# Run 20260808T024735-default-fair-minimax-minimax-m3-polygon__agglayer_bridge

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: polygon/agglayer_bridge
- score: 0 / 2 points
- targets: 0 / 2 passed
- failure taxonomy: {"repetition_loop": 2}

## Targets

- `polygon/agglayer_bridge/claimAsset_valid_leaf_and_consumes_unique_nullifier`: forbidden_placeholder
- `polygon/agglayer_bridge/claimMessage_valid_leaf_and_consumes_unique_nullifier`: forbidden_placeholder
