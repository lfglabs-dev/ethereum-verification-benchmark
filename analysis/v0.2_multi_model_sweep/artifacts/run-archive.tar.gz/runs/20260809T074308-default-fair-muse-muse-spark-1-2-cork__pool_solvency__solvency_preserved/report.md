# Run 20260809T074308-default-fair-muse-muse-spark-1-2-cork__pool_solvency__solvency_preserved

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: cork/pool_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `cork/pool_solvency/solvency_preserved`: verifier_infra_error
