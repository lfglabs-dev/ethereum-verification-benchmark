# Run 20260809T121638-default-fair-openai-gpt-5-5-alchemix__earmark_conservation__redeem_preserves_invariant

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: alchemix/earmark_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `alchemix/earmark_conservation/redeem_preserves_invariant`: verifier_infra_error
