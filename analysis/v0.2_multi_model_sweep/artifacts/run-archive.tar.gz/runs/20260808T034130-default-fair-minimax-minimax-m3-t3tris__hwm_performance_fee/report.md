# Run 20260808T034130-default-fair-minimax-minimax-m3-t3tris__hwm_performance_fee

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: t3tris/hwm_performance_fee
- score: 1 / 8 points
- targets: 1 / 8 passed
- failure taxonomy: {"max_attempts_exceeded": 3, "repetition_loop": 4}

## Targets

- `t3tris/hwm_performance_fee/fee_claim_preserves_unclaimed_le_supply`: passed
- `t3tris/hwm_performance_fee/gain_loss_recovery_no_double_charge`: forbidden_placeholder
- `t3tris/hwm_performance_fee/no_performance_fee_when_pre_pps_le_hwm`: forbidden_placeholder
- `t3tris/hwm_performance_fee/period_fee_accounting_preserves_structural_assumptions`: lean_check_failed
- `t3tris/hwm_performance_fee/profit_pnl_uses_cached_hwm`: forbidden_placeholder
- `t3tris/hwm_performance_fee/recovery_then_new_high_uses_stored_hwm`: forbidden_placeholder
- `t3tris/hwm_performance_fee/validated_initial_state_satisfies_successful_assumptions`: lean_check_failed
- `t3tris/hwm_performance_fee/validated_performance_fee_update_preserves_cap`: lean_check_failed
