# Verity Task Summary

- group: `t3tris/hwm_performance_fee`
- suite: `active`
- tasks: `8`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `t3tris/hwm_performance_fee/fee_claim_preserves_unclaimed_le_supply`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.fee_claim_preserves_unclaimed_le_supply`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.FeeClaimPreservesUnclaimedLeSupply`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/FeeClaimPreservesUnclaimedLeSupply.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/FeeClaimPreservesUnclaimedLeSupply.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem fee_claim_preserves_unclaimed_le_supply
    (s : FeeState)
    (requestedSharesToClaim : Nat) :
    fee_claim_preserves_unclaimed_le_supply_spec s requestedSharesToClaim := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 2: `t3tris/hwm_performance_fee/gain_loss_recovery_no_double_charge`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.gain_loss_recovery_no_double_charge`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.GainLossRecoveryNoDoubleCharge`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/GainLossRecoveryNoDoubleCharge.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/GainLossRecoveryNoDoubleCharge.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem gain_loss_recovery_no_double_charge
    (s0 : FeeState)
    (gainAssets lossAssets recoveryAssets : Nat)
    (gainManagementFee : ManagementFeeModel := noManagementFee)
    (lossManagementFee : ManagementFeeModel := noManagementFee)
    (recoveryManagementFee : ManagementFeeModel := noManagementFee) :
    gain_loss_recovery_no_double_charge_spec
      s0 gainAssets lossAssets recoveryAssets
      gainManagementFee lossManagementFee recoveryManagementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 3: `t3tris/hwm_performance_fee/no_performance_fee_when_pre_pps_le_hwm`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.no_performance_fee_when_pre_pps_le_hwm`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.NoPerformanceFeeWhenPrePpsLeHwm`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/NoPerformanceFeeWhenPrePpsLeHwm.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/NoPerformanceFeeWhenPrePpsLeHwm.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem no_performance_fee_when_pre_pps_le_hwm
    (gross : GrossTvlData)
    (params : PeriodFeesParams)
    (managementFee : ManagementFeeModel := noManagementFee) :
    no_performance_fee_when_pre_pps_le_hwm_spec gross params managementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 4: `t3tris/hwm_performance_fee/period_fee_accounting_preserves_structural_assumptions`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.period_fee_accounting_preserves_structural_assumptions`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.PeriodFeeAccountingPreservesStructuralAssumptions`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/PeriodFeeAccountingPreservesStructuralAssumptions.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/PeriodFeeAccountingPreservesStructuralAssumptions.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem period_fee_accounting_preserves_structural_assumptions
    (s : FeeState)
    (totalAssets : Nat)
    (managementFee : ManagementFeeModel := noManagementFee) :
    period_fee_accounting_preserves_structural_assumptions_spec s totalAssets managementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 5: `t3tris/hwm_performance_fee/profit_pnl_uses_cached_hwm`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.profit_pnl_uses_cached_hwm`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.ProfitPnlUsesCachedHwm`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ProfitPnlUsesCachedHwm.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ProfitPnlUsesCachedHwm.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem profit_pnl_uses_cached_hwm
    (gross : GrossTvlData)
    (params : PeriodFeesParams)
    (managementFee : ManagementFeeModel := noManagementFee) :
    profit_pnl_uses_cached_hwm_spec gross params managementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 6: `t3tris/hwm_performance_fee/recovery_then_new_high_uses_stored_hwm`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.recovery_then_new_high_uses_stored_hwm`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.RecoveryThenNewHighUsesStoredHwm`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/RecoveryThenNewHighUsesStoredHwm.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/RecoveryThenNewHighUsesStoredHwm.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem recovery_then_new_high_uses_stored_hwm
    (s0 : FeeState)
    (gainAssets lossAssets recoveryAssets newHighAssets : Nat)
    (gainManagementFee : ManagementFeeModel := noManagementFee)
    (lossManagementFee : ManagementFeeModel := noManagementFee)
    (recoveryManagementFee : ManagementFeeModel := noManagementFee)
    (newHighManagementFee : ManagementFeeModel := noManagementFee) :
    recovery_then_new_high_uses_stored_hwm_spec
      s0 gainAssets lossAssets recoveryAssets newHighAssets
      gainManagementFee lossManagementFee recoveryManagementFee newHighManagementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 7: `t3tris/hwm_performance_fee/validated_initial_state_satisfies_successful_assumptions`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.validated_initial_state_satisfies_successful_assumptions`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.ValidatedInitialStateSatisfiesSuccessfulAssumptions`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ValidatedInitialStateSatisfiesSuccessfulAssumptions.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ValidatedInitialStateSatisfiesSuccessfulAssumptions.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem validated_initial_state_satisfies_successful_assumptions
    (performanceFeeWad : Nat) :
    validated_initial_state_satisfies_successful_assumptions_spec performanceFeeWad := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```

## Task 8: `t3tris/hwm_performance_fee/validated_performance_fee_update_preserves_cap`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.validated_performance_fee_update_preserves_cap`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.ValidatedPerformanceFeeUpdatePreservesCap`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ValidatedPerformanceFeeUpdatePreservesCap.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/ValidatedPerformanceFeeUpdatePreservesCap.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem validated_performance_fee_update_preserves_cap
    (s : FeeState)
    (nextPerformanceFeeWad : Nat) :
    validated_performance_fee_update_preserves_cap_spec s nextPerformanceFeeWad := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```
