import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem period_fee_accounting_preserves_structural_assumptions
    (s : FeeState)
    (totalAssets : Nat)
    (managementFee : ManagementFeeModel := noManagementFee) :
    period_fee_accounting_preserves_structural_assumptions_spec s totalAssets managementFee := by
  intro h; unfold period_fee_accounting_preserves_structural_assumptions_spec periodStepNoReanchor feeStateStructuralInvariant computeLastPeriodFeesAndUpdateResult recordAccruedFeesNoReanchor; simp_all

end Benchmark.Cases.T3tris.HwmPerformanceFee

