import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem fee_claim_preserves_unclaimed_le_supply
    (s : FeeState)
    (requestedSharesToClaim : Nat) :
    fee_claim_preserves_unclaimed_le_supply_spec s requestedSharesToClaim := by
  intro h
  unfold claimFeeShares
  simp only
  omega

end Benchmark.Cases.T3tris.HwmPerformanceFee

