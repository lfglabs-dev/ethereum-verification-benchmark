import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem validated_initial_state_satisfies_successful_assumptions
    (performanceFeeWad : Nat) :
    validated_initial_state_satisfies_successful_assumptions_spec performanceFeeWad := by
  intro s h
  unfold initializeFeeState at h
  simp at h
  subst s
  unfold feeStateStructuralInvariant
  simp

end Benchmark.Cases.T3tris.HwmPerformanceFee

