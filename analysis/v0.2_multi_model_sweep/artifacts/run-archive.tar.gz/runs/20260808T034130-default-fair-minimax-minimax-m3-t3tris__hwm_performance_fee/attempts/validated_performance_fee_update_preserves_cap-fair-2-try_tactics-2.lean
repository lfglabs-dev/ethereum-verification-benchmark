import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem validated_performance_fee_update_preserves_cap
    (s : FeeState)
    (nextPerformanceFeeWad : Nat) :
    validated_performance_fee_update_preserves_cap_spec s nextPerformanceFeeWad := by
  intros h s' hs; cases s' <;> simp [setValidatedPerformanceFee] at hs ⊢; split at hs <;> first | assumption | exact le_of_not_gt (by intro hx; cases hs; assumption)

end Benchmark.Cases.T3tris.HwmPerformanceFee

