import Benchmark.Cases.Piku.FundConservation.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Piku.FundConservation

open Verity
open Verity.EVM.Uint256

/--
Manual queue payment execution preserves the same backing decomposition
when the queued amount is split into user distribution plus protocol treasury
fee. The reference proof discharges that Uint256 split arithmetic directly.
-/
theorem amountPaid_preserves_fund_conservation
    (amount protocolFeeAmount_ : Uint256) (s : ContractState)
    (hOpen : amount.val <= (s.storage 5).val)
    (hFee : protocolFeeAmount_.val <= amount.val) :
    let s' := ((FM_PC_Oracle_Redeeming_v1.amountPaid amount protocolFeeAmount_).run s).snd
    amountPaid_preserves_fund_conservation_spec amount protocolFeeAmount_ s s' := by
  unfold FM_PC_Oracle_Redeeming_v1.amountPaid amountPaid_preserves_fund_conservation_spec; simp [Contract.run, Verity.bind, Bind.bind, Verity.require, Verity.pure, Pure.pure, getStorage, setStorage]

end Benchmark.Cases.Piku.FundConservation

