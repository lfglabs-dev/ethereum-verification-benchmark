import Benchmark.Cases.Piku.FundConservation.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Piku.FundConservation

open Verity
open Verity.EVM.Uint256

theorem _sellOrder_records_redemption_buckets
    (total protocolFeeBps : Uint256) (s : ContractState)
    (hAmount : total != 0)
    (hFees : add protocolFeeBps (s.storage 7) < 10000)
    (hRemaining : total.val <= (s.storage 2).val) :
    let s' := ((FM_PC_Oracle_Redeeming_v1._sellOrder total protocolFeeBps).run s).snd
    _sellOrder_records_redemption_buckets_spec total protocolFeeBps s s' := by
  unfold _sellOrder_records_redemption_buckets_spec projectFeeAmount protocolFeeAmount netRedeemAmount _createAndEmitOrder _addToOpenRedemptionAmount FM_PC_Oracle_Redeeming_v1.sellOrder; simp [Contract.run, Verity.bind, Bind.bind, Verity.require, Verity.pure, Pure.pure, getStorage, setStorage, FundConservation.add, FundConservation.sub]

end Benchmark.Cases.Piku.FundConservation

