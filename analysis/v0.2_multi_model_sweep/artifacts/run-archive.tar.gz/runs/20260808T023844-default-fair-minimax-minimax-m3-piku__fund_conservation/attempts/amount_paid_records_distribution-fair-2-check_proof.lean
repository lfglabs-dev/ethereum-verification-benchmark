import Benchmark.Cases.Piku.FundConservation.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Piku.FundConservation

open Verity
open Verity.EVM.Uint256

theorem amountPaid_records_distribution
    (amount protocolFeeAmount_ : Uint256) (s : ContractState)
    (hOpen : amount.val <= (s.storage 5).val)
    (hFee : protocolFeeAmount_.val <= amount.val) :
    let s' := ((FM_PC_Oracle_Redeeming_v1.amountPaid amount protocolFeeAmount_).run s).snd
    amountPaid_records_distribution_spec amount protocolFeeAmount_ s s' := by
  unfold FM_PC_Oracle_Redeeming_v1.amountPaid amountPaid_records_distribution_spec
    simp [Contract.run, Verity.bind, Bind.bind, Verity.require, Verity.pure, Pure.pure, getStorage, setStorage]
    refine ⟨?_, ?_, ?_⟩ <;> simp_all [Contract.run, Verity.bind, Bind.bind, Verity.require, Verity.pure, Pure.pure, getStorage, setStorage]
    · omega
    · omega
    · omega

end Benchmark.Cases.Piku.FundConservation

