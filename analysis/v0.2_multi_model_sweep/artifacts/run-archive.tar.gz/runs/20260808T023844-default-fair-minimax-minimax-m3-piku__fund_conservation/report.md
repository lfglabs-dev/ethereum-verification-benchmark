# Run 20260808T023844-default-fair-minimax-minimax-m3-piku__fund_conservation

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: piku/fund_conservation
- score: 0 / 4 points
- targets: 0 / 4 passed
- failure taxonomy: {"max_attempts_exceeded": 4}

## Targets

- `piku/fund_conservation/amount_paid_preserves_fund_conservation`: lean_check_failed
- `piku/fund_conservation/amount_paid_records_distribution`: forbidden_placeholder
- `piku/fund_conservation/sell_order_preserves_fund_conservation`: lean_check_failed
- `piku/fund_conservation/sell_order_records_redemption_buckets`: lean_check_failed
