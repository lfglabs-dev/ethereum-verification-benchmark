# Run 20260808T214801-default-fair-minimax-minimax-m3-lifi__swap_atomicity__final_transfer_implies_all_steps_succeeded

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lifi/swap_atomicity
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `lifi/swap_atomicity/final_transfer_implies_all_steps_succeeded`: lean_check_failed
