# Run 20260809T122757-default-fair-openai-gpt-5-5-erc4337__entry_point_invariant__beneficiary_eq_total_prefund

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: erc4337/entry_point_invariant
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `erc4337/entry_point_invariant/beneficiary_eq_total_prefund`: forbidden_placeholder
