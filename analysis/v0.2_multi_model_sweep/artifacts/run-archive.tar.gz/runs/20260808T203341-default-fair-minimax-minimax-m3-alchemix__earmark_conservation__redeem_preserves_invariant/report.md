# Run 20260808T203341-default-fair-minimax-minimax-m3-alchemix__earmark_conservation__redeem_preserves_invariant

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: alchemix/earmark_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `alchemix/earmark_conservation/redeem_preserves_invariant`: forbidden_placeholder
