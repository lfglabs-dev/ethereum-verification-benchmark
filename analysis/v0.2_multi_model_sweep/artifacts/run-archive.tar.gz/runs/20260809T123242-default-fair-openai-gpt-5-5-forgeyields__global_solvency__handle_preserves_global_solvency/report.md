# Run 20260809T123242-default-fair-openai-gpt-5-5-forgeyields__global_solvency__handle_preserves_global_solvency

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: forgeyields/global_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `forgeyields/global_solvency/handle_preserves_global_solvency`: lean_check_failed
