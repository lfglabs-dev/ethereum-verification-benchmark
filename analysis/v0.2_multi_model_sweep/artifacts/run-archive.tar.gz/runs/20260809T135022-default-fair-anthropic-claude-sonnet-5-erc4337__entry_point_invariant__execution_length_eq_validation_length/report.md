# Run 20260809T135022-default-fair-anthropic-claude-sonnet-5-erc4337__entry_point_invariant__execution_length_eq_validation_length

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: erc4337/entry_point_invariant
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `erc4337/entry_point_invariant/execution_length_eq_validation_length`: verifier_infra_error
