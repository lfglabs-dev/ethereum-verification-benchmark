# Run 20260808T210001-default-fair-minimax-minimax-m3-ipor__plasma_vault_redeem_split__fee_payout_bounded_by_fee_free

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: ipor/plasma_vault_redeem_split
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `ipor/plasma_vault_redeem_split/fee_payout_bounded_by_fee_free`: theorem_missing
