import Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.DamnVulnerableDeFi.SideEntrance

open Verity
open Verity.EVM.Uint256

/--
Executing the summarized flash-loan-plus-deposit path leaves tracked pool ETH
unchanged.
-/
theorem flashLoanViaDeposit_preserves_pool_balance
    (amount : Uint256) (s : ContractState)
    (hBorrow : amount <= s.storage 0) :
    let s' := ((SideEntrance.flashLoanViaDeposit amount).run s).snd
    flashLoanViaDeposit_preserves_pool_balance_spec amount s s' := by
  try simp only [grind_norm] at *; try unfold flashLoanViaDeposit_preserves_pool_balance_spec; try unfold SideEntrance.flashLoanViaDeposit; simp [grind_norm, SideEntrance.flashLoanViaDeposit, SideEntrance.poolBalance, SideEntrance.totalCredits, SideEntrance.creditOf, *]; all_goals try (split_ifs <;> simp_all [grind_norm]); all_goals try (repeat' (split <;> simp_all [grind_norm])); all_goals try omega

end Benchmark.Cases.DamnVulnerableDeFi.SideEntrance

