# Run 20260808T204534-default-fair-minimax-minimax-m3-damn_vulnerable_defi__side_entrance__flash_loan_via_deposit_preserves_pool_balance

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: damn_vulnerable_defi/side_entrance
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `damn_vulnerable_defi/side_entrance/flash_loan_via_deposit_preserves_pool_balance`: passed
