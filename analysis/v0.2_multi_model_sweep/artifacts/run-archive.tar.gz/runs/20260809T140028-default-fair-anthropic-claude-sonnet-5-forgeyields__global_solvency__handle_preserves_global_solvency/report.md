# Run 20260809T140028-default-fair-anthropic-claude-sonnet-5-forgeyields__global_solvency__handle_preserves_global_solvency

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: forgeyields/global_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `forgeyields/global_solvency/handle_preserves_global_solvency`: verifier_infra_error
