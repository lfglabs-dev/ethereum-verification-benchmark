# Run 20260809T032932-default-fair-minimax-minimax-m3-erc4337__entry_point_invariant__beneficiary_eq_total_prefund

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: erc4337/entry_point_invariant
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `erc4337/entry_point_invariant/beneficiary_eq_total_prefund`: lean_check_failed
