# Run 20260809T053227-default-fair-gpt-5-6-terra-erc4337__entry_point_invariant__beneficiary_eq_total_prefund

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: erc4337/entry_point_invariant
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `erc4337/entry_point_invariant/beneficiary_eq_total_prefund`: forbidden_placeholder
