# Run 20260810T092302-default-fair-anthropic-claude-fable-5-1inch__xycswap_curve_safety__quote_exact_in_curve_safety

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: 1inch/xycswap_curve_safety
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `1inch/xycswap_curve_safety/quote_exact_in_curve_safety`: forbidden_placeholder
