# Run 20260808T025643-default-fair-minimax-minimax-m3-safe__owner_manager_reach

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: safe/owner_manager_reach
- score: 0 / 15 points
- targets: 0 / 15 passed
- failure taxonomy: {"max_attempts_exceeded": 6, "repetition_loop": 9}

## Targets

- `safe/owner_manager_reach/add_owner_acyclicity`: forbidden_placeholder
- `safe/owner_manager_reach/add_owner_is_owner_correctness`: forbidden_placeholder
- `safe/owner_manager_reach/add_owner_owner_list_invariant`: lean_check_failed
- `safe/owner_manager_reach/in_list_reachable`: lean_check_failed
- `safe/owner_manager_reach/remove_owner_acyclicity`: lean_check_failed
- `safe/owner_manager_reach/remove_owner_in_list_reachable`: lean_check_failed
- `safe/owner_manager_reach/remove_owner_is_owner_correctness`: lean_check_failed
- `safe/owner_manager_reach/remove_owner_owner_list_invariant`: lean_check_failed
- `safe/owner_manager_reach/setup_owners_acyclicity`: lean_check_failed
- `safe/owner_manager_reach/setup_owners_in_list_reachable`: lean_check_failed
- `safe/owner_manager_reach/setup_owners_owner_list_invariant`: forbidden_placeholder
- `safe/owner_manager_reach/swap_owner_acyclicity`: forbidden_placeholder
- `safe/owner_manager_reach/swap_owner_in_list_reachable`: forbidden_placeholder
- `safe/owner_manager_reach/swap_owner_is_owner_correctness`: forbidden_placeholder
- `safe/owner_manager_reach/swap_owner_owner_list_invariant`: forbidden_placeholder
