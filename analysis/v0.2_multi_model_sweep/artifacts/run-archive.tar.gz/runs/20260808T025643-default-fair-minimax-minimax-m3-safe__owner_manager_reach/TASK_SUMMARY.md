# Verity Task Summary

- group: `safe/owner_manager_reach`
- suite: `active`
- tasks: `15`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `safe/owner_manager_reach/add_owner_acyclicity`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.addOwner_acyclicity`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.AddOwnerAcyclicity`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerAcyclicity.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerAcyclicity.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
addOwner preserves acyclicity of the owner linked list.

After addOwner(owner), the list becomes:
  SENTINEL → owner → old_head → ... → SENTINEL

Acyclicity is a tautology — it holds for any state. The proof
(acyclic_generic) shows that any duplicate-free chain from SENTINEL's
successor ending at key ≠ SENTINEL cannot contain SENTINEL, purely
by the structure of the definitions. No pre-state hypotheses are needed
beyond the Solidity require guards.
-/
theorem addOwner_acyclicity
    (owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hFresh : (wordToAddress (s.storageMap 0 owner) == zeroAddress) = true) :
    acyclic ((OwnerManager.addOwner owner).run s).snd := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 2: `safe/owner_manager_reach/add_owner_is_owner_correctness`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.addOwner_isOwnerCorrectness`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.AddOwnerIsOwnerCorrectness`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerIsOwnerCorrectness.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerIsOwnerCorrectness.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Functional correctness of `addOwner`: the new address becomes an owner
and all other addresses' ownership status is unchanged.

`isOwner s addr` holds iff `next s addr ≠ zeroAddress ∧ addr ≠ SENTINEL`.

Proof strategy: use `addOwner_next_eq` to characterise the post-state
`next` function, then split into the two conjuncts of `addOwner_correctness`.
For the new owner: `next s' owner = next s SENTINEL ≠ 0`.
For others: `next s' k = next s k` when `k ≠ SENTINEL` and `k ≠ owner`.
-/
theorem addOwner_isOwnerCorrectness
    (owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hFresh : (wordToAddress (s.storageMap 0 owner) == zeroAddress) = true)
    (hPreInv : ownerListInvariant s) :
    let s' := ((OwnerManager.addOwner owner).run s).snd
    addOwner_correctness s s' owner := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 3: `safe/owner_manager_reach/add_owner_owner_list_invariant`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.addOwner_ownerListInvariant`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.AddOwnerOwnerListInvariant`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerOwnerListInvariant.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/AddOwnerOwnerListInvariant.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Combined `ownerListInvariant` preservation under `addOwner`.

The ownerListInvariant merges `inListReachable` and `reachableInList`:
membership (non-zero successor) is equivalent to reachability from
SENTINEL. This is strictly stronger than proving inListReachable alone.

Proof strategy: prove both directions of the biconditional separately.
The forward direction (membership → reachability) follows from the
existing inListReachable proof. The reverse direction (reachability →
membership) requires showing that the new chain structure doesn't
introduce reachability to nodes with zero successors.

Acyclicity and freshness are derived from ownerListInvariant internally,
not required as separate hypotheses.
-/
theorem addOwner_ownerListInvariant
    (owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hFresh : (wordToAddress (s.storageMap 0 owner) == zeroAddress) = true)
    (hPreInv : ownerListInvariant s) :
    let s' := ((OwnerManager.addOwner owner).run s).snd
    ownerListInvariant s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 4: `safe/owner_manager_reach/in_list_reachable`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.in_list_reachable`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.InListReachable`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/InListReachable.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/InListReachable.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Certora `inListReachable` invariant preservation under `addOwner`.

Given that in the pre-state every node with a non-zero successor is reachable
from SENTINEL, show that the same holds in the post-state after inserting
`owner` at the head of the linked list.

Proof strategy: SENTINEL is trivially reachable (reflexivity). The new owner
is reachable via [SENTINEL, owner]. For any other key with a non-zero successor,
its next pointer is unchanged, so we can lift its pre-state witness chain to
the post-state and prepend the new path SENTINEL → owner → old_head.
-/
theorem in_list_reachable
    (owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hFresh : (wordToAddress (s.storageMap 0 owner) == zeroAddress) = true)
    (hPreReach : ∀ key : Address, next s key ≠ zeroAddress → reachable s SENTINEL key)
    -- Raw acyclicity: SENTINEL ∉ any chain from next s SENTINEL.
    -- Strictly stronger than `acyclic s` (no noDuplicates guard).
    (hAcyclic : ∀ key : Address, ∀ chain : List Address,
      chain.head? = some (next s SENTINEL) →
      chain.getLast? = some key →
      isChain s chain →
      SENTINEL ∉ chain)
    -- Raw freshness: owner ∉ any chain from next s SENTINEL.
    -- Strictly stronger than `freshInList s owner` (no noDuplicates guard).
    (hOwnerFresh : ∀ key : Address, ∀ chain : List Address,
      chain.head? = some (next s SENTINEL) →
      chain.getLast? = some key →
      isChain s chain →
      owner ∉ chain) :
    in_list_reachable_spec s ((OwnerManager.addOwner owner).run s).snd := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 5: `safe/owner_manager_reach/remove_owner_acyclicity`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.removeOwner_acyclicity`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.RemoveOwnerAcyclicity`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerAcyclicity.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerAcyclicity.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
removeOwner preserves acyclicity of the owner linked list.

Acyclicity is a tautology — it holds for any state. The proof
(acyclic_generic) shows that any duplicate-free chain from SENTINEL's
successor ending at key ≠ SENTINEL cannot contain SENTINEL, purely
by the structure of the definitions. No pre-state acyclicity hypothesis
is needed.
-/
theorem removeOwner_acyclicity
    (prevOwner owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == owner) = true)
    (hOwnerInList : next s owner ≠ zeroAddress) :
    acyclic ((OwnerManager.removeOwner prevOwner owner).run s).snd := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 6: `safe/owner_manager_reach/remove_owner_in_list_reachable`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.removeOwner_inListReachable`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.RemoveOwnerInListReachable`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerInListReachable.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerInListReachable.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Certora `inListReachable` invariant preservation under `removeOwner`.

After removing `owner` by unlinking it from `prevOwner`, show that every
node with a non-zero successor in the post-state is still reachable from
SENTINEL.

Proof strategy: The removed owner's mapping becomes 0 so it no longer
triggers the invariant. prevOwner now points to owner's old successor,
so chains that went through owner can "skip" it: replace
[... → prevOwner → owner → X → ...] with [... → prevOwner → X → ...].
All other next pointers are unchanged.
-/
theorem removeOwner_inListReachable
    (prevOwner owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == owner) = true)
    -- The removed owner must have a non-zero successor (i.e. be in the list).
    (hOwnerInList : next s owner ≠ zeroAddress)
    -- Pre-state invariant
    (hPreInv : inListReachable s)
    -- Unique predecessor: each non-zero node has at most one non-zero predecessor.
    (hUniquePred : uniquePredecessor s)
    -- prevOwner is non-zero (a valid list node)
    (hPrevNZ : prevOwner ≠ zeroAddress)
    -- Zero address maps to itself
    (hZeroInert : next s zeroAddress = zeroAddress) :
    let s' := ((OwnerManager.removeOwner prevOwner owner).run s).snd
    inListReachable s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 7: `safe/owner_manager_reach/remove_owner_is_owner_correctness`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.removeOwner_isOwnerCorrectness`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.RemoveOwnerIsOwnerCorrectness`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerIsOwnerCorrectness.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerIsOwnerCorrectness.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Functional correctness of `removeOwner`: the removed address is no longer
an owner and all other addresses' ownership status is unchanged.

`isOwner s addr` holds iff `next s addr ≠ zeroAddress ∧ addr ≠ SENTINEL`.

Proof strategy: use `removeOwner_storageMap` to characterise the post-state
`next` function, then show `next s' owner = zeroAddress` and for all
`k ≠ owner`, `next s' k ≠ 0 ↔ next s k ≠ 0` by case-splitting on
`k = prevOwner`.
-/
theorem removeOwner_isOwnerCorrectness
    (prevOwner owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == owner) = true)
    (hOwnerInList : next s owner ≠ zeroAddress) :
    let s' := ((OwnerManager.removeOwner prevOwner owner).run s).snd
    removeOwner_correctness s s' owner := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 8: `safe/owner_manager_reach/remove_owner_owner_list_invariant`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.removeOwner_ownerListInvariant`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.RemoveOwnerOwnerListInvariant`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerOwnerListInvariant.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/RemoveOwnerOwnerListInvariant.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Combined `ownerListInvariant` preservation under `removeOwner`.

Properties like noSelfLoops and owner ≠ prevOwner are derived internally
from ownerListInvariant + uniquePredecessor, not required as hypotheses.
-/
theorem removeOwner_ownerListInvariant
    (prevOwner owner : Address) (s : ContractState)
    (hNotZero : (owner != zeroAddress) = true)
    (hNotSentinel : (owner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == owner) = true)
    (hOwnerInList : next s owner ≠ zeroAddress)
    (hPreInv : ownerListInvariant s)
    (hUniquePred : uniquePredecessor s)
    (hPrevNZ : prevOwner ≠ zeroAddress)
    (hZeroInert : next s zeroAddress = zeroAddress) :
    let s' := ((OwnerManager.removeOwner prevOwner owner).run s).snd
    ownerListInvariant s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 9: `safe/owner_manager_reach/setup_owners_acyclicity`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.setupOwners_acyclicity`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SetupOwnersAcyclicity`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersAcyclicity.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersAcyclicity.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
setupOwners establishes acyclicity of the owner linked list (base case).

The constructed list SENTINEL → o1 → o2 → o3 → SENTINEL has no internal
cycles because all three owners are distinct, non-zero, and non-sentinel.
SENTINEL appears only as the list head and the terminal pointer
(o3 → SENTINEL), never in the interior of any chain starting from
SENTINEL's successor.
-/
theorem setupOwners_acyclicity
    (owner1 owner2 owner3 : Address) (s : ContractState)
    (h1NZ : (owner1 != zeroAddress) = true)
    (h1NS : (owner1 != SENTINEL) = true)
    (h2NZ : (owner2 != zeroAddress) = true)
    (h2NS : (owner2 != SENTINEL) = true)
    (h3NZ : (owner3 != zeroAddress) = true)
    (h3NS : (owner3 != SENTINEL) = true)
    (h12 : (owner1 != owner2) = true)
    (h13 : (owner1 != owner3) = true)
    (h23 : (owner2 != owner3) = true)
    (hClean : ∀ addr : Address, s.storageMap 0 addr = 0) :
    let s' := ((OwnerManager.setupOwners owner1 owner2 owner3).run s).snd
    acyclic s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 10: `safe/owner_manager_reach/setup_owners_in_list_reachable`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.setupOwners_inListReachable`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SetupOwnersInListReachable`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersInListReachable.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersInListReachable.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
setupOwners establishes the `inListReachable` invariant from a clean state.
This is the base case: no pre-state invariant is required.

After setupOwners(owner1, owner2, owner3), the linked list is:
  SENTINEL → owner1 → owner2 → owner3 → SENTINEL

Every node with a non-zero successor (SENTINEL, owner1, owner2, owner3)
is reachable from SENTINEL by construction. This can be proven by
characterizing the post-state storageMap and building explicit witness
chains for each node.
-/
theorem setupOwners_inListReachable
    (owner1 owner2 owner3 : Address) (s : ContractState)
    (h1NZ : (owner1 != zeroAddress) = true)
    (h1NS : (owner1 != SENTINEL) = true)
    (h2NZ : (owner2 != zeroAddress) = true)
    (h2NS : (owner2 != SENTINEL) = true)
    (h3NZ : (owner3 != zeroAddress) = true)
    (h3NS : (owner3 != SENTINEL) = true)
    (h12 : (owner1 != owner2) = true)
    (h13 : (owner1 != owner3) = true)
    (h23 : (owner2 != owner3) = true)
    (hClean : ∀ addr : Address, s.storageMap 0 addr = 0) :
    let s' := ((OwnerManager.setupOwners owner1 owner2 owner3).run s).snd
    inListReachable s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 11: `safe/owner_manager_reach/setup_owners_owner_list_invariant`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.setupOwners_ownerListInvariant`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SetupOwnersOwnerListInvariant`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersOwnerListInvariant.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SetupOwnersOwnerListInvariant.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
setupOwners establishes the combined `ownerListInvariant` (base case).

After setupOwners(owner1, owner2, owner3), the linked list is:
  SENTINEL → owner1 → owner2 → owner3 → SENTINEL

Both directions of the biconditional hold: every node with a non-zero
successor is reachable from SENTINEL (by explicit chains), and every
node reachable from SENTINEL has a non-zero successor (because only
SENTINEL, owner1, owner2, owner3 are reachable, and they all have
non-zero successors).
-/
theorem setupOwners_ownerListInvariant
    (owner1 owner2 owner3 : Address) (s : ContractState)
    (h1NZ : (owner1 != zeroAddress) = true)
    (h1NS : (owner1 != SENTINEL) = true)
    (h2NZ : (owner2 != zeroAddress) = true)
    (h2NS : (owner2 != SENTINEL) = true)
    (h3NZ : (owner3 != zeroAddress) = true)
    (h3NS : (owner3 != SENTINEL) = true)
    (h12 : (owner1 != owner2) = true)
    (h13 : (owner1 != owner3) = true)
    (h23 : (owner2 != owner3) = true)
    (hClean : ∀ addr : Address, s.storageMap 0 addr = 0) :
    let s' := ((OwnerManager.setupOwners owner1 owner2 owner3).run s).snd
    ownerListInvariant s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 12: `safe/owner_manager_reach/swap_owner_acyclicity`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.swapOwner_acyclicity`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SwapOwnerAcyclicity`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerAcyclicity.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerAcyclicity.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
swapOwner preserves acyclicity of the owner linked list.

Acyclicity is a tautology — it holds for any state. The proof
(acyclic_generic) shows that any duplicate-free chain from SENTINEL's
successor ending at key ≠ SENTINEL cannot contain SENTINEL, purely
by the structure of the definitions. No pre-state hypotheses are needed
beyond the Solidity require guards.
-/
theorem swapOwner_acyclicity
    (prevOwner oldOwner newOwner : Address) (s : ContractState)
    (hNewNotZero : (newOwner != zeroAddress) = true)
    (hNewNotSentinel : (newOwner != SENTINEL) = true)
    (hNewFresh : (wordToAddress (s.storageMap 0 newOwner) == zeroAddress) = true)
    (hOldNotZero : (oldOwner != zeroAddress) = true)
    (hOldNotSentinel : (oldOwner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == oldOwner) = true) :
    acyclic ((OwnerManager.swapOwner prevOwner oldOwner newOwner).run s).snd := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 13: `safe/owner_manager_reach/swap_owner_in_list_reachable`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.swapOwner_inListReachable`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SwapOwnerInListReachable`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerInListReachable.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerInListReachable.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Certora `inListReachable` invariant preservation under `swapOwner`.

swapOwner atomically replaces oldOwner with newOwner in-place:
  owners[newOwner] = owners[oldOwner]
  owners[prevOwner] = newOwner
  owners[oldOwner] = 0

Proof strategy: newOwner inherits oldOwner's successor. For any key with
a non-zero successor in the post-state, its pre-state chain through
oldOwner can be adapted by replacing oldOwner with newOwner:
[... → prevOwner → oldOwner → X → ...] becomes
[... → prevOwner → newOwner → X → ...].
-/
theorem swapOwner_inListReachable
    (prevOwner oldOwner newOwner : Address) (s : ContractState)
    (hNewNotZero : (newOwner != zeroAddress) = true)
    (hNewNotSentinel : (newOwner != SENTINEL) = true)
    (hNewFresh : (wordToAddress (s.storageMap 0 newOwner) == zeroAddress) = true)
    (hOldNotZero : (oldOwner != zeroAddress) = true)
    (hOldNotSentinel : (oldOwner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == oldOwner) = true)
    -- Pre-state invariant (full ownerListInvariant, not just inListReachable)
    (hPreInvFull : ownerListInvariant s)
    -- Unique predecessor: each non-zero node has at most one non-zero predecessor.
    (hUniquePred : uniquePredecessor s)
    -- prevOwner is non-zero (a valid list node)
    (hPrevNZ : prevOwner ≠ zeroAddress)
    -- Zero address maps to itself
    (hZeroInert : next s zeroAddress = zeroAddress) :
    let s' := ((OwnerManager.swapOwner prevOwner oldOwner newOwner).run s).snd
    inListReachable s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 14: `safe/owner_manager_reach/swap_owner_is_owner_correctness`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.swapOwner_isOwnerCorrectness`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SwapOwnerIsOwnerCorrectness`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerIsOwnerCorrectness.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerIsOwnerCorrectness.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Functional correctness of `swapOwner`: the old owner is removed, the new
owner is added, and all other addresses' ownership status is unchanged.

`isOwner s addr` holds iff `next s addr ≠ zeroAddress ∧ addr ≠ SENTINEL`.

Proof strategy: use `swapOwner_storageMap` to characterise the post-state
`next` function, then show:
  1. `next s' oldOwner = zeroAddress` (old owner removed)
  2. `next s' newOwner = next s oldOwner ≠ 0` (new owner added)
  3. For all `k ≠ oldOwner, k ≠ newOwner`: `next s' k ≠ 0 ↔ next s k ≠ 0`
     by case-splitting on `k = prevOwner`.
-/
theorem swapOwner_isOwnerCorrectness
    (prevOwner oldOwner newOwner : Address) (s : ContractState)
    (hNewNotZero : (newOwner != zeroAddress) = true)
    (hNewNotSentinel : (newOwner != SENTINEL) = true)
    (hNewFresh : (wordToAddress (s.storageMap 0 newOwner) == zeroAddress) = true)
    (hOldNotZero : (oldOwner != zeroAddress) = true)
    (hOldNotSentinel : (oldOwner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == oldOwner) = true)
    (hOldInList : next s oldOwner ≠ zeroAddress) :
    let s' := ((OwnerManager.swapOwner prevOwner oldOwner newOwner).run s).snd
    swapOwner_correctness s s' oldOwner newOwner := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```

## Task 15: `safe/owner_manager_reach/swap_owner_owner_list_invariant`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.swapOwner_ownerListInvariant`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SwapOwnerOwnerListInvariant`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerOwnerListInvariant.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerOwnerListInvariant.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Combined `ownerListInvariant` preservation under `swapOwner`.

Properties like noSelfLoops, freshInList, and oldOwner ≠ prevOwner are
derived internally from ownerListInvariant + uniquePredecessor, not
required as hypotheses.
-/
theorem swapOwner_ownerListInvariant
    (prevOwner oldOwner newOwner : Address) (s : ContractState)
    (hNewNotZero : (newOwner != zeroAddress) = true)
    (hNewNotSentinel : (newOwner != SENTINEL) = true)
    (hNewFresh : (wordToAddress (s.storageMap 0 newOwner) == zeroAddress) = true)
    (hOldNotZero : (oldOwner != zeroAddress) = true)
    (hOldNotSentinel : (oldOwner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == oldOwner) = true)
    (hPreInv : ownerListInvariant s)
    (hUniquePred : uniquePredecessor s)
    (hPrevNZ : prevOwner ≠ zeroAddress)
    (hZeroInert : next s zeroAddress = zeroAddress) :
    let s' := ((OwnerManager.swapOwner prevOwner oldOwner newOwner).run s).snd
    ownerListInvariant s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```
