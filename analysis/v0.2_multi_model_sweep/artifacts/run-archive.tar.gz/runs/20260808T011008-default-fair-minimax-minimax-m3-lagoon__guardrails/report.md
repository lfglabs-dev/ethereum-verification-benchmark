# Run 20260808T011008-default-fair-minimax-minimax-m3-lagoon__guardrails

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: lagoon/guardrails
- score: 0 / 3 points
- targets: 0 / 3 passed
- failure taxonomy: {"max_attempts_exceeded": 3}

## Targets

- `lagoon/guardrails/exact_compliance`: theorem_missing
- `lagoon/guardrails/negative_variation_bounded`: theorem_missing
- `lagoon/guardrails/positive_variation_bounded`: theorem_missing
