# Verity Task Summary

- group: `lagoon/guardrails`
- suite: `active`
- tasks: `3`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `lagoon/guardrails/exact_compliance`

- theorem: `Benchmark.Cases.Lagoon.Guardrails.guardrails_exact_compliance`
- target module: `Benchmark.Generated.Lagoon.Guardrails.Tasks.ExactCompliance`
- editable files: `Benchmark/Generated/Lagoon/Guardrails/Tasks/ExactCompliance.lean`
- implementation files: `cases/lagoon/guardrails/verity/Contract.lean, Benchmark/Cases/Lagoon/Guardrails/Contract.lean`
- specification files: `cases/lagoon/guardrails/verity/Specs.lean, Benchmark/Cases/Lagoon/Guardrails/Specs.lean`

### Relevant Symbols

- `cases/lagoon/guardrails/verity/Contract.lean`: def ONE_YEAR : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def SCALE : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def INT256_MIN : Int
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256Nat (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256NegativeMagnitude (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def lowerRateNotMin (lowerRate : Verity.Core.Int256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def uint256Nat (value : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def scaleToOneYearNat (timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsIncreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsDecreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def increaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def decreaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def positiveBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def negativeBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def isCompliant
- `cases/lagoon/guardrails/verity/Specs.lean`: def successfulSolidityArithmeticScope
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedPpsVariation
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedVariationInsideGuardrails
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationUpperOnlySpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def nonnegativeLowerRejectsDecreaseSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def negativeVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def exactComplianceSpec

### Current Editable File

`Benchmark/Generated/Lagoon/Guardrails/Tasks/ExactCompliance.lean`

```lean
import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem exact_compliance_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    exactComplianceSpec currentPps nextPps timePast upperRate lowerRate := by
  exact ?_

end Benchmark.Generated.Lagoon.Guardrails.Tasks
```

## Task 2: `lagoon/guardrails/negative_variation_bounded`

- theorem: `Benchmark.Cases.Lagoon.Guardrails.guardrails_negative_bounded`
- target module: `Benchmark.Generated.Lagoon.Guardrails.Tasks.NegativeVariationBounded`
- editable files: `Benchmark/Generated/Lagoon/Guardrails/Tasks/NegativeVariationBounded.lean`
- implementation files: `cases/lagoon/guardrails/verity/Contract.lean, Benchmark/Cases/Lagoon/Guardrails/Contract.lean`
- specification files: `cases/lagoon/guardrails/verity/Specs.lean, Benchmark/Cases/Lagoon/Guardrails/Specs.lean`

### Relevant Symbols

- `cases/lagoon/guardrails/verity/Contract.lean`: def ONE_YEAR : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def SCALE : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def INT256_MIN : Int
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256Nat (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256NegativeMagnitude (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def lowerRateNotMin (lowerRate : Verity.Core.Int256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def uint256Nat (value : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def scaleToOneYearNat (timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsIncreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsDecreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def increaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def decreaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def positiveBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def negativeBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def isCompliant
- `cases/lagoon/guardrails/verity/Specs.lean`: def successfulSolidityArithmeticScope
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedPpsVariation
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedVariationInsideGuardrails
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationUpperOnlySpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def nonnegativeLowerRejectsDecreaseSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def negativeVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def exactComplianceSpec

### Current Editable File

`Benchmark/Generated/Lagoon/Guardrails/Tasks/NegativeVariationBounded.lean`

```lean
import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem negative_variation_bounded_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    negativeVariationBoundedSpec currentPps nextPps timePast upperRate lowerRate := by
  exact ?_

end Benchmark.Generated.Lagoon.Guardrails.Tasks
```

## Task 3: `lagoon/guardrails/positive_variation_bounded`

- theorem: `Benchmark.Cases.Lagoon.Guardrails.guardrails_positive_bounded`
- target module: `Benchmark.Generated.Lagoon.Guardrails.Tasks.PositiveVariationBounded`
- editable files: `Benchmark/Generated/Lagoon/Guardrails/Tasks/PositiveVariationBounded.lean`
- implementation files: `cases/lagoon/guardrails/verity/Contract.lean, Benchmark/Cases/Lagoon/Guardrails/Contract.lean`
- specification files: `cases/lagoon/guardrails/verity/Specs.lean, Benchmark/Cases/Lagoon/Guardrails/Specs.lean`

### Relevant Symbols

- `cases/lagoon/guardrails/verity/Contract.lean`: def ONE_YEAR : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def SCALE : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def INT256_MIN : Int
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256Nat (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def int256NegativeMagnitude (rate : Verity.Core.Int256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def lowerRateNotMin (lowerRate : Verity.Core.Int256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def uint256Nat (value : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def scaleToOneYearNat (timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsIncreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def ppsDecreaseVariationNat (currentPps nextPps timePast : Uint256) : Nat
- `cases/lagoon/guardrails/verity/Contract.lean`: def increaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def decreaseVariationArithmeticSafe (currentPps nextPps timePast : Uint256) : Prop
- `cases/lagoon/guardrails/verity/Contract.lean`: def positiveBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def negativeBranchCompliant
- `cases/lagoon/guardrails/verity/Contract.lean`: def isCompliant
- `cases/lagoon/guardrails/verity/Specs.lean`: def successfulSolidityArithmeticScope
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedPpsVariation
- `cases/lagoon/guardrails/verity/Specs.lean`: def annualizedVariationInsideGuardrails
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationUpperOnlySpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def positiveVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def nonnegativeLowerRejectsDecreaseSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def negativeVariationBoundedSpec
- `cases/lagoon/guardrails/verity/Specs.lean`: def exactComplianceSpec

### Current Editable File

`Benchmark/Generated/Lagoon/Guardrails/Tasks/PositiveVariationBounded.lean`

```lean
import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem positive_variation_bounded_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    positiveVariationBoundedSpec currentPps nextPps timePast upperRate lowerRate := by
  exact ?_

end Benchmark.Generated.Lagoon.Guardrails.Tasks
```
