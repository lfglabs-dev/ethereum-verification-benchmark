# Run 20260809T093404-default-fair-zai-glm-4-7-ethereum__deposit_contract_minimal__deposit_count

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: ethereum/deposit_contract_minimal
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `ethereum/deposit_contract_minimal/deposit_count`: verifier_infra_error
