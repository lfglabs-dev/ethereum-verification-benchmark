# Run 20260809T081226-default-fair-zai-glm-5-2-1inch__xycswap_curve_safety__quote_exact_in_curve_safety

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: 1inch/xycswap_curve_safety
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `1inch/xycswap_curve_safety/quote_exact_in_curve_safety`: verifier_infra_error
