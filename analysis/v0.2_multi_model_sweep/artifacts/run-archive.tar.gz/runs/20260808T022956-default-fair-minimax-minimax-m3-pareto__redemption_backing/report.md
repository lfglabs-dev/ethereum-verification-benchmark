# Run 20260808T022956-default-fair-minimax-minimax-m3-pareto__redemption_backing

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: pareto/redemption_backing
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `pareto/redemption_backing/deposit_funds_preserves_closed_epoch_reserve_guard`: lean_check_failed
