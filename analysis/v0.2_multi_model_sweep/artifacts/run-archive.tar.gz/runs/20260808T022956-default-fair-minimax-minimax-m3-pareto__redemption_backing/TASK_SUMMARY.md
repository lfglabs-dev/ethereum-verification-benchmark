# Verity Task Summary

- group: `pareto/redemption_backing`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `pareto/redemption_backing/deposit_funds_preserves_closed_epoch_reserve_guard`

- theorem: `Benchmark.Cases.Pareto.RedemptionBacking.depositFunds_preserves_closed_epoch_reserve_guard`
- target module: `Benchmark.Generated.Pareto.RedemptionBacking.Tasks.DepositFundsPreservesClosedEpochReserveGuard`
- editable files: `Benchmark/Generated/Pareto/RedemptionBacking/Tasks/DepositFundsPreservesClosedEpochReserveGuard.lean`
- implementation files: `cases/pareto/redemption_backing/verity/Contract.lean, Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`
- specification files: `cases/pareto/redemption_backing/verity/Specs.lean, Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage idleCollateralScaled : Uint256 := slot 0
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage totCreditVaultsRequestedScaled : Uint256 := slot 1
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage totReservedWithdrawals : Uint256 := slot 2
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage currentEpochPending : Uint256 := slot 3
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage previousEpochPending : Uint256 := slot 4
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: storage collateralizedFlag : Uint256 := slot 5
- `Benchmark/Cases/Pareto/RedemptionBacking/Contract.lean`: Benchmark.Cases.Pareto.RedemptionBacking.function depositFunds (depositedScaled : Uint256) : Unit := do
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def idleCollateralScaledOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def totCreditVaultsRequestedScaledOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def totReservedWithdrawalsOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def currentEpochPendingOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def previousEpochPendingOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def collateralizedFlagOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def idleCollateralScaled (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def totCreditVaultsRequestedScaled (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def closedClaims (s : ContractState) : Uint256
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def closed_epoch_reserve_guard (s : ContractState) : Prop
- `Benchmark/Cases/Pareto/RedemptionBacking/Specs.lean`: def depositFunds_preserves_closed_epoch_reserve_guard_spec

### Current Editable File

`Benchmark/Generated/Pareto/RedemptionBacking/Tasks/DepositFundsPreservesClosedEpochReserveGuard.lean`

```lean
import Benchmark.Cases.Pareto.RedemptionBacking.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Pareto.RedemptionBacking

open Verity
open Verity.EVM.Uint256

theorem depositFunds_preserves_closed_epoch_reserve_guard
    (depositedScaled : Uint256) (s : ContractState)
    (hCollateralized : s.storage 5 != 0)
    (hDepositLeIdle : depositedScaled.val <= (s.storage 0).val)
    (hCurrentLeReserved : (s.storage 3).val <= (s.storage 2).val)
    (hAddNoOverflow :
      (sub (s.storage 0) depositedScaled).val + (s.storage 1).val <
        Verity.Core.Uint256.modulus)
    (hReserveGuard :
      (sub (s.storage 2) (s.storage 3)).val <=
        (add (sub (s.storage 0) depositedScaled) (s.storage 1)).val) :
    let s' := ((ParetoDollarQueue.depositFunds depositedScaled).run s).snd
    depositFunds_preserves_closed_epoch_reserve_guard_spec s s' := by
  exact ?_

end Benchmark.Cases.Pareto.RedemptionBacking
```
