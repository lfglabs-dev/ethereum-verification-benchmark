import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem redeem_preserves_pps_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    redeem_preserves_pps_spec amountShares feeRate s m := by
  unfold redeem_preserves_pps_spec validRedeemInput ppsCrossNondecreasing redeem redeemPayout convertToAssets
    intro h
    rcases h with ⟨hm, hsh, hfee, hfs, hp⟩
    simp only
    have hnet : amountShares - feeShares amountShares feeRate ≤ amountShares := Nat.sub_le _ _
    have hdiv :
        ((amountShares - feeShares amountShares feeRate) * (s.assets + 1) /
            (s.shares + m)) * (s.shares + m) ≤
          (amountShares - feeShares amountShares feeRate) * (s.assets + 1) := by
      exact Nat.div_mul_le_self _ _
    have hprod :
        ((amountShares - feeShares amountShares feeRate) * (s.assets + 1) /
            (s.shares + m)) * (s.shares + m) ≤
          (s.assets + 1) * amountShares := by
      calc
        ((amountShares - feeShares amountShares feeRate) * (s.assets + 1) /
            (s.shares + m)) * (s.shares + m) ≤
            (amountShares - feeShares amountShares feeRate) * (s.assets + 1) := hdiv
        _ ≤ amountShares * (s.assets + 1) := Nat.mul_le_mul_right _ hnet
        _ = (s.assets + 1) * amountShares := Nat.mul_comm _ _
    rw [show s.assets - (amountShares - feeShares amountShares feeRate) * (s.assets + 1) / (s.shares + m) + 1 =
        s.assets + 1 - (amountShares - feeShares amountShares feeRate) * (s.assets + 1) / (s.shares + m) by omega]
    rw [show s.shares - amountShares + m = s.shares + m - amountShares by omega]
    calc
      (s.assets + 1 - (amountShares - feeShares amountShares feeRate) * (s.assets + 1) / (s.shares + m)) * (s.shares + m) =
          (s.assets + 1) * (s.shares + m) -
            ((amountShares - feeShares amountShares feeRate) * (s.assets + 1) / (s.shares + m)) * (s.shares + m) := Nat.sub_mul _ _ _
      _ ≥ (s.assets + 1) * (s.shares + m) - (s.assets + 1) * amountShares := Nat.sub_le_sub_left hprod _
      _ = (s.assets + 1) * (s.shares + m - amountShares) := (Nat.mul_sub_left_distrib _ _ _).symm

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

