# Run 20260807T234658-default-fair-minimax-minimax-m3-cork__pool_solvency

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: cork/pool_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `cork/pool_solvency/solvency_preserved`: lean_check_failed
