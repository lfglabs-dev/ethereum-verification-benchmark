# Verity Task Summary

- group: `cork/pool_solvency`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `cork/pool_solvency/solvency_preserved`

- theorem: `Benchmark.Cases.Cork.PoolSolvency.solvency_preserved`
- target module: `Benchmark.Generated.Cork.PoolSolvency.Tasks.SolvencyPreserved`
- editable files: `Benchmark/Generated/Cork/PoolSolvency/Tasks/SolvencyPreserved.lean`
- implementation files: `cases/cork/pool_solvency/verity/Contract.lean, Benchmark/Cases/Cork/PoolSolvency/Contract.lean`
- specification files: `cases/cork/pool_solvency/verity/Specs.lean, Benchmark/Cases/Cork/PoolSolvency/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: def calculateEqualSwapAmount (referenceAsset swapRate : Uint256) : Uint256
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: def tokenNativeDecimalsToFixed (amount refScaleUp : Uint256) : Uint256
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: def normalizeDecimalsWithCeilDiv (amountFixed colScaleUp : Uint256) : Uint256
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: def mulDivCeil (a b c : Uint256) : Uint256
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage collateralAssetLocked : Uint256 := slot 0
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage swapTotalSupply : Uint256 := slot 1
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage swapBalanceOfPool : Uint256 := slot 2
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage swapRate : Uint256 := slot 3
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage refScaleUp : Uint256 := slot 4
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: storage colScaleUp : Uint256 := slot 5
- `Benchmark/Cases/Cork/PoolSolvency/Contract.lean`: Benchmark.Cases.Cork.PoolSolvency.function unwindExerciseOther (referenceAssetsOut : Uint256) : Uint256 := do
- `Benchmark/Cases/Cork/PoolSolvency/Specs.lean`: def solvency_preserved_spec

### Current Editable File

`Benchmark/Generated/Cork/PoolSolvency/Tasks/SolvencyPreserved.lean`

```lean
import Benchmark.Cases.Cork.PoolSolvency.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Cork.PoolSolvency

open Verity
open Verity.EVM.Uint256

/--
Certora P-02: Solvency preserved by unwindExerciseOther.
After executing unwindExerciseOther, locked collateral normalized to 18 decimals
still covers the outstanding swap share supply:

  collateralAssetLocked' * colScaleUp >= swapTotalSupply - swapBalanceOfPool'

The proof requires showing that the ceiling-rounded collateral added
(assetsInWithoutFee * colScaleUp) is at least the floor-rounded shares released
(cstSharesOut), which follows from the ceilDiv sandwich bound and the
monotonicity of ceiling division under multiplication.

Hypotheses encode:
- Pre-condition: solvency holds before the call
- Scale factors are positive (decimals <= 18)
- Swap rate is positive
- No overflow in intermediate computations
-/
theorem solvency_preserved
    (s : ContractState)
    (referenceAssetsOut : Uint256)
    -- Pre-condition: solvency holds before the call
    (hSolvencyBefore : mul (s.storage 0) (s.storage 5) ≥ sub (s.storage 1) (s.storage 2))
    -- colScaleUp > 0 (collateralDecimals <= 18)
    (hColScale : s.storage 5 > 0)
    -- refScaleUp > 0 (referenceDecimals <= 18)
    (hRefScale : s.storage 4 > 0)
    -- swapRate > 0
    (hSwapRate : s.storage 3 > 0)
    -- referenceAssetsOut > 0
    (hRefOut : referenceAssetsOut > 0)
    -- No overflow: referenceAssetsOut * refScaleUp
    (hNoOvf1 : referenceAssetsOut.val * (s.storage 4).val < modulus)
    -- No overflow: refFixed * swapRate
    (hNoOvf2 : (referenceAssetsOut.val * (s.storage 4).val) * (s.storage 3).val < modulus)
    -- No overflow: normalizedReferenceAsset * swapRate
    (hNoOvf3 : let refFixed := referenceAssetsOut.val * (s.storage 4).val
               let normalizedReferenceAsset := if refFixed = 0 then 0
                 else (refFixed - 1) / (s.storage 5).val + 1
               normalizedReferenceAsset * (s.storage 3).val < modulus)
    -- No overflow: collateralAssetLocked + assetsInWithoutFee
    (hNoOvf4 : let refFixed := referenceAssetsOut.val * (s.storage 4).val
               let normalizedReferenceAsset := if refFixed = 0 then 0
                 else (refFixed - 1) / (s.storage 5).val + 1
               let assetProduct := normalizedReferenceAsset * (s.storage 3).val
               let assetsInWithoutFee := if assetProduct = 0 then 0
                 else (assetProduct - 1) / 1000000000000000000 + 1
               (s.storage 0).val + assetsInWithoutFee < modulus)
    -- No overflow: (collateralAssetLocked + assetsInWithoutFee) * colScaleUp
    (hNoOvf5 : let refFixed := referenceAssetsOut.val * (s.storage 4).val
               let normalizedReferenceAsset := if refFixed = 0 then 0
                 else (refFixed - 1) / (s.storage 5).val + 1
               let assetProduct := normalizedReferenceAsset * (s.storage 3).val
               let assetsInWithoutFee := if assetProduct = 0 then 0
                 else (assetProduct - 1) / 1000000000000000000 + 1
               ((s.storage 0).val + assetsInWithoutFee) * (s.storage 5).val < modulus)
    -- swapTotalSupply >= swapBalanceOfPool (outstanding shares non-negative)
    (hSupplyGeBal : s.storage 1 ≥ s.storage 2) :
    let s' := ((CorkUnwindExerciseOther.unwindExerciseOther referenceAssetsOut).run s).snd
    solvency_preserved_spec s s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Cork.PoolSolvency
```
