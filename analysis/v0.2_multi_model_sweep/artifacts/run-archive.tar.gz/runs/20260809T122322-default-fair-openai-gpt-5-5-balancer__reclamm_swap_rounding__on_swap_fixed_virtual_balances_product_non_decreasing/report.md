# Run 20260809T122322-default-fair-openai-gpt-5-5-balancer__reclamm_swap_rounding__on_swap_fixed_virtual_balances_product_non_decreasing

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: balancer/reclamm_swap_rounding
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `balancer/reclamm_swap_rounding/on_swap_fixed_virtual_balances_product_non_decreasing`: forbidden_placeholder
