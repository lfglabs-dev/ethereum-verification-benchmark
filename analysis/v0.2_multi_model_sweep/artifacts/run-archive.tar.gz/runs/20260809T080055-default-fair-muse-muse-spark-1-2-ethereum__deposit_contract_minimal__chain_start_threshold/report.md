# Run 20260809T080055-default-fair-muse-muse-spark-1-2-ethereum__deposit_contract_minimal__chain_start_threshold

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: ethereum/deposit_contract_minimal
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"provider_setup_error": 1}

## Targets

- `ethereum/deposit_contract_minimal/chain_start_threshold`: verifier_infra_error
