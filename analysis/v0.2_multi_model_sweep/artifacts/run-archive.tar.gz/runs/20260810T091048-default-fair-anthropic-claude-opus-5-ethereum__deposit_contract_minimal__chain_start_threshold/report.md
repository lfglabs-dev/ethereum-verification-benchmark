# Run 20260810T091048-default-fair-anthropic-claude-opus-5-ethereum__deposit_contract_minimal__chain_start_threshold

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: ethereum/deposit_contract_minimal
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `ethereum/deposit_contract_minimal/chain_start_threshold`: forbidden_placeholder
