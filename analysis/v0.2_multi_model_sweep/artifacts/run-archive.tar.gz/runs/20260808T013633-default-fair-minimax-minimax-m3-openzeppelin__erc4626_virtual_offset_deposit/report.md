# Run 20260808T013633-default-fair-minimax-minimax-m3-openzeppelin__erc4626_virtual_offset_deposit

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: openzeppelin/erc4626_virtual_offset_deposit
- score: 0 / 6 points
- targets: 0 / 6 passed
- failure taxonomy: {"max_attempts_exceeded": 5, "repetition_loop": 1}

## Targets

- `openzeppelin/erc4626_virtual_offset_deposit/deposit_redeem_round_trip_bound`: lean_check_failed
- `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_assets`: lean_check_failed
- `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_shares`: lean_check_failed
- `openzeppelin/erc4626_virtual_offset_deposit/positive_deposit_mints_positive_shares_under_rate_bound`: lean_check_failed
- `openzeppelin/erc4626_virtual_offset_deposit/preview_deposit_rounds_down`: lean_check_failed
- `openzeppelin/erc4626_virtual_offset_deposit/share_price_monotone_under_donation`: lean_check_failed
