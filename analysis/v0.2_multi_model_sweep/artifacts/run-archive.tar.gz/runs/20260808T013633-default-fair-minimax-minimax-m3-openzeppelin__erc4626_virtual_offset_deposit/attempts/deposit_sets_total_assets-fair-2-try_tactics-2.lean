import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256

/--
Executing `deposit` stores `oldTotalAssets + assets` in `totalAssets`.
-/
theorem deposit_sets_totalAssets
    (assets : Uint256) (s : ContractState) :
    let s' := ((ERC4626VirtualOffsetDeposit.deposit assets).run s).snd
    deposit_sets_totalAssets_spec assets s s' := by
  unfold deposit_sets_totalAssets_spec ERC4626VirtualOffsetDeposit.deposit; simp [Verity.run, Contract.run, ContractResult.snd, getStorage, setStorage, Verity.bind, Bind.bind, Verity.pure, Pure.pure, Verity.require]

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

