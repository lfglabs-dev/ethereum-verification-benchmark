# Verity Task Summary

- group: `openzeppelin/erc4626_virtual_offset_deposit`
- suite: `active`
- tasks: `6`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `openzeppelin/erc4626_virtual_offset_deposit/deposit_redeem_round_trip_bound`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.deposit_redeem_round_trip_bound`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.DepositRedeemRoundTripBound`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositRedeemRoundTripBound.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositRedeemRoundTripBound.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Verity.Stdlib.Math
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256
open Verity.Stdlib.Math

/--
Depositing `assets` and immediately redeeming the minted shares never returns
more than `assets`, and the round-trip loss is bounded by one share's asset
value rounded up (`oneShareAssetsUp`). Both conversions round down under the
virtual-offset rule, so the bound follows from a floor/ceil rounding sandwich
over the two chained integer divisions.
-/
theorem deposit_redeem_round_trip_bound
    (assets : Uint256) (s : ContractState)
    (hAssetsDenom : add (s.storage 0) virtualAssets ≠ 0)
    (hSharesDenom : add (s.storage 1) virtualShares ≠ 0)
    (hMul : (assets : Nat) * ((add (s.storage 1) virtualShares : Uint256) : Nat)
      <= MAX_UINT256) :
    deposit_redeem_round_trip_bound_spec assets s := by
  -- Grindset-first skeleton. See harness/PROOF_PATTERNS.md.
  -- Try `grind` with contract symbol hints; fall back to `simp` /
  -- `by_cases` if grind leaves goals. Use `grind?` for hints.
  unfold deposit_redeem_round_trip_bound_spec
  grind

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```

## Task 2: `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_assets`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.deposit_sets_totalAssets`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.DepositSetsTotalAssets`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalAssets.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalAssets.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256

/--
Executing `deposit` stores `oldTotalAssets + assets` in `totalAssets`.
-/
theorem deposit_sets_totalAssets
    (assets : Uint256) (s : ContractState) :
    let s' := ((ERC4626VirtualOffsetDeposit.deposit assets).run s).snd
    deposit_sets_totalAssets_spec assets s s' := by
  exact ?_

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```

## Task 3: `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_shares`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.deposit_sets_totalShares`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.DepositSetsTotalShares`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalShares.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalShares.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256

/--
Executing `deposit` stores `oldTotalShares + previewDeposit(assets)` in `totalShares`.
-/
theorem deposit_sets_totalShares
    (assets : Uint256) (s : ContractState) :
    let s' := ((ERC4626VirtualOffsetDeposit.deposit assets).run s).snd
    deposit_sets_totalShares_spec assets s s' := by
  exact ?_

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```

## Task 4: `openzeppelin/erc4626_virtual_offset_deposit/positive_deposit_mints_positive_shares_under_rate_bound`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.positive_deposit_mints_positive_shares_under_rate_bound`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.PositiveDepositMintsPositiveSharesUnderRateBound`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/PositiveDepositMintsPositiveSharesUnderRateBound.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/PositiveDepositMintsPositiveSharesUnderRateBound.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Verity.Stdlib.Math
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256
open Verity.Stdlib.Math

/--
Under the rate-bound assumption that the exact numerator already reaches one full
denominator-width, a positive deposit mints a positive number of shares.
-/
theorem positive_deposit_mints_positive_shares_under_rate_bound
    (assets : Uint256) (s : ContractState)
    (hAssets : assets ≠ 0)
    (hDenom : add (s.storage 0) virtualAssets ≠ 0)
    (hRate : ((add (s.storage 0) virtualAssets : Uint256) : Nat)
      <= (assets : Nat) * ((add (s.storage 1) virtualShares : Uint256) : Nat))
    (hMul : (assets : Nat) * ((add (s.storage 1) virtualShares : Uint256) : Nat) <= MAX_UINT256) :
    positive_deposit_mints_positive_shares_under_rate_bound_spec assets s := by
  exact ?_

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```

## Task 5: `openzeppelin/erc4626_virtual_offset_deposit/preview_deposit_rounds_down`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.previewDeposit_rounds_down`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.PreviewDepositRoundsDown`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/PreviewDepositRoundsDown.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/PreviewDepositRoundsDown.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Verity.Stdlib.Math
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256
open Verity.Stdlib.Math

/--
`previewDeposit` rounds down, so the minted share estimate times the denominator
never exceeds the exact numerator product when the multiplication is exact.
-/
theorem previewDeposit_rounds_down
    (assets : Uint256) (s : ContractState)
    (hMul : (assets : Nat) * ((add (s.storage 1) virtualShares : Uint256) : Nat) <= MAX_UINT256) :
    previewDeposit_rounds_down_spec assets s := by
  exact ?_

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```

## Task 6: `openzeppelin/erc4626_virtual_offset_deposit/share_price_monotone_under_donation`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.share_price_monotone_under_donation`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.SharePriceMonotoneUnderDonation`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/SharePriceMonotoneUnderDonation.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/SharePriceMonotoneUnderDonation.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Verity.Stdlib.Math
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256
open Verity.Stdlib.Math

/--
A direct asset donation to the vault never decreases the assets an existing
holder can redeem for a fixed share amount: under the virtual-offset rule the
assets-per-share rate seen through `previewRedeem` is monotone in donations,
given decimal-offset no-overflow hypotheses on the offset denominator, the
donated total, and the conversion product.
-/
theorem share_price_monotone_under_donation
    (shares donation : Uint256) (s : ContractState)
    (_hOffsetShares : ((s.storage 1 : Uint256) : Nat) + (virtualShares : Nat)
      <= MAX_UINT256)
    (hDonation : ((s.storage 0 : Uint256) : Nat) + (donation : Nat) + (virtualAssets : Nat)
      <= MAX_UINT256)
    (hMul : (shares : Nat)
      * (((s.storage 0 : Uint256) : Nat) + (donation : Nat) + (virtualAssets : Nat))
      <= MAX_UINT256) :
    share_price_monotone_under_donation_spec shares donation s := by
  -- Grindset-first skeleton. See harness/PROOF_PATTERNS.md.
  -- Try `grind` with contract symbol hints; fall back to `simp` /
  -- `by_cases` if grind leaves goals. Use `grind?` for hints.
  unfold share_price_monotone_under_donation_spec
  grind

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```
