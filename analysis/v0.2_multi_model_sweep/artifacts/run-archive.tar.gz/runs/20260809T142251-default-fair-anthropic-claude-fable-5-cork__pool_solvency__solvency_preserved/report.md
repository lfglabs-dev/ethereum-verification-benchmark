# Run 20260809T142251-default-fair-anthropic-claude-fable-5-cork__pool_solvency__solvency_preserved

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: cork/pool_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `cork/pool_solvency/solvency_preserved`: forbidden_placeholder
