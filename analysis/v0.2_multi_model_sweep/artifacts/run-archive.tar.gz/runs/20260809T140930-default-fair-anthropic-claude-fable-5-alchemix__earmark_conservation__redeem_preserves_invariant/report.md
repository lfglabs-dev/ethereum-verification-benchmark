# Run 20260809T140930-default-fair-anthropic-claude-fable-5-alchemix__earmark_conservation__redeem_preserves_invariant

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: alchemix/earmark_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `alchemix/earmark_conservation/redeem_preserves_invariant`: forbidden_placeholder
