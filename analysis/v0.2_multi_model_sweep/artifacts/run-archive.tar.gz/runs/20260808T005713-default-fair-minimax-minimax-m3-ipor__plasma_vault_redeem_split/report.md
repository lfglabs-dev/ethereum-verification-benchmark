# Run 20260808T005713-default-fair-minimax-minimax-m3-ipor__plasma_vault_redeem_split

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: ipor/plasma_vault_redeem_split
- score: 0 / 2 points
- targets: 0 / 2 passed
- failure taxonomy: {"max_attempts_exceeded": 2}

## Targets

- `ipor/plasma_vault_redeem_split/fee_payout_bounded_by_fee_free`: theorem_missing
- `ipor/plasma_vault_redeem_split/redeem_preserves_pps`: theorem_missing
