import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem redeem_preserves_pps_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    redeem_preserves_pps_spec amountShares feeRate s m := by
  intro h
  unfold validRedeemInput at h
  unfold ppsCrossNondecreasing redeem redeemPayout feeShares convertToAssets getStorage setStorage Verity.require Verity.bind Bind.bind Verity.pure Pure.pure Contract.run ContractResult.snd
  simp only []
  omega

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

