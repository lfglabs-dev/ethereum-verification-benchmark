# Run 20260809T024422-default-fair-anthropic-claude-opus-5-balancer__reclamm_swap_rounding__on_swap_fixed_virtual_balances_product_non_decreasing

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: balancer/reclamm_swap_rounding
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `balancer/reclamm_swap_rounding/on_swap_fixed_virtual_balances_product_non_decreasing`: forbidden_placeholder
