# Verity Task Summary

- group: `usual/dao_collateral`
- suite: `active`
- tasks: `5`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `usual/dao_collateral/redeem_conservation`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.redeem_conservation`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.RedeemConservation`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemConservation.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemConservation.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
Direct redeem burns the user USD0 amount, remints only the explicit non-CBR fee,
and debits exactly the collateral returned under oracle, fee, CBR, and rounding.
-/
theorem redeem_conservation
    (rwaToken : Address) (stableAmount minAmountOut price tokenUnit : Uint256)
    (s : ContractState)
    (hAmount : stableAmount != 0)
    (hPrice : price != 0)
    (hTokenUnit : tokenUnit != 0)
    (hReturnedNonzero :
      expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
        (cbrCoefOf s) (isCBROnState s) ≠ 0)
    (hMin :
      minAmountOut.val ≤
        (expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
          (cbrCoefOf s) (isCBROnState s)).val)
    (hArithmetic :
      successfulRedeemArithmetic rwaToken stableAmount price tokenUnit s) :
    let s' := ((DaoCollateral.redeemDirect rwaToken stableAmount minAmountOut price tokenUnit).run s).snd
    redeem_conservation_spec rwaToken stableAmount price tokenUnit s s' := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```

## Task 2: `usual/dao_collateral/redeem_fee_formula`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.redeem_fee_formula`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.RedeemFeeFormula`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemFeeFormula.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemFeeFormula.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
The redeem fee is the configured basis-point fee, normalized through collateral
token precision when token decimals are below USD0's 18 decimals.
-/
theorem redeem_fee_formula
    (stableAmount tokenUnit : Uint256) (s : ContractState) :
    redeem_fee_formula_spec stableAmount tokenUnit s := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```

## Task 3: `usual/dao_collateral/redeem_return_formula`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.redeem_return_formula`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.RedeemReturnFormula`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemReturnFormula.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemReturnFormula.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
The redeem return value is the modeled floor-rounded oracle conversion, with CBR
coefficient applied when active.
-/
theorem redeem_return_formula
    (stableAmount minAmountOut price tokenUnit : Uint256) (rwaToken : Address)
    (s : ContractState)
    (hAmount : stableAmount != 0)
    (hPrice : price != 0)
    (hTokenUnit : tokenUnit != 0)
    (hReturnedNonzero :
      expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
        (cbrCoefOf s) (isCBROnState s) ≠ 0)
    (hMin :
      minAmountOut.val ≤
        (expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
          (cbrCoefOf s) (isCBROnState s)).val)
    (hArithmetic :
      successfulRedeemArithmetic rwaToken stableAmount price tokenUnit s) :
    let result := (DaoCollateral.redeemDirect rwaToken stableAmount minAmountOut price tokenUnit).run s
    redeem_return_formula_spec result.fst stableAmount price tokenUnit s := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```

## Task 4: `usual/dao_collateral/swap_conservation`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.swap_conservation`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.SwapConservation`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/SwapConservation.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/SwapConservation.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
Direct swap computes the oracle USD quote from explicit price and supported
token-unit inputs, then mints exactly that quote and credits exactly the RWA
collateral amount in the modeled treasury ledger.
-/
theorem swap_conservation
    (rwaToken : Address) (amount minAmountOut price tokenUnit : Uint256) (s : ContractState)
    (hAmount : amount != 0)
    (hMin : expectedSwapUsdQuote amount price tokenUnit >= minAmountOut)
    (hArithmetic : successfulSwapArithmetic rwaToken amount price tokenUnit s) :
    let s' := ((DaoCollateral.swapDirect rwaToken amount minAmountOut price tokenUnit).run s).snd
    swap_conservation_spec rwaToken amount price tokenUnit s s' := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```

## Task 5: `usual/dao_collateral/swap_value_conservation`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.swap_value_conservation`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.SwapValueConservation`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/SwapValueConservation.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/SwapValueConservation.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
The direct swap model computes the oracle quote internally from explicit price
and supported token-unit inputs, so the value-conservation spec no longer
depends on a free quote parameter.
-/
theorem swap_value_conservation
    (rwaToken : Address) (amount minAmountOut price tokenUnit : Uint256)
    (s : ContractState)
    (hAmount : amount != 0)
    (hMin : expectedSwapUsdQuote amount price tokenUnit >= minAmountOut)
    (hArithmetic : successfulSwapArithmetic rwaToken amount price tokenUnit s) :
    let s' := ((DaoCollateral.swapDirect rwaToken amount minAmountOut price tokenUnit).run s).snd
    swap_value_conservation_spec rwaToken amount price tokenUnit s s' := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```
