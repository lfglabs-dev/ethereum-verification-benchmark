import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
The redeem fee is the configured basis-point fee, normalized through collateral
token precision when token decimals are below USD0's 18 decimals.
-/
theorem redeem_fee_formula
    (stableAmount tokenUnit : Uint256) (s : ContractState) :
    redeem_fee_formula_spec stableAmount tokenUnit s := by
  unfold redeem_fee_formula_spec feeUsd0 expectedFeeUsd0 redeemFeeAmount floorMulDiv
  simp [grind_norm, *]
  all_goals try (split_ifs <;> simp_all [grind_norm])
  all_goals try (repeat' (split <;> simp_all [grind_norm]))

end Benchmark.Cases.Usual.DaoCollateral

