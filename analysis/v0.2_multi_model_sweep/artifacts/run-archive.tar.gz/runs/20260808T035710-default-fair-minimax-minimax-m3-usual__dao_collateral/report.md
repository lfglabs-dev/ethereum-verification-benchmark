# Run 20260808T035710-default-fair-minimax-minimax-m3-usual__dao_collateral

- harness: default
- track: group/lean_tools
- run mode: group
- harness mode: fair
- group: usual/dao_collateral
- score: 1 / 5 points
- targets: 1 / 5 passed
- failure taxonomy: {"max_attempts_exceeded": 3, "repetition_loop": 1}

## Targets

- `usual/dao_collateral/redeem_conservation`: forbidden_placeholder
- `usual/dao_collateral/redeem_fee_formula`: passed
- `usual/dao_collateral/redeem_return_formula`: lean_check_failed
- `usual/dao_collateral/swap_conservation`: lean_check_failed
- `usual/dao_collateral/swap_value_conservation`: lean_check_failed
