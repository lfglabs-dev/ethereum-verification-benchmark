# Run 20260810T094651-default-fair-anthropic-claude-fable-5-damn_vulnerable_defi__side_entrance__flash_loan_via_deposit_preserves_pool_balance

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: damn_vulnerable_defi/side_entrance
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"request_failed": 1}

## Targets

- `damn_vulnerable_defi/side_entrance/flash_loan_via_deposit_preserves_pool_balance`: forbidden_placeholder
