# Run 20260811T191429-default-fair-gpt-5-6-luna-lido__vaulthub_locked__shares_conversion_monotone

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lido/vaulthub_locked
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `lido/vaulthub_locked/shares_conversion_monotone`: lean_check_failed
