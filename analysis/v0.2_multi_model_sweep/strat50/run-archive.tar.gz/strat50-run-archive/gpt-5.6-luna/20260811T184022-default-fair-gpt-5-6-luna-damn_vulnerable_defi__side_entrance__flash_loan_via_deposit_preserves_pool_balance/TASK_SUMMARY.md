# Verity Task Summary

- group: `damn_vulnerable_defi/side_entrance/flash_loan_via_deposit_preserves_pool_balance`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `damn_vulnerable_defi/side_entrance/flash_loan_via_deposit_preserves_pool_balance`

- theorem: `Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.flashLoanViaDeposit_preserves_pool_balance`
- target module: `Benchmark.Generated.DamnVulnerableDeFi.SideEntrance.Tasks.FlashLoanViaDepositPreservesPoolBalance`
- editable files: `Benchmark/Generated/DamnVulnerableDeFi/SideEntrance/Tasks/FlashLoanViaDepositPreservesPoolBalance.lean`
- implementation files: `cases/damn_vulnerable_defi/side_entrance/verity/Contract.lean, Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`
- specification files: `cases/damn_vulnerable_defi/side_entrance/verity/Specs.lean, Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: storage poolBalance : Uint256 := slot 0
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: storage totalCredits : Uint256 := slot 1
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: storage creditOf : Address → Uint256 := slot 2
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.function deposit (amount : Uint256) : Unit := do
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.function flashLoanViaDeposit (amount : Uint256) : Unit := do
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Contract.lean`: Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.function withdraw () : Uint256 := do
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`: def deposit_sets_pool_balance_spec
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`: def deposit_sets_sender_credit_spec
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`: def flashLoanViaDeposit_preserves_pool_balance_spec
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`: def flashLoanViaDeposit_sets_sender_credit_spec
- `Benchmark/Cases/DamnVulnerableDeFi/SideEntrance/Specs.lean`: def exploit_trace_drains_pool_spec

### Current Editable File

`Benchmark/Generated/DamnVulnerableDeFi/SideEntrance/Tasks/FlashLoanViaDepositPreservesPoolBalance.lean`

```lean
import Benchmark.Cases.DamnVulnerableDeFi.SideEntrance.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.DamnVulnerableDeFi.SideEntrance

open Verity
open Verity.EVM.Uint256

/--
Executing the summarized flash-loan-plus-deposit path leaves tracked pool ETH
unchanged.
-/
theorem flashLoanViaDeposit_preserves_pool_balance
    (amount : Uint256) (s : ContractState)
    (hBorrow : amount <= s.storage 0) :
    let s' := ((SideEntrance.flashLoanViaDeposit amount).run s).snd
    flashLoanViaDeposit_preserves_pool_balance_spec amount s s' := by
  sorry

end Benchmark.Cases.DamnVulnerableDeFi.SideEntrance
```
