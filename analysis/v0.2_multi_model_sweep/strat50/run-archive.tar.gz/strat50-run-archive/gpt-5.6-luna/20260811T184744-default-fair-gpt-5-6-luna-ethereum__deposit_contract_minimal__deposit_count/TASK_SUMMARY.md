# Verity Task Summary

- group: `ethereum/deposit_contract_minimal/deposit_count`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `ethereum/deposit_contract_minimal/deposit_count`

- theorem: `Benchmark.Cases.Ethereum.DepositContractMinimal.deposit_increments_deposit_count`
- target module: `Benchmark.Generated.Ethereum.DepositContractMinimal.Tasks.DepositCount`
- editable files: `Benchmark/Generated/Ethereum/DepositContractMinimal/Tasks/DepositCount.lean`
- implementation files: `cases/ethereum/deposit_contract_minimal/verity/Contract.lean, Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`
- specification files: `cases/ethereum/deposit_contract_minimal/verity/Specs.lean, Benchmark/Cases/Ethereum/DepositContractMinimal/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`: storage depositCount : Uint256 := slot 0
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`: storage fullDepositCount : Uint256 := slot 1
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`: storage chainStarted : Uint256 := slot 2
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`: Benchmark.Cases.Ethereum.DepositContractMinimal.function deposit (depositAmount : Uint256) : Unit := do
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Contract.lean`: Benchmark.Cases.Ethereum.DepositContractMinimal.function hasChainStarted () : Bool := do
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Specs.lean`: def deposit_increments_deposit_count_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Specs.lean`: def deposit_preserves_full_count_for_small_deposit_spec (depositAmount : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Specs.lean`: def deposit_increments_full_count_for_full_deposit_spec (depositAmount : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/Ethereum/DepositContractMinimal/Specs.lean`: def deposit_starts_chain_at_threshold_spec (depositAmount : Uint256) (s s' : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Ethereum/DepositContractMinimal/Tasks/DepositCount.lean`

```lean
import Benchmark.Cases.Ethereum.DepositContractMinimal.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Ethereum.DepositContractMinimal

open Verity
open Verity.EVM.Uint256

/--
Executing `deposit` on the successful path increments the total deposit counter
by exactly one.
-/
theorem deposit_increments_deposit_count
    (depositAmount : Uint256) (s : ContractState)
    (hCount : s.storage 0 < 4294967295)
    (hMin : depositAmount >= 1000000000) :
    let s' := ((DepositContractMinimal.deposit depositAmount).run s).snd
    deposit_increments_deposit_count_spec s s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Ethereum.DepositContractMinimal
```
