# Run 20260811T193906-default-fair-gpt-5-6-luna-safe__owner_manager_reach__swap_owner_in_list_reachable

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: safe/owner_manager_reach
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `safe/owner_manager_reach/swap_owner_in_list_reachable`: forbidden_placeholder
