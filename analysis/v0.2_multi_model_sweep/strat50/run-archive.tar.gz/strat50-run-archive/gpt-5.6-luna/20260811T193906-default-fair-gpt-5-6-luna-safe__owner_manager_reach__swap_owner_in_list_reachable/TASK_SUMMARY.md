# Verity Task Summary

- group: `safe/owner_manager_reach/swap_owner_in_list_reachable`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `safe/owner_manager_reach/swap_owner_in_list_reachable`

- theorem: `Benchmark.Cases.Safe.OwnerManagerReach.swapOwner_inListReachable`
- target module: `Benchmark.Generated.Safe.OwnerManagerReach.Tasks.SwapOwnerInListReachable`
- editable files: `Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerInListReachable.lean`
- implementation files: `cases/safe/owner_manager_reach/verity/Contract.lean, Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`
- specification files: `cases/safe/owner_manager_reach/verity/Specs.lean, Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: def SENTINEL : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage owners : Address → Uint256 := slot 0
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: storage ownerCount : Uint256 := slot 1
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function setupOwners (owner1 : Address, owner2 : Address, owner3 : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function addOwner (owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function removeOwner (prevOwner : Address, owner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Contract.lean`: Benchmark.Cases.Safe.OwnerManagerReach.function swapOwner (prevOwner : Address, oldOwner : Address, newOwner : Address) : Unit := do
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def next (s : ContractState) (a : Address) : Address
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def isChain (s : ContractState) : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachable (s : ContractState) (a b : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def inListReachable (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def reachableInList (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def ownerListInvariant (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noDuplicates : List Address → Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def acyclic (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def uniquePredecessor (s : ContractState) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def freshInList (s : ContractState) (addr : Address) : Prop
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def in_list_reachable_spec
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def addOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def removeOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def swapOwner_preserves_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def setupOwners_establishes_invariant
- `Benchmark/Cases/Safe/OwnerManagerReach/Specs.lean`: def noSelfLoops (s : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Safe/OwnerManagerReach/Tasks/SwapOwnerInListReachable.lean`

```lean
import Benchmark.Cases.Safe.OwnerManagerReach.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Safe.OwnerManagerReach

open Verity
open Verity.EVM.Uint256

/--
Certora `inListReachable` invariant preservation under `swapOwner`.

swapOwner atomically replaces oldOwner with newOwner in-place:
  owners[newOwner] = owners[oldOwner]
  owners[prevOwner] = newOwner
  owners[oldOwner] = 0

Proof strategy: newOwner inherits oldOwner's successor. For any key with
a non-zero successor in the post-state, its pre-state chain through
oldOwner can be adapted by replacing oldOwner with newOwner:
[... → prevOwner → oldOwner → X → ...] becomes
[... → prevOwner → newOwner → X → ...].
-/
theorem swapOwner_inListReachable
    (prevOwner oldOwner newOwner : Address) (s : ContractState)
    (hNewNotZero : (newOwner != zeroAddress) = true)
    (hNewNotSentinel : (newOwner != SENTINEL) = true)
    (hNewFresh : (wordToAddress (s.storageMap 0 newOwner) == zeroAddress) = true)
    (hOldNotZero : (oldOwner != zeroAddress) = true)
    (hOldNotSentinel : (oldOwner != SENTINEL) = true)
    (hPrevLink : (wordToAddress (s.storageMap 0 prevOwner) == oldOwner) = true)
    -- Pre-state invariant (full ownerListInvariant, not just inListReachable)
    (hPreInvFull : ownerListInvariant s)
    -- Unique predecessor: each non-zero node has at most one non-zero predecessor.
    (hUniquePred : uniquePredecessor s)
    -- prevOwner is non-zero (a valid list node)
    (hPrevNZ : prevOwner ≠ zeroAddress)
    -- Zero address maps to itself
    (hZeroInert : next s zeroAddress = zeroAddress) :
    let s' := ((OwnerManager.swapOwner prevOwner oldOwner newOwner).run s).snd
    inListReachable s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Safe.OwnerManagerReach
```
