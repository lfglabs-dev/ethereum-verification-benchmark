# Run 20260811T182517-default-fair-gpt-5-6-luna-1inch__xycswap_curve_safety__quote_exact_in_curve_safety

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: 1inch/xycswap_curve_safety
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"max_attempts_exceeded": 1}

## Targets

- `1inch/xycswap_curve_safety/quote_exact_in_curve_safety`: lean_check_failed
