# Verity Task Summary

- group: `term_finance/term_auction_clearing/clearing_assignment_correct`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `term_finance/term_auction_clearing/clearing_assignment_correct`

- theorem: `Benchmark.Cases.TermFinance.TermAuctionClearing.clearing_assignment_correct`
- target module: `Benchmark.Generated.TermFinance.TermAuctionClearing.Tasks.ClearingAssignmentCorrect`
- editable files: `Benchmark/Generated/TermFinance/TermAuctionClearing/Tasks/ClearingAssignmentCorrect.lean`
- implementation files: `cases/term_finance/term_auction_clearing/verity/Contract.lean, Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`
- specification files: `cases/term_finance/term_auction_clearing/verity/Specs.lean, Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: structure Bid where
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: structure Offer where
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def bidEligible (clearingPrice : Nat) (bid : Bid) : Prop
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def offerEligible (clearingPrice : Nat) (offer : Offer) : Prop
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def SortedAscendingBids : List Bid -> Prop
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def SortedAscendingOffers : List Offer -> Prop
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def minNat (a b : Nat) : Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def bidAmountIfEligible (clearingPrice : Nat) (bid : Bid) : Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def offerAmountIfEligible (clearingPrice : Nat) (offer : Offer) : Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def sumBidDemandAtOrAbove (clearingPrice : Nat) : List Bid -> Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def sumOfferSupplyAtOrBelow (clearingPrice : Nat) : List Offer -> Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def assignBidAmountsForward (clearingPrice maxAssignable : Nat) : List Bid -> List Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def assignBidAmounts (clearingPrice maxAssignable : Nat) (bids : List Bid) : List Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def assignOfferAmounts (clearingPrice maxAssignable : Nat) : List Offer -> List Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def sumNatList : List Nat -> Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Contract.lean`: def assignedBidPrincipal (clearingPrice maxAssignable : Nat) (bids : List Bid) : Nat
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`: def assigned_bid_rate_floor_spec
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`: def assigned_offer_rate_ceiling_spec
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`: def assigned_bid_total_spec
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`: def assigned_offer_total_spec
- `Benchmark/Cases/TermFinance/TermAuctionClearing/Specs.lean`: def clearing_assignment_correct_spec

### Current Editable File

`Benchmark/Generated/TermFinance/TermAuctionClearing/Tasks/ClearingAssignmentCorrect.lean`

```lean
import Benchmark.Cases.TermFinance.TermAuctionClearing.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.TermFinance.TermAuctionClearing

/--
For a valid TermAuction clearing point, assignment preserves the clearing-rate
guards and assigns exactly the shared `maxAssignable` purchase-token principal
on both sides.
-/
theorem clearing_assignment_correct_task
    (clearingPrice maxAssignable : Nat) (bids : List Bid) (offers : List Offer)
    (hSortedBids : SortedAscendingBids bids)
    (hSortedOffers : SortedAscendingOffers offers)
    (hCapacity : ClearingPointCapacity clearingPrice maxAssignable bids offers) :
  clearing_assignment_correct_spec clearingPrice maxAssignable bids offers := by
  exact ?_

end Benchmark.Cases.TermFinance.TermAuctionClearing
```
