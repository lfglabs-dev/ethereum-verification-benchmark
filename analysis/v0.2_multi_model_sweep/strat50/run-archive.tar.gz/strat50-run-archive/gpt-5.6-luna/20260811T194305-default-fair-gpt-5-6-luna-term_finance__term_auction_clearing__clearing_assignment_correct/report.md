# Run 20260811T194305-default-fair-gpt-5-6-luna-term_finance__term_auction_clearing__clearing_assignment_correct

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: term_finance/term_auction_clearing
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `term_finance/term_auction_clearing/clearing_assignment_correct`: theorem_missing
