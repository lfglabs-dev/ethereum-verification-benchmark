# Run 20260811T191315-default-fair-gpt-5-6-luna-lido__vaulthub_locked__max_liability_shares_bound

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lido/vaulthub_locked
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `lido/vaulthub_locked/max_liability_shares_bound`: passed
