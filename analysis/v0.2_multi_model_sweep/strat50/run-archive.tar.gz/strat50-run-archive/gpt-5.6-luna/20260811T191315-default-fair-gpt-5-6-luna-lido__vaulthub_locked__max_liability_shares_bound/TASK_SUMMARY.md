# Verity Task Summary

- group: `lido/vaulthub_locked/max_liability_shares_bound`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `lido/vaulthub_locked/max_liability_shares_bound`

- theorem: `Benchmark.Cases.Lido.VaulthubLocked.max_liability_shares_bound`
- target module: `Benchmark.Generated.Lido.VaulthubLocked.Tasks.MaxLiabilitySharesBound`
- editable files: `Benchmark/Generated/Lido/VaulthubLocked/Tasks/MaxLiabilitySharesBound.lean`
- implementation files: `cases/lido/vaulthub_locked/verity/Contract.lean, Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`
- specification files: `cases/lido/vaulthub_locked/verity/Specs.lean, Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: def TOTAL_BASIS_POINTS : Uint256
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: def ceilDiv (a b : Uint256) : Uint256
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: def getPooledEthBySharesRoundUp
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage maxLiabilityShares : Uint256 := slot 0
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage liabilityShares : Uint256 := slot 1
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage minimalReserve : Uint256 := slot 2
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage reserveRatioBP : Uint256 := slot 3
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage totalPooledEther : Uint256 := slot 4
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage totalShares : Uint256 := slot 5
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: storage lockedAmount : Uint256 := slot 6
- `Benchmark/Cases/Lido/VaulthubLocked/Contract.lean`: Benchmark.Cases.Lido.VaulthubLocked.function syncLocked () : Uint256 := do
- `Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`: def locked_funds_solvency_spec
- `Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`: def max_liability_shares_bound_spec
- `Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`: def reserve_ratio_bounds_spec
- `Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`: def ceildiv_sandwich_spec
- `Benchmark/Cases/Lido/VaulthubLocked/Specs.lean`: def shares_conversion_monotone_spec

### Current Editable File

`Benchmark/Generated/Lido/VaulthubLocked/Tasks/MaxLiabilitySharesBound.lean`

```lean
import Benchmark.Cases.Lido.VaulthubLocked.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Lido.VaulthubLocked

open Verity
open Verity.EVM.Uint256

/--
Certora P-VH-04: maxLiabilityShares >= liabilityShares.
This invariant is maintained by the VaultHub's minting and reporting logic.
-/
theorem max_liability_shares_bound
    (maxLiabilityShares liabilityShares : Uint256)
    (hBound : maxLiabilityShares ≥ liabilityShares) :
    max_liability_shares_bound_spec maxLiabilityShares liabilityShares := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Lido.VaulthubLocked
```
