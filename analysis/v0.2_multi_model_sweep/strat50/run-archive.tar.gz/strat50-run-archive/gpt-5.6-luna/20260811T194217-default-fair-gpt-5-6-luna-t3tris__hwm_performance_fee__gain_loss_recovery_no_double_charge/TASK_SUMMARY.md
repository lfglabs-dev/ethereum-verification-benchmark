# Verity Task Summary

- group: `t3tris/hwm_performance_fee/gain_loss_recovery_no_double_charge`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `t3tris/hwm_performance_fee/gain_loss_recovery_no_double_charge`

- theorem: `Benchmark.Cases.T3tris.HwmPerformanceFee.gain_loss_recovery_no_double_charge`
- target module: `Benchmark.Generated.T3tris.HwmPerformanceFee.Tasks.GainLossRecoveryNoDoubleCharge`
- editable files: `Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/GainLossRecoveryNoDoubleCharge.lean`
- implementation files: `cases/t3tris/hwm_performance_fee/verity/Contract.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`
- specification files: `cases/t3tris/hwm_performance_fee/verity/Specs.lean, Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def WAD : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def absDist (a b : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDiv (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def fullMulDivUp (x y denominator : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def computeFee (value feeWad : Nat) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure GrossTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure NetTvlData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesParams where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def noManagementFee : ManagementFeeModel where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure LastPeriodData where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: structure PeriodFeesResult where
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetSupply (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def oldTotalNetAssets (gross : GrossTvlData) (params : PeriodFeesParams) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def supplyAfterManagement (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Contract.lean`: def prePerformancePps (gross : GrossTvlData) (managementFee : ManagementFeeModel) : Nat
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulPeriodAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def successfulStepAssumptions
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_initial_state_satisfies_successful_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def validated_performance_fee_update_preserves_cap_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def period_fee_accounting_preserves_structural_assumptions_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def fee_claim_preserves_unclaimed_le_supply_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def no_performance_fee_when_pre_pps_le_hwm_spec
- `Benchmark/Cases/T3tris/HwmPerformanceFee/Specs.lean`: def profit_pnl_uses_cached_hwm_spec

### Current Editable File

`Benchmark/Generated/T3tris/HwmPerformanceFee/Tasks/GainLossRecoveryNoDoubleCharge.lean`

```lean
import Benchmark.Cases.T3tris.HwmPerformanceFee.Specs

namespace Benchmark.Cases.T3tris.HwmPerformanceFee

theorem gain_loss_recovery_no_double_charge
    (s0 : FeeState)
    (gainAssets lossAssets recoveryAssets : Nat)
    (gainManagementFee : ManagementFeeModel := noManagementFee)
    (lossManagementFee : ManagementFeeModel := noManagementFee)
    (recoveryManagementFee : ManagementFeeModel := noManagementFee) :
    gain_loss_recovery_no_double_charge_spec
      s0 gainAssets lossAssets recoveryAssets
      gainManagementFee lossManagementFee recoveryManagementFee := by
  exact ?_

end Benchmark.Cases.T3tris.HwmPerformanceFee
```
