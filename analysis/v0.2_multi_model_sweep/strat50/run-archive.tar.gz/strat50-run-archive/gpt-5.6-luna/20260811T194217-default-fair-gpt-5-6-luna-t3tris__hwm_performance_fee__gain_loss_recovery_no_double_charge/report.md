# Run 20260811T194217-default-fair-gpt-5-6-luna-t3tris__hwm_performance_fee__gain_loss_recovery_no_double_charge

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: t3tris/hwm_performance_fee
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `t3tris/hwm_performance_fee/gain_loss_recovery_no_double_charge`: forbidden_placeholder
