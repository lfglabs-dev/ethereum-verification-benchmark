# Run 20260811T195107-default-fair-gpt-5-6-luna-zama__erc7984_confidential_token__transferFrom_conservation

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: zama/erc7984_confidential_token
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `zama/erc7984_confidential_token/transferFrom_conservation`: lean_check_failed
