# Verity Task Summary

- group: `zama/erc7984_confidential_token/transferFrom_conservation`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `zama/erc7984_confidential_token/transferFrom_conservation`

- theorem: `Benchmark.Cases.Zama.ERC7984ConfidentialToken.transferFrom_conservation`
- target module: `Benchmark.Generated.Zama.ERC7984ConfidentialToken.Tasks.TransferFromConservation`
- editable files: `Benchmark/Generated/Zama/ERC7984ConfidentialToken/Tasks/TransferFromConservation.lean`
- implementation files: `cases/zama/erc7984_confidential_token/verity/Contract.lean, Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`
- specification files: `cases/zama/erc7984_confidential_token/verity/Specs.lean, Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def UINT64_MOD : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def add64 (a b : Uint256) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def sub64 (a b : Uint256) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryIncrease64SuccessWithInit (oldInit oldValue delta : Uint256) : Bool
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryIncrease64UpdatedWithInit (oldInit oldValue delta : Uint256) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryIncrease64WithInit (oldInit oldValue delta : Uint256) : Bool × Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryIncrease64 (oldValue delta : Uint256) : Bool × Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryDecrease64SuccessWithInit (oldInit oldValue delta : Uint256) : Bool
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryDecrease64UpdatedWithInit (oldInit oldValue delta : Uint256) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryDecrease64WithInit (oldInit oldValue delta : Uint256) : Bool × Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: def tryDecrease64 (oldValue delta : Uint256) : Bool × Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: storage totalSupply : Uint256 := slot 0
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: storage balances : Address → Uint256 := slot 1
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: storage balanceInitialized : Address → Uint256 := slot 2
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: storage operators : Address → Address → Uint256 := slot 3
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Contract.lean`: storage totalSupplyInitialized : Uint256 := slot 4
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def balanceOf (s : ContractState) (addr : Address) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def supply (s : ContractState) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def supplyInitialized (s : ContractState) : Uint256
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def transfer_conservation_spec
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def transfer_sufficient_spec
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def transfer_insufficient_spec
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def transfer_preserves_supply_spec
- `Benchmark/Cases/Zama/ERC7984ConfidentialToken/Specs.lean`: def mint_increases_supply_spec

### Current Editable File

`Benchmark/Generated/Zama/ERC7984ConfidentialToken/Tasks/TransferFromConservation.lean`

```lean
import Benchmark.Cases.Zama.ERC7984ConfidentialToken.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Zama.ERC7984ConfidentialToken

open Verity
open Verity.EVM.Uint256

/--
Operator-gated transferFrom preserves balance conservation.

When the caller is authorized (either `holder == msg.sender` or
`block.timestamp <= operators[holder][msg.sender]`), transferFrom
preserves the sum `balances[holder] + balances[recipient]`.

This ensures that delegating transfer authority via the operator
pattern does not allow creation or destruction of tokens.
-/
theorem transferFrom_conservation
    (holder recipient : Address) (amount blockTimestamp : Uint256)
    (s : ContractState)
    (hFrom : (holder != zeroAddress) = true)
    (hTo : (recipient != zeroAddress) = true)
    (hInit : s.storageMap 2 holder ≠ 0)
    (hDistinct : holder ≠ recipient)
    (hAuthorized :
      holder == s.sender ∨ blockTimestamp <= s.storageMap2 3 holder s.sender)
    (hAmount64 : amount < UINT64_MOD)
    (hHolderBal64 : s.storageMap 1 holder < UINT64_MOD)
    (hRecipientBal64 : s.storageMap 1 recipient < UINT64_MOD)
    (hToNoWrap : s.storageMap 1 recipient + amount < UINT64_MOD) :
    let s' := ((ERC7984.transferFrom holder recipient amount blockTimestamp).run s).snd
    transferFrom_conservation_spec holder recipient s s' := by
  -- Grindset-first skeleton. See harness/PROOF_PATTERNS.md.
  -- Try `grind` with contract symbol hints; fall back to `simp` /
  -- `by_cases` if grind leaves goals. Use `grind?` for hints.
  unfold transferFrom_conservation_spec
  grind [ERC7984.transferFrom, ERC7984.totalSupply, ERC7984.balances, ERC7984.balanceInitialized, ERC7984.operators, ERC7984.totalSupplyInitialized]

end Benchmark.Cases.Zama.ERC7984ConfidentialToken
```
