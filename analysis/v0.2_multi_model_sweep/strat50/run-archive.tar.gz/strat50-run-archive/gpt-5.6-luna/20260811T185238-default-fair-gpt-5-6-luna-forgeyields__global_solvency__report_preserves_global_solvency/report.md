# Run 20260811T185238-default-fair-gpt-5-6-luna-forgeyields__global_solvency__report_preserves_global_solvency

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: forgeyields/global_solvency
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `forgeyields/global_solvency/report_preserves_global_solvency`: passed
