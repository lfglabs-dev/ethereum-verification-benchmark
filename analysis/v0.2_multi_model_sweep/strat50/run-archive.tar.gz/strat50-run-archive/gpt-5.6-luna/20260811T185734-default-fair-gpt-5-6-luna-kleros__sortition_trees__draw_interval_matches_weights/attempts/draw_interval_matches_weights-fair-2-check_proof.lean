import Benchmark.Cases.Kleros.SortitionTrees.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Kleros.SortitionTrees

open Verity
open Verity.EVM.Uint256

/--
Executing `draw` follows the encoded ticket intervals used by the
implementation.
-/
theorem draw_interval_matches_weights
    (ticket : Uint256) (s : ContractState)
    (hRoot : s.storage 0 != 0)
    (hInRange : ticket < s.storage 0) :
    let s' := ((SortitionTrees.draw ticket).run s).snd
    draw_interval_matches_weights_spec ticket s s' := by
  simp only [grind_norm] at *
    simp [draw_interval_matches_weights_spec, SortitionTrees.draw, SortitionTrees.rootSum,
      SortitionTrees.leftSum, SortitionTrees.leaf0, SortitionTrees.leaf2,
      Contract.run, ContractResult.snd, Verity.bind, Bind.bind, Verity.pure, Pure.pure,
      getStorage, setStorage, *]
    all_goals split_ifs <;> simp_all [grind_norm]

end Benchmark.Cases.Kleros.SortitionTrees

