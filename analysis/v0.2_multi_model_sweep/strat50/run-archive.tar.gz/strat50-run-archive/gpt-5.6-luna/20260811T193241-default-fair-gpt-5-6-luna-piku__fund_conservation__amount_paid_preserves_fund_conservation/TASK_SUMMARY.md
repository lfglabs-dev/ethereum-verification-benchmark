# Verity Task Summary

- group: `piku/fund_conservation/amount_paid_preserves_fund_conservation`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `piku/fund_conservation/amount_paid_preserves_fund_conservation`

- theorem: `Benchmark.Cases.Piku.FundConservation.amountPaid_preserves_fund_conservation`
- target module: `Benchmark.Generated.Piku.FundConservation.Tasks.AmountPaidPreservesFundConservation`
- editable files: `Benchmark/Generated/Piku/FundConservation/Tasks/AmountPaidPreservesFundConservation.lean`
- implementation files: `cases/piku/fund_conservation/verity/Contract.lean, Benchmark/Cases/Piku/FundConservation/Contract.lean`
- specification files: `cases/piku/fund_conservation/verity/Specs.lean, Benchmark/Cases/Piku/FundConservation/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: def BPS : Uint256
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: def projectFeeAmount (total projectFeeBps : Uint256) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: def protocolFeeAmount (total protocolFeeBps : Uint256) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: def netRedeemAmount (total protocolFeeBps projectFeeBps : Uint256) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage initialBacking : Uint256 := slot 0
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage distributedBacking : Uint256 := slot 1
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage remainingBacking : Uint256 := slot 2
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage protocolTreasuryFees : Uint256 := slot 3
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage projectTreasuryFees : Uint256 := slot 4
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage _openRedemptionAmount : Uint256 := slot 5
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage _orderId : Uint256 := slot 6
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: storage sellFee : Uint256 := slot 7
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: Benchmark.Cases.Piku.FundConservation.function _sellOrder
- `Benchmark/Cases/Piku/FundConservation/Contract.lean`: Benchmark.Cases.Piku.FundConservation.function amountPaid (amount : Uint256, protocolCollateralFeeAmount : Uint256) : Unit := do
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def initialBackingOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def distributedBackingOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def remainingBackingOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def protocolTreasuryFeesOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def projectTreasuryFeesOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def _openRedemptionAmountOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def _orderIdOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def sellFeeOf (s : ContractState) : Uint256
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def fund_conservation_spec (s : ContractState) : Prop
- `Benchmark/Cases/Piku/FundConservation/Specs.lean`: def _sellOrder_preserves_fund_conservation_spec

### Current Editable File

`Benchmark/Generated/Piku/FundConservation/Tasks/AmountPaidPreservesFundConservation.lean`

```lean
import Benchmark.Cases.Piku.FundConservation.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Piku.FundConservation

open Verity
open Verity.EVM.Uint256

/--
Manual queue payment execution preserves the same backing decomposition
when the queued amount is split into user distribution plus protocol treasury
fee. The reference proof discharges that Uint256 split arithmetic directly.
-/
theorem amountPaid_preserves_fund_conservation
    (amount protocolFeeAmount_ : Uint256) (s : ContractState)
    (hOpen : amount.val <= (s.storage 5).val)
    (hFee : protocolFeeAmount_.val <= amount.val) :
    let s' := ((FM_PC_Oracle_Redeeming_v1.amountPaid amount protocolFeeAmount_).run s).snd
    amountPaid_preserves_fund_conservation_spec amount protocolFeeAmount_ s s' := by
  exact ?_

end Benchmark.Cases.Piku.FundConservation
```
