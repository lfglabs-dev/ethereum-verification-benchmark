# Verity Task Summary

- group: `usual/dao_collateral/redeem_return_formula`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `usual/dao_collateral/redeem_return_formula`

- theorem: `Benchmark.Cases.Usual.DaoCollateral.redeem_return_formula`
- target module: `Benchmark.Generated.Usual.DaoCollateral.Tasks.RedeemReturnFormula`
- editable files: `Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemReturnFormula.lean`
- implementation files: `cases/usual/dao_collateral/verity/Contract.lean, Benchmark/Cases/Usual/DaoCollateral/Contract.lean`
- specification files: `cases/usual/dao_collateral/verity/Specs.lean, Benchmark/Cases/Usual/DaoCollateral/Specs.lean`

### Relevant Symbols

- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_ONE : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def SCALAR_TEN_KWEI : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def supportedTokenUnit (tokenUnit : Uint256) : Bool
- `cases/usual/dao_collateral/verity/Contract.lean`: def floorMulDiv (x y denominator : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def redeemFeeAmount (stableAmount redeemFee tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def tokenAmountForUsd (wadStableAmount price tokenUnit : Uint256) : Uint256
- `cases/usual/dao_collateral/verity/Contract.lean`: def cbrAdjustedTokenAmount
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostUsd0Supply : Uint256 := slot 0
- `cases/usual/dao_collateral/verity/Contract.lean`: storage ghostTreasuryCollateral : Address → Uint256 := slot 1
- `cases/usual/dao_collateral/verity/Contract.lean`: storage redeemFeeBps : Uint256 := slot 2
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrOn : Uint256 := slot 3
- `cases/usual/dao_collateral/verity/Contract.lean`: storage cbrCoefficient : Uint256 := slot 4
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function swapDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: Benchmark.Cases.Usual.DaoCollateral.function redeemDirect
- `cases/usual/dao_collateral/verity/Contract.lean`: def mulDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Contract.lean`: def addDoesNotWrap (x y : Uint256) : Prop
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostUsd0SupplyOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def ghostTreasuryCollateralOf (s : ContractState) (rwaToken : Address) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def redeemFeeBpsOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def isCBROnState (s : ContractState) : Bool
- `cases/usual/dao_collateral/verity/Specs.lean`: def cbrCoefOf (s : ContractState) : Uint256
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedFeeUsd0
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedReturnedCollateral
- `cases/usual/dao_collateral/verity/Specs.lean`: def expectedSwapUsdQuote

### Current Editable File

`Benchmark/Generated/Usual/DaoCollateral/Tasks/RedeemReturnFormula.lean`

```lean
import Benchmark.Cases.Usual.DaoCollateral.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Usual.DaoCollateral

open Verity
open Verity.EVM.Uint256

/--
The redeem return value is the modeled floor-rounded oracle conversion, with CBR
coefficient applied when active.
-/
theorem redeem_return_formula
    (stableAmount minAmountOut price tokenUnit : Uint256) (rwaToken : Address)
    (s : ContractState)
    (hAmount : stableAmount != 0)
    (hPrice : price != 0)
    (hTokenUnit : tokenUnit != 0)
    (hReturnedNonzero :
      expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
        (cbrCoefOf s) (isCBROnState s) ≠ 0)
    (hMin :
      minAmountOut.val ≤
        (expectedReturnedCollateral stableAmount price tokenUnit (redeemFeeBpsOf s)
          (cbrCoefOf s) (isCBROnState s)).val)
    (hArithmetic :
      successfulRedeemArithmetic rwaToken stableAmount price tokenUnit s) :
    let result := (DaoCollateral.redeemDirect rwaToken stableAmount minAmountOut price tokenUnit).run s
    redeem_return_formula_spec result.fst stableAmount price tokenUnit s := by
  exact ?_

end Benchmark.Cases.Usual.DaoCollateral
```
