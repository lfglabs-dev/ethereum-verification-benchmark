# Run 20260811T194654-default-fair-gpt-5-6-luna-usual__dao_collateral__redeem_return_formula

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: usual/dao_collateral
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `usual/dao_collateral/redeem_return_formula`: forbidden_placeholder
