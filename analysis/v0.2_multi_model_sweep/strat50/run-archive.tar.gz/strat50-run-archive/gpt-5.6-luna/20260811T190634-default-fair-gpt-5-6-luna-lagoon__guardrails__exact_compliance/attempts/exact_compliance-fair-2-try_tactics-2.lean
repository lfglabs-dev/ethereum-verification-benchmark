import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem exact_compliance_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    exactComplianceSpec currentPps nextPps timePast upperRate lowerRate := by
  unfold exactComplianceSpec; split_ifs <;> simp [isCompliant, annualizedVariationInsideGuardrails, positiveBranchCompliant, negativeBranchCompliant]

end Benchmark.Generated.Lagoon.Guardrails.Tasks

