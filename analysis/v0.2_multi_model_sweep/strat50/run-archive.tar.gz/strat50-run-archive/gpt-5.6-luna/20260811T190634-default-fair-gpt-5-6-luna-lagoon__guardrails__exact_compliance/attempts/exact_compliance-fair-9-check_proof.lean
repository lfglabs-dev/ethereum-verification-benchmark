import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem exact_compliance_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    exactComplianceSpec currentPps nextPps timePast upperRate lowerRate := by
  simp [exactComplianceSpec, successfulSolidityArithmeticScope, isCompliant, annualizedVariationInsideGuardrails, positiveBranchCompliant, negativeBranchCompliant, lowerRateNotMin, int256Nat, int256NegativeMagnitude, ppsIncreaseVariationNat, ppsDecreaseVariationNat, uint256Nat, scaleToOneYearNat] <;>
      intro hmin hcur htime hsafe
      by_cases hdir : currentPps.val ≤ nextPps.val
      · by_cases hneg : lowerRate.toInt < 0
        · simp [hdir, hneg, hsafe]
        · simp [hdir, hneg, and_comm, hsafe]
      · simp [hdir, hsafe]

end Benchmark.Generated.Lagoon.Guardrails.Tasks

