# Run 20260811T190634-default-fair-gpt-5-6-luna-lagoon__guardrails__exact_compliance

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lagoon/guardrails
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `lagoon/guardrails/exact_compliance`: theorem_missing
