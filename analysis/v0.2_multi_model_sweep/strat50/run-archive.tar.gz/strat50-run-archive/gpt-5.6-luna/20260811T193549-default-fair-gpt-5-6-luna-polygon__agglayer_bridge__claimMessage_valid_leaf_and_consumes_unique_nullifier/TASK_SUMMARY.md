# Verity Task Summary

- group: `polygon/agglayer_bridge/claimMessage_valid_leaf_and_consumes_unique_nullifier`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `polygon/agglayer_bridge/claimMessage_valid_leaf_and_consumes_unique_nullifier`

- theorem: `Benchmark.Cases.Polygon.AgglayerBridge.claimMessage_valid_leaf_and_consumes_unique_nullifier`
- target module: `Benchmark.Generated.Polygon.AgglayerBridge.Tasks.claimMessage_valid_leaf_and_consumes_unique_nullifier`
- editable files: `Benchmark/Generated/Polygon/AgglayerBridge/Tasks/claimMessage_valid_leaf_and_consumes_unique_nullifier.lean`
- implementation files: `cases/polygon/agglayer_bridge/verity/Contract.lean, Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`
- specification files: `cases/polygon/agglayer_bridge/verity/Specs.lean, Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def MAINNET_NETWORK_ID : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def ZKEVM_NETWORK_ID : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def LEAF_TYPE_ASSET : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def LEAF_TYPE_MESSAGE : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def MAX_LEAFS_PER_NETWORK : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def GLOBAL_INDEX_MAINNET_FLAG : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def LOW_32_MASK : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def LOW_8_MASK : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def globalIndexForNullifierModel
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def bitmapWordPosModel (index : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def bitmapBitPosModel (index : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: def bitmapMaskModel (index : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: storage _branch : Uint256 → Uint256 := slot 0
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: storage depositCount : Uint256 := slot 1
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: storage networkID : Uint256 := slot 2
- `Benchmark/Cases/Polygon/AgglayerBridge/Contract.lean`: storage globalExitRootMap : Uint256 → Uint256 := slot 3
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def calculateGlobalExitRoot_spec (mainnetExitRoot rollupExitRoot : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def calculateRoot_spec (leafHash : Uint256) (proof : Array Uint256) (index : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def getLeafValue_spec
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def _validateAndDecodeGlobalIndex_leafIndex (globalIndex : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def _validateAndDecodeGlobalIndex_indexRollup (globalIndex : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def _validateAndDecodeGlobalIndex_sourceBridgeNetwork (globalIndex : Uint256) : Uint256
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def _validateAndDecodeGlobalIndex_valid (globalIndex : Uint256) : Prop
- `Benchmark/Cases/Polygon/AgglayerBridge/Specs.lean`: def _bitmapPositions_wordPos (index : Uint256) : Uint256

### Current Editable File

`Benchmark/Generated/Polygon/AgglayerBridge/Tasks/claimMessage_valid_leaf_and_consumes_unique_nullifier.lean`

```lean
import Benchmark.Cases.Polygon.AgglayerBridge.Contract
import Benchmark.Cases.Polygon.AgglayerBridge.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Polygon.AgglayerBridge.Tasks

open Verity
open Verity.EVM.Uint256
open Benchmark.Cases.Polygon.AgglayerBridge

theorem claimMessage_valid_leaf_and_consumes_unique_nullifier
    (s : ContractState)
    (smtProofLocalExitRoot smtProofRollupExitRoot : Array Uint256)
    (globalIndex mainnetExitRoot rollupExitRoot originNetwork : Uint256)
    (originAddress : Address)
    (destinationNetwork : Uint256)
    (destinationAddress : Address)
    (amount metadataHash : Uint256) :
    match
      (AgglayerBridge.claimMessage
        smtProofLocalExitRoot smtProofRollupExitRoot globalIndex mainnetExitRoot rollupExitRoot
        originNetwork originAddress destinationNetwork destinationAddress amount metadataHash).run s
    with
    | ContractResult.success _ s' =>
        claimMessage_valid_leaf_and_consumes_unique_nullifier_spec
          s s' smtProofLocalExitRoot smtProofRollupExitRoot globalIndex mainnetExitRoot rollupExitRoot
          originNetwork originAddress destinationNetwork destinationAddress amount metadataHash
    | ContractResult.revert _ _ => True := by
  exact ?_

end Benchmark.Generated.Polygon.AgglayerBridge.Tasks
```
