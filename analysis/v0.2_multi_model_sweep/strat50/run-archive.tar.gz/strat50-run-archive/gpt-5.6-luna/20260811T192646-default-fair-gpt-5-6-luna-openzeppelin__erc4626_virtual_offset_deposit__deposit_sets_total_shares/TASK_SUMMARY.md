# Verity Task Summary

- group: `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_shares`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `openzeppelin/erc4626_virtual_offset_deposit/deposit_sets_total_shares`

- theorem: `Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.deposit_sets_totalShares`
- target module: `Benchmark.Generated.OpenZeppelin.ERC4626VirtualOffsetDeposit.Tasks.DepositSetsTotalShares`
- editable files: `Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalShares.lean`
- implementation files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Contract.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`
- specification files: `cases/openzeppelin/erc4626_virtual_offset_deposit/verity/Specs.lean, Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualAssets : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def virtualShares : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewDepositAmount (assets totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: def previewRedeemAmount (shares totalAssets totalShares : Uint256) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalAssets : Uint256 := slot 0
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: storage totalShares : Uint256 := slot 1
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Contract.lean`: Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.function deposit (assets : Uint256) : Uint256 := do
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit (assets : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewRedeem (shares : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def oneShareAssetsUp (s : ContractState) : Uint256
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def donate (donation : Uint256) (s : ContractState) : ContractState
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalAssets_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_sets_totalShares_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def previewDeposit_rounds_down_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def positive_deposit_mints_positive_shares_under_rate_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def deposit_redeem_round_trip_bound_spec
- `Benchmark/Cases/OpenZeppelin/ERC4626VirtualOffsetDeposit/Specs.lean`: def share_price_monotone_under_donation_spec

### Current Editable File

`Benchmark/Generated/OpenZeppelin/ERC4626VirtualOffsetDeposit/Tasks/DepositSetsTotalShares.lean`

```lean
import Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit

open Verity
open Verity.EVM.Uint256

/--
Executing `deposit` stores `oldTotalShares + previewDeposit(assets)` in `totalShares`.
-/
theorem deposit_sets_totalShares
    (assets : Uint256) (s : ContractState) :
    let s' := ((ERC4626VirtualOffsetDeposit.deposit assets).run s).snd
    deposit_sets_totalShares_spec assets s s' := by
  exact ?_

end Benchmark.Cases.OpenZeppelin.ERC4626VirtualOffsetDeposit
```
