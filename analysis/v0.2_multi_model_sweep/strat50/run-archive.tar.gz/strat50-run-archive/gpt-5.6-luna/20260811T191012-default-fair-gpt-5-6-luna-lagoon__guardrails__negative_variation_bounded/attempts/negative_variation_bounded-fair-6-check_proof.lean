import Benchmark.Cases.Lagoon.Guardrails.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Lagoon.Guardrails.Tasks

open Benchmark.Cases.Lagoon.Guardrails
open Verity
open Verity.EVM

theorem negative_variation_bounded_task
    (currentPps nextPps timePast upperRate : Uint256)
    (lowerRate : Verity.Core.Int256) :
    negativeVariationBoundedSpec currentPps nextPps timePast upperRate lowerRate := by
  unfold negativeVariationBoundedSpec
  by_cases h : uint256Nat currentPps ≤ uint256Nat nextPps
  · simp [h, isCompliant, negativeBranchCompliant]
    <;> omega
  · have h' : uint256Nat nextPps < uint256Nat currentPps := by omega
    simp [h, h', isCompliant, negativeBranchCompliant,
      Nat.not_le.mpr h']
    <;> omega

end Benchmark.Generated.Lagoon.Guardrails.Tasks

