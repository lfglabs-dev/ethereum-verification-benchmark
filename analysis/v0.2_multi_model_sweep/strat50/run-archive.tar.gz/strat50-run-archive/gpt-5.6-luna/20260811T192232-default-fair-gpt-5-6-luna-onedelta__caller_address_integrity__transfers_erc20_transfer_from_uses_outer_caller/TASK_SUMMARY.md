# Verity Task Summary

- group: `onedelta/caller_address_integrity/transfers_erc20_transfer_from_uses_outer_caller`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `onedelta/caller_address_integrity/transfers_erc20_transfer_from_uses_outer_caller`

- theorem: `Benchmark.Cases.OneDelta.CallerAddressIntegrity.transfers_erc20_transferFrom_uses_outer_caller`
- target module: `Benchmark.Generated.OneDelta.CallerAddressIntegrity.Tasks.TransfersErc20TransferFromUsesOuterCaller`
- editable files: `Benchmark/Generated/OneDelta/CallerAddressIntegrity/Tasks/TransfersErc20TransferFromUsesOuterCaller.lean`
- implementation files: `cases/onedelta/caller_address_integrity/verity/Contract.lean, Benchmark/Cases/OneDelta/CallerAddressIntegrity/Contract.lean`
- specification files: `cases/onedelta/caller_address_integrity/verity/Specs.lean, Benchmark/Cases/OneDelta/CallerAddressIntegrity/Specs.lean`

### Relevant Symbols

- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: def TRANSFER_FROM : Uint256
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: def PERMIT2_TRANSFER_FROM : Uint256
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage outerCallerWord : Uint256 := slot 0
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage erc20TransferFromWord : Uint256 := slot 1
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage permit2TransferFromWord : Uint256 := slot 2
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage flashCallbackCallerWord : Uint256 := slot 3
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage swapCallbackCallerWord : Uint256 := slot 4
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage v3CallbackTransferFromWord : Uint256 := slot 5
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage erc20TransferFromOccurred : Uint256 := slot 6
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage permit2TransferFromOccurred : Uint256 := slot 7
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: storage v3CallbackTransferFromOccurred : Uint256 := slot 8
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: Benchmark.Cases.OneDelta.CallerAddressIntegrity.function deltaCompose () : Unit := do
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: Benchmark.Cases.OneDelta.CallerAddressIntegrity.function _deltaComposeInternal_transferFrom (callerAddress : Address) : Unit := do
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: Benchmark.Cases.OneDelta.CallerAddressIntegrity.function _deltaComposeInternal_permit2TransferFrom (callerAddress : Address) : Unit := do
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: Benchmark.Cases.OneDelta.CallerAddressIntegrity.function _deltaComposeInternal_invalidTransfer (callerAddress : Address) : Unit := do
- `cases/onedelta/caller_address_integrity/verity/Contract.lean`: Benchmark.Cases.OneDelta.CallerAddressIntegrity.function _transfers_transferFrom (callerAddress : Address) : Unit := do
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def outerCaller (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def erc20PullFrom (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def permit2PullFrom (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def flashCallbackCaller (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def swapCallbackCaller (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def v3CallbackPullFrom (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def erc20PullOccurred (s : ContractState) : Uint256
- `cases/onedelta/caller_address_integrity/verity/Specs.lean`: def permit2PullOccurred (s : ContractState) : Uint256

### Current Editable File

`Benchmark/Generated/OneDelta/CallerAddressIntegrity/Tasks/TransfersErc20TransferFromUsesOuterCaller.lean`

```lean
import Benchmark.Cases.OneDelta.CallerAddressIntegrity.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.OneDelta.CallerAddressIntegrity

open Verity
open Verity.EVM.Uint256

/--
Decoded `_transfers` `TRANSFER_FROM` dispatch must preserve the outer
`deltaCompose` sender as the ERC20 `transferFrom` source.
-/
theorem transfers_erc20_transferFrom_uses_outer_caller
    (callerAddress : Address) (s : ContractState) :
    let s' := ((OneDeltaComposer._transfers_transferFrom callerAddress).run s).snd
    erc20_caller_spec {s with sender := callerAddress} s' := by
  exact ?_

end Benchmark.Cases.OneDelta.CallerAddressIntegrity
```
