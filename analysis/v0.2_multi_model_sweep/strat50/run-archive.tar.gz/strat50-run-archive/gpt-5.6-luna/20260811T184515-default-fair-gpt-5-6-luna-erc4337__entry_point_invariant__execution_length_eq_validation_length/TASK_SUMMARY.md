# Verity Task Summary

- group: `erc4337/entry_point_invariant/execution_length_eq_validation_length`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `erc4337/entry_point_invariant/execution_length_eq_validation_length`

- theorem: `Benchmark.Cases.ERC4337.EntryPointInvariant.execution_length_eq_validation_length`
- target module: `Benchmark.Generated.ERC4337.EntryPointInvariant.Tasks.ExecutionLengthEqValidationLength`
- editable files: `Benchmark/Generated/ERC4337/EntryPointInvariant/Tasks/ExecutionLengthEqValidationLength.lean`
- implementation files: `cases/erc4337/entry_point_invariant/verity/Contract.lean, Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`
- specification files: `cases/erc4337/entry_point_invariant/verity/Specs.lean, Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: Benchmark.Cases.ERC4337.EntryPointInvariant.function handleOps(PackedUserOperation[] calldata ops, address payable beneficiary)
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: abbrev ValidationResult
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: abbrev ExecutionAttempted
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def validationPhaseSucceeds (results : List ValidationResult) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def executionPhase (opslen : Nat) : List ExecutionAttempted
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def handleOps (validationResults : List ValidationResult)
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def wasValidated (validationResults : List ValidationResult) (i : Nat) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def wasExecuted (executionResults : Option (List ExecutionAttempted)) (i : Nat) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: structure OpInfo where
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def validationPhaseSucceedsR (ops : List OpInfo) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def senderCallAttempted (ops : List OpInfo) (i : Nat) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def executionAttemptedR (ops : List OpInfo) (i : Nat) : Bool
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def handleOpsR (ops : List OpInfo) : Option Nat
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Contract.lean`: def feesCollectedR (ops : List OpInfo) : Option Nat
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def execution_implies_validation_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def validation_implies_execution_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def execution_iff_validation_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def all_validated_on_success_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def all_executed_on_success_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def no_execution_on_revert_spec
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def single_op_execution_on_validation_spec (_s s' : ContractState) : Prop
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def single_op_fee_collected_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def handleOps_deterministic_spec (vr1 vr2 : List ValidationResult) : Prop
- `Benchmark/Cases/ERC4337/EntryPointInvariant/Specs.lean`: def handleOps_empty_spec : Prop

### Current Editable File

`Benchmark/Generated/ERC4337/EntryPointInvariant/Tasks/ExecutionLengthEqValidationLength.lean`

```lean
import Benchmark.Cases.ERC4337.EntryPointInvariant.Specs

namespace Benchmark.Cases.ERC4337.EntryPointInvariant

open Verity
open Verity.EVM.Uint256

/--
On success, the execution-attempt list has one entry per UserOp.
-/
theorem execution_length_eq_validation_length
    (validationResults : List ValidationResult) :
    execution_length_eq_validation_length_spec validationResults := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.ERC4337.EntryPointInvariant
```
