# Run 20260811T192507-default-fair-gpt-5-6-luna-openzeppelin__erc4626_virtual_offset_deposit__deposit_redeem_round_trip_bound

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: openzeppelin/erc4626_virtual_offset_deposit
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `openzeppelin/erc4626_virtual_offset_deposit/deposit_redeem_round_trip_bound`: lean_check_failed
