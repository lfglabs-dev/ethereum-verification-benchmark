# Run 20260811T193138-default-fair-gpt-5-6-luna-pendle__py_supply_pairing__redeem_py_pre_expiry_burns_equal_amount

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: pendle/py_supply_pairing
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `pendle/py_supply_pairing/redeem_py_pre_expiry_burns_equal_amount`: forbidden_placeholder
