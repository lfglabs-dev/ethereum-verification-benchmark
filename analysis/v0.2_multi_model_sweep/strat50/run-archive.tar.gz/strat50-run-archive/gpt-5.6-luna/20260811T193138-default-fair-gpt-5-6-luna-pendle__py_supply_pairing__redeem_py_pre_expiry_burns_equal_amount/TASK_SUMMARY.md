# Verity Task Summary

- group: `pendle/py_supply_pairing/redeem_py_pre_expiry_burns_equal_amount`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `pendle/py_supply_pairing/redeem_py_pre_expiry_burns_equal_amount`

- theorem: `Benchmark.Cases.Pendle.PySupplyPairing.redeem_py_pre_expiry_burns_equal_amount`
- target module: `Benchmark.Generated.Pendle.PySupplyPairing.Tasks.RedeemPyPreExpiryBurnsEqualAmount`
- editable files: `Benchmark/Generated/Pendle/PySupplyPairing/Tasks/RedeemPyPreExpiryBurnsEqualAmount.lean`
- implementation files: `cases/pendle/py_supply_pairing/verity/Contract.lean, Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`
- specification files: `cases/pendle/py_supply_pairing/verity/Specs.lean, Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: theorem observes only PT/YT supply and balance state.
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def ONE : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def uint248Max : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: abbrev requireSomeUint
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: abbrev safeAdd
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: abbrev safeMul
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: abbrev safeDiv
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def syToAsset (exchangeRate syAmount : Uint256) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def assetToSy (exchangeRate assetAmount : Uint256) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def maxUint (a b : Uint256) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def minUint (a b : Uint256) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: def pyToRedeem (expiredFlag ptHeldByContract ytHeldByContract : Uint256) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: storage ytTotalSupply : Uint256 := slot 0
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: storage ptTotalSupply : Uint256 := slot 1
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: storage ytBalances : Address → Uint256 := slot 2
- `Benchmark/Cases/Pendle/PySupplyPairing/Contract.lean`: storage ptBalances : Address → Uint256 := slot 3
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def ytSupply (s : ContractState) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def ptSupply (s : ContractState) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def ytBalanceOf (s : ContractState) (account : Address) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def ptBalanceOf (s : ContractState) (account : Address) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def syReserveOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def syBalanceOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def pyIndexStoredOf (s : ContractState) : Uint256
- `Benchmark/Cases/Pendle/PySupplyPairing/Specs.lean`: def exchangeRateOf (s : ContractState) : Uint256

### Current Editable File

`Benchmark/Generated/Pendle/PySupplyPairing/Tasks/RedeemPyPreExpiryBurnsEqualAmount.lean`

```lean
import Benchmark.Cases.Pendle.PySupplyPairing.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Pendle.PySupplyPairing

open Verity
open Verity.EVM.Uint256

/--
Successful pre-expiry `redeemPY` burns the exact computed amount from both PT
and YT supplies and from the contract's own PT/YT balances.
-/
theorem redeem_py_pre_expiry_burns_equal_amount
    (receiver : Address) (s : ContractState)
    (hNotExpired : s.storage 8 = 0)
    (hSelf : (s.thisAddress != zeroAddress) = true)
    (hPtBalanceEnough : s.storageMap 3 s.thisAddress >= redeemPYAmountOf s)
    (hYtBalanceEnough : s.storageMap 2 s.thisAddress >= redeemPYAmountOf s)
    (hPtSupplyEnough : s.storage 1 >= redeemPYAmountOf s)
    (hYtSupplyEnough : s.storage 0 >= redeemPYAmountOf s)
    (hRedeemUint248 : redeemPYAmountOf s <= uint248Max)
    (hIndexNonzero : (currentIndexOf s != 0) = true)
    (hRedeemMulNoOverflow :
      (redeemPYAmountOf s : Nat) * (ONE : Nat) <= Verity.Stdlib.Math.MAX_UINT256) :
    let s' := ((PendlePY.redeemPY receiver).run s).snd
    redeem_py_pre_expiry_burns_equal_amount_spec s s' := by
  exact ?_

end Benchmark.Cases.Pendle.PySupplyPairing
```
