# Run 20260811T193805-default-fair-gpt-5-6-luna-rootstock__flyover_quote_lifecycle__refund_peg_out_conserves_quote_amount

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: rootstock/flyover_quote_lifecycle
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `rootstock/flyover_quote_lifecycle/refund_peg_out_conserves_quote_amount`: forbidden_placeholder
