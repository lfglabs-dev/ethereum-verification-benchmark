# Verity Task Summary

- group: `rootstock/flyover_quote_lifecycle/refund_peg_out_conserves_quote_amount`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `rootstock/flyover_quote_lifecycle/refund_peg_out_conserves_quote_amount`

- theorem: `Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle.refundPegOut_conserves_quote_amount`
- target module: `Benchmark.Generated.Rootstock.FlyoverQuoteLifecycle.Tasks.RefundPegOutConservesQuoteAmount`
- editable files: `Benchmark/Generated/Rootstock/FlyoverQuoteLifecycle/Tasks/RefundPegOutConservesQuoteAmount.lean`
- implementation files: `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean, Benchmark/Cases/Rootstock/FlyoverQuoteLifecycle/Contract.lean`
- specification files: `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean, Benchmark/Cases/Rootstock/FlyoverQuoteLifecycle/Specs.lean`

### Relevant Symbols

- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: def completedFlag : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteAmount : Address → Uint256 := slot 0
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quotePenalty : Address → Uint256 := slot 1
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteCompleted : Address → Uint256 := slot 2
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage lpPaid : Address → Uint256 := slot 3
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage userPaid : Address → Uint256 := slot 4
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage internalBalance : Address → Uint256 := slot 5
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage slashCallAmount : Address → Uint256 := slot 6
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteRegistered : Address → Uint256 := slot 7
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteDepositTimestamp : Address → Uint256 := slot 8
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteExpireDate : Address → Uint256 := slot 9
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteExpireBlock : Address → Uint256 := slot 10
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteLpRskAddress : Address → Uint256 := slot 11
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: storage quoteRskRefundAddress : Address → Uint256 := slot 12
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle.function depositPegOut
- `cases/rootstock/flyover_quote_lifecycle/verity/Contract.lean`: Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle.function refundPegOut
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def depositedAmount (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def penaltyAmount (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def completed (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def paidToLp (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def paidToUser (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def fallbackBalance (s : ContractState) (recipient : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def slashCallAmountOf (s : ContractState) (quoteHash : Address) : Uint256
- `cases/rootstock/flyover_quote_lifecycle/verity/Specs.lean`: def registered (s : ContractState) (quoteHash : Address) : Uint256

### Current Editable File

`Benchmark/Generated/Rootstock/FlyoverQuoteLifecycle/Tasks/RefundPegOutConservesQuoteAmount.lean`

```lean
import Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle.Specs
import Verity.Proofs.Stdlib.Automation
import Benchmark.Grindset

namespace Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle

open Verity
open Verity.EVM.Uint256

/-- LP refund completes the quote and assigns the registered amount. -/
theorem refundPegOut_conserves_quote_amount
    (quoteHash : Address)
    (transferSucceeds : Bool)
    (transferTime btcBlockTime firstConfirmationTimestamp
      expireDate currentTimestamp expireBlock currentBlock : Uint256)
    (s : ContractState)
    (hPenaltyDeadlineNoOverflow :
      add (s.storageMap 8 quoteHash) transferTime >= s.storageMap 8 quoteHash)
    (hPenaltyExpectedNoOverflow :
      add (add (s.storageMap 8 quoteHash) transferTime) btcBlockTime >=
        add (s.storageMap 8 quoteHash) transferTime)
    (hFallbackNoOverflow :
      add (s.storageMap 5 (lpRecipientOf s quoteHash)) (s.storageMap 0 quoteHash) >=
        s.storageMap 5 (lpRecipientOf s quoteHash))
    (hRegistered : (s.storageMap 7 quoteHash == completedFlag) = true)
    (hIncomplete : (s.storageMap 2 quoteHash == 0) = true) :
    let s' := ((PegOutLifecycle.refundPegOut quoteHash transferSucceeds transferTime
      btcBlockTime firstConfirmationTimestamp expireDate currentTimestamp expireBlock currentBlock).run s).snd
    refundPegOut_conserves_quote_amount_spec quoteHash transferSucceeds transferTime
      btcBlockTime firstConfirmationTimestamp expireDate currentTimestamp expireBlock currentBlock s s' := by
  exact ?_

end Benchmark.Cases.Rootstock.FlyoverQuoteLifecycle
```
