# Verity Task Summary

- group: `polaris/bonding_curve/floor_sell_and_burn_preserves_reserve_ratio_zero`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `polaris/bonding_curve/floor_sell_and_burn_preserves_reserve_ratio_zero`

- theorem: `Benchmark.Cases.Polaris.BondingCurve.floorSellAndBurn_preserves_reserve_ratio_zero`
- target module: `Benchmark.Generated.Polaris.BondingCurve.Tasks.floor_sell_and_burn_preserves_reserve_ratio_zero`
- editable files: `Benchmark/Generated/Polaris/BondingCurve/Tasks/floor_sell_and_burn_preserves_reserve_ratio_zero.lean`
- implementation files: `cases/polaris/bonding_curve/verity/Contract.lean, Benchmark/Cases/Polaris/BondingCurve/Contract.lean`
- specification files: `cases/polaris/bonding_curve/verity/Specs.lean, Benchmark/Cases/Polaris/BondingCurve/Specs.lean`

### Relevant Symbols

- `cases/polaris/bonding_curve/verity/Contract.lean`: def decimalPrecision : Uint256
- `cases/polaris/bonding_curve/verity/Contract.lean`: def curvePow (supply bPlusOne : Uint256) : Uint256
- `cases/polaris/bonding_curve/verity/Contract.lean`: def reserveRatioBalanceFromLeft (left bPlusOne : Uint256) : Uint256
- `cases/polaris/bonding_curve/verity/Contract.lean`: def reserveRatioLeftFormula
- `cases/polaris/bonding_curve/verity/Contract.lean`: def getBalanceFromReserveRatio
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage virtualBalance : Uint256 := slot 0
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage floorSupply : Uint256 := slot 1
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage floorBalance : Uint256 := slot 2
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage totalSupply : Uint256 := slot 3
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage feePercentage : Uint256 := slot 4
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage initialized : Uint256 := slot 5
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage alpha : Uint256 := slot 6
- `cases/polaris/bonding_curve/verity/Contract.lean`: storage bPlusOne : Uint256 := slot 7
- `cases/polaris/bonding_curve/verity/Contract.lean`: Benchmark.Cases.Polaris.BondingCurve.function allow_post_interaction_writes init
- `cases/polaris/bonding_curve/verity/Contract.lean`: Benchmark.Cases.Polaris.BondingCurve.function allow_post_interaction_writes buy
- `cases/polaris/bonding_curve/verity/Contract.lean`: Benchmark.Cases.Polaris.BondingCurve.function allow_post_interaction_writes sell (bcTokenAmount : Uint256) : Unit := do
- `cases/polaris/bonding_curve/verity/Specs.lean`: def virtualBalanceOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def floorSupplyOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def floorBalanceOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def totalSupplyOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def feePercentageOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def initializedOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def alphaOf (s : ContractState) : Uint256
- `cases/polaris/bonding_curve/verity/Specs.lean`: def bPlusOneOf (s : ContractState) : Uint256

### Current Editable File

`Benchmark/Generated/Polaris/BondingCurve/Tasks/floor_sell_and_burn_preserves_reserve_ratio_zero.lean`

```lean
import Benchmark.Cases.Polaris.BondingCurve.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Polaris.BondingCurve.Tasks

open Benchmark.Cases.Polaris.BondingCurve
open Verity
open Verity.EVM.Uint256

theorem floor_sell_and_burn_preserves_reserve_ratio_zero_task
    (authorizedFeeRouter : Bool) (bcTokenAmount : Uint256)
    (s : ContractState)
    (hAuthorized : authorizedFeeRouter = true)
    (hAmountNonZero : bcTokenAmount != 0)
    (hOldSupplyNoOverflow :
      (floorSupplyOf s).val + (totalSupplyOf s).val < Verity.Core.Uint256.modulus)
    (hNewFloorNoOverflow :
      (floorSupplyOf s).val + bcTokenAmount.val < Verity.Core.Uint256.modulus)
    (hNewFloorLeOldSupply :
      floorSupplyAfterFeeBurn bcTokenAmount s <= virtualSupplyOf s)
    (hBurnLeTotalSupply : bcTokenAmount <= totalSupplyOf s)
    (hBurnValLeTotalSupply : bcTokenAmount.val <= (totalSupplyOf s).val) :
    let s' :=
      ((BaseBondingCurve.floorSellAndBurn
        authorizedFeeRouter bcTokenAmount).run s).snd
    floorSellAndBurn_preserves_reserve_ratio_zero_spec s s' := by
  exact ?_

end Benchmark.Generated.Polaris.BondingCurve.Tasks
```
