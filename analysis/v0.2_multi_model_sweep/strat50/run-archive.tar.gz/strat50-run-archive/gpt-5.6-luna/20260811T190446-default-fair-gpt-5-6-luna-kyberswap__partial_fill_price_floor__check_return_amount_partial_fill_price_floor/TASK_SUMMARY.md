# Verity Task Summary

- group: `kyberswap/partial_fill_price_floor/check_return_amount_partial_fill_price_floor`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `kyberswap/partial_fill_price_floor/check_return_amount_partial_fill_price_floor`

- theorem: `Benchmark.Cases.KyberSwap.PartialFillPriceFloor.checkReturnAmount_partial_fill_price_floor`
- target module: `Benchmark.Generated.KyberSwap.PartialFillPriceFloor.Tasks.CheckReturnAmountPartialFillPriceFloor`
- editable files: `Benchmark/Generated/KyberSwap/PartialFillPriceFloor/Tasks/CheckReturnAmountPartialFillPriceFloor.lean`
- implementation files: `cases/kyberswap/partial_fill_price_floor/verity/Contract.lean, Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`
- specification files: `cases/kyberswap/partial_fill_price_floor/verity/Specs.lean, Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: def partialFillFlag : Uint256
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: structure SwapDescriptionV2 where
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: def _flagsChecked (flags flag : Uint256) : Bool
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: def isPartialFill (desc : SwapDescriptionV2) : Bool
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: def checkedScaledPriceFloorHolds
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Contract.lean`: Benchmark.Cases.KyberSwap.PartialFillPriceFloor.function _checkReturnAmount
- `Benchmark/Cases/KyberSwap/PartialFillPriceFloor/Specs.lean`: def partial_fill_price_floor_spec

### Current Editable File

`Benchmark/Generated/KyberSwap/PartialFillPriceFloor/Tasks/CheckReturnAmountPartialFillPriceFloor.lean`

```lean
import Benchmark.Cases.KyberSwap.PartialFillPriceFloor.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.KyberSwap.PartialFillPriceFloor

open Verity
open Verity.EVM.Uint256

/--
KyberSwap helper-level partial-fill price-floor invariant.

For a successful modeled `_checkReturnAmount` execution in the partial-fill
branch, the checked scaled floor holds:

  `returnAmount * amount >= minReturnAmount * spentAmount`.
-/
theorem checkReturnAmount_partial_fill_price_floor
    (spentAmount returnAmount amount minReturnAmount flags : Uint256)
    (s : ContractState)
    (hPartial :
      isPartialFill
        { amount := amount, minReturnAmount := minReturnAmount, flags := flags } = true)
    (hRun :
      (MetaAggregationRouterV2._checkReturnAmount
        spentAmount returnAmount amount minReturnAmount flags).run s =
        ContractResult.success () s) :
    partial_fill_price_floor_spec spentAmount returnAmount
      { amount := amount, minReturnAmount := minReturnAmount, flags := flags } := by
  exact ?_

end Benchmark.Cases.KyberSwap.PartialFillPriceFloor
```
