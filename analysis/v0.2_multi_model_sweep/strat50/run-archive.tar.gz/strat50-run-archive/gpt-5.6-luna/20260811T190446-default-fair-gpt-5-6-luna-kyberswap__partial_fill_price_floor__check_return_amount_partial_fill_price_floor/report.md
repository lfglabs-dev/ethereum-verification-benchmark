# Run 20260811T190446-default-fair-gpt-5-6-luna-kyberswap__partial_fill_price_floor__check_return_amount_partial_fill_price_floor

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: kyberswap/partial_fill_price_floor
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `kyberswap/partial_fill_price_floor/check_return_amount_partial_fill_price_floor`: lean_check_failed
