# Run 20260811T194958-default-fair-gpt-5-6-luna-yo_protocol__async_redemption_escrow__cancel_redeem_accounting

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: yo_protocol/async_redemption_escrow
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `yo_protocol/async_redemption_escrow/cancel_redeem_accounting`: forbidden_placeholder
