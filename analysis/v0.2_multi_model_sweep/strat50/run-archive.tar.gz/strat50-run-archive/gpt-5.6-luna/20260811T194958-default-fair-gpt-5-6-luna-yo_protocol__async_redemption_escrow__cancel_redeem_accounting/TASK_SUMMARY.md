# Verity Task Summary

- group: `yo_protocol/async_redemption_escrow/cancel_redeem_accounting`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `yo_protocol/async_redemption_escrow/cancel_redeem_accounting`

- theorem: `Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow.cancel_redeem_accounting`
- target module: `Benchmark.Generated.YOProtocol.AsyncRedemptionEscrow.Tasks.CancelRedeemExactAccounting`
- editable files: `Benchmark/Generated/YOProtocol/AsyncRedemptionEscrow/Tasks/CancelRedeemExactAccounting.lean`
- implementation files: `cases/yo_protocol/async_redemption_escrow/verity/Contract.lean, Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`
- specification files: `cases/yo_protocol/async_redemption_escrow/verity/Specs.lean, Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: def feeDenominator : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: def maxFee : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage totalPendingAssets : Uint256 := slot 0
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage feeOnWithdraw : Uint256 := slot 1
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage feeRecipient : Address := slot 2
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage paused : Uint256 := slot 3
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage totalSupply : Uint256 := slot 4
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage shareBalances : Address → Uint256 := slot 5
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage pendingShares : Address → Uint256 := slot 6
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage pendingAssets : Address → Uint256 := slot 7
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage owner : Address := slot 8
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage authority : Address := slot 9
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: storage underlyingToken : Address := slot 10
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow.function internal isAuthorized
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow.function internal _getAvailableBalance
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Contract.lean`: Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow.function internal _update (fromAddr : Address, toAddr : Address, shares : Uint256) : Unit := do
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def totalPendingAssetsOf (s : ContractState) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def feeOnWithdrawOf (s : ContractState) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def feeRecipientOf (s : ContractState) : Address
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def pausedOf (s : ContractState) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def totalSupplyOf (s : ContractState) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def shareBalanceOf (s : ContractState) (account : Address) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def pendingSharesOf (s : ContractState) (receiver : Address) : Uint256
- `Benchmark/Cases/YOProtocol/AsyncRedemptionEscrow/Specs.lean`: def pendingAssetsOf (s : ContractState) (receiver : Address) : Uint256

### Current Editable File

`Benchmark/Generated/YOProtocol/AsyncRedemptionEscrow/Tasks/CancelRedeemExactAccounting.lean`

```lean
import Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow

open Verity
open Verity.EVM.Uint256

/-- Successful cancellation independently releases pending components and
    returns pooled shares to the receiver, including the vault self-transfer. -/
theorem cancel_redeem_accounting
    (receiver : Address) (shares grossAssets : Uint256) (s : ContractState)
    (hAuthority : authorityOf s != zeroAddress)
    (hVault : vaultAddress s != zeroAddress)
    (hReceiver : receiver != zeroAddress)
    (hPendingShares : pendingSharesOf s receiver != 0)
    (hPendingAssets : pendingAssetsOf s receiver != 0)
    (hShareBound : shares <= pendingSharesOf s receiver)
    (hAssetBound : grossAssets <= pendingAssetsOf s receiver)
    (hGlobalBound : grossAssets <= totalPendingAssetsOf s)
    (hVaultShares : shares <= shareBalanceOf s (vaultAddress s))
    (hErc20 : erc20WellFormed s)
    (hUnpaused : pausedOf s = 0) :
    let result :=
      (YoAsyncRedemptionEscrow.cancelRedeem receiver shares grossAssets true true).run s
    cancel_redeem_accounting_spec shares grossAssets receiver s result := by
  exact ?_

end Benchmark.Cases.YOProtocol.AsyncRedemptionEscrow
```
