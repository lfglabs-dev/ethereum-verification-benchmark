# Verity Task Summary

- group: `reserve/auction_price_band/price_at_end_time`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `reserve/auction_price_band/price_at_end_time`

- theorem: `Benchmark.Cases.Reserve.AuctionPriceBand.price_at_end_time`
- target module: `Benchmark.Generated.Reserve.AuctionPriceBand.Tasks.PriceAtEndTime`
- editable files: `Benchmark/Generated/Reserve/AuctionPriceBand/Tasks/PriceAtEndTime.lean`
- implementation files: `cases/reserve/auction_price_band/verity/Contract.lean, Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`
- specification files: `cases/reserve/auction_price_band/verity/Specs.lean, Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`: def D18 : Uint256
- `Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`: def D27 : Uint256
- `Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`: structure PriceRange where
- `Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`: def auctionOngoing
- `Benchmark/Cases/Reserve/AuctionPriceBand/Contract.lean`: structure InteriorSafe
- `Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`: def price_at_start_time_spec
- `Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`: def price_at_end_time_spec
- `Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`: def price_lower_bound_spec
- `Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`: def price_upper_bound_spec
- `Benchmark/Cases/Reserve/AuctionPriceBand/Specs.lean`: def band_well_formed_spec

### Current Editable File

`Benchmark/Generated/Reserve/AuctionPriceBand/Tasks/PriceAtEndTime.lean`

```lean
import Benchmark.Cases.Reserve.AuctionPriceBand.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Reserve.AuctionPriceBand

open Verity
open Verity.EVM.Uint256

/--
At `block_timestamp = auction_endTime` and `auction_startTime ≠ auction_endTime`,
`_price` returns `endPrice`.
-/
theorem price_at_end_time
    (sellPrices buyPrices : PriceRange)
    (auction_startTime auction_endTime : Uint256)
    (hStartNeEnd : auction_startTime ≠ auction_endTime) :
    price_at_end_time_spec sellPrices buyPrices auction_startTime auction_endTime := by
  exact ?_

end Benchmark.Cases.Reserve.AuctionPriceBand
```
