# Run 20260811T191651-default-fair-gpt-5-6-luna-lifi__swap_atomicity__final_transfer_implies_all_steps_succeeded

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lifi/swap_atomicity
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `lifi/swap_atomicity/final_transfer_implies_all_steps_succeeded`: forbidden_placeholder
