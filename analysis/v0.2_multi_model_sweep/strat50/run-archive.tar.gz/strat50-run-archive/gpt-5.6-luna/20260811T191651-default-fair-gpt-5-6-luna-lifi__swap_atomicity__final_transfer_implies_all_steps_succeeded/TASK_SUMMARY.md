# Verity Task Summary

- group: `lifi/swap_atomicity/final_transfer_implies_all_steps_succeeded`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `lifi/swap_atomicity/final_transfer_implies_all_steps_succeeded`

- theorem: `Benchmark.Cases.LiFi.SwapAtomicity.final_transfer_implies_all_steps_succeeded`
- target module: `Benchmark.Generated.LiFi.SwapAtomicity.Tasks.FinalTransferImpliesAllStepsSucceeded`
- editable files: `Benchmark/Generated/LiFi/SwapAtomicity/Tasks/FinalTransferImpliesAllStepsSucceeded.lean`
- implementation files: `cases/lifi/swap_atomicity/verity/Contract.lean, Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`
- specification files: `cases/lifi/swap_atomicity/verity/Specs.lean, Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: structure SwapStep where
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def depositForStepSucceeds (step : SwapStep) : Bool
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def depositsSucceed : List SwapStep → Bool
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def requiredDepositCount : List SwapStep → Nat
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: structure RouteGuards where
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def stepPreconditionsHold (step : SwapStep) : Bool
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def stepSucceeds (step : SwapStep) : Bool
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def executeSwapsCount : List SwapStep → Option Nat
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: structure RouteCommit where
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def depositAndSwap (route : RouteGuards) (minAmount outputAmount : Nat)
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def routeGateFails (route : RouteGuards) (steps : List SwapStep) : Prop
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def finalTransferCommitted (result : Option RouteCommit) : Bool
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def committedSwapCount (result : Option RouteCommit) : Nat
- `Benchmark/Cases/LiFi/SwapAtomicity/Contract.lean`: def allStepsSucceeded (steps : List SwapStep) : Prop
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def failed_step_reverts_spec (steps : List SwapStep) : Prop
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def no_final_transfer_on_failed_step_spec
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def final_transfer_implies_all_steps_succeeded_spec
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def committed_route_executes_every_step_spec
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def min_output_required_for_commit_spec
- `Benchmark/Cases/LiFi/SwapAtomicity/Specs.lean`: def route_gate_failure_prevents_commit_spec

### Current Editable File

`Benchmark/Generated/LiFi/SwapAtomicity/Tasks/FinalTransferImpliesAllStepsSucceeded.lean`

```lean
import Benchmark.Cases.LiFi.SwapAtomicity.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.LiFi.SwapAtomicity

open Verity
open Verity.EVM.Uint256

/-- A committed final transfer means every modeled LI.FI route step succeeded. -/
theorem final_transfer_implies_all_steps_succeeded
    (route : RouteGuards) (steps : List SwapStep)
    (minAmount outputAmount : Nat) :
    final_transfer_implies_all_steps_succeeded_spec
      route steps minAmount outputAmount := by
  exact ?_

end Benchmark.Cases.LiFi.SwapAtomicity
```
