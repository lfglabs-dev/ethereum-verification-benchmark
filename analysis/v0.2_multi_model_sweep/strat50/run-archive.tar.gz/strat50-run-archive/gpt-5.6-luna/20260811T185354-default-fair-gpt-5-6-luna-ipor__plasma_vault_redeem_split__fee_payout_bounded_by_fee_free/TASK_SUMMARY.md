# Verity Task Summary

- group: `ipor/plasma_vault_redeem_split/fee_payout_bounded_by_fee_free`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `ipor/plasma_vault_redeem_split/fee_payout_bounded_by_fee_free`

- theorem: `Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.fee_payout_bounded_by_fee_free`
- target module: `Benchmark.Generated.IPOR.PlasmaVaultRedeemSplit.Tasks.FeePayoutBoundedByFeeFree`
- editable files: `Benchmark/Generated/IPOR/PlasmaVaultRedeemSplit/Tasks/FeePayoutBoundedByFeeFree.lean`
- implementation files: `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean, Benchmark/Cases/IPOR/PlasmaVaultRedeemSplit/Contract.lean`
- specification files: `cases/ipor/plasma_vault_redeem_split/verity/Specs.lean, Benchmark/Cases/IPOR/PlasmaVaultRedeemSplit/Specs.lean`

### Relevant Symbols

- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def WAD : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def virtualShares : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: structure VaultState where
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def convertToAssets (amountShares : Nat) (s : VaultState) (m : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def feeShares (amountShares feeRate : Nat) : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def redeemPayout (amountShares feeRate : Nat) (s : VaultState) (m : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def redeem (amountShares feeRate : Nat) (s : VaultState) (m : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def feeFreePayout (amountShares : Nat) (s : VaultState) (m : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Contract.lean`: def ppsCrossNondecreasing (before after : VaultState) (m : Nat
- `cases/ipor/plasma_vault_redeem_split/verity/Specs.lean`: def validRedeemInput
- `cases/ipor/plasma_vault_redeem_split/verity/Specs.lean`: def redeem_preserves_pps_spec
- `cases/ipor/plasma_vault_redeem_split/verity/Specs.lean`: def fee_payout_bounded_by_fee_free_spec
- `cases/ipor/plasma_vault_redeem_split/verity/Specs.lean`: def final_security_claim

### Current Editable File

`Benchmark/Generated/IPOR/PlasmaVaultRedeemSplit/Tasks/FeePayoutBoundedByFeeFree.lean`

```lean
import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem fee_payout_bounded_by_fee_free_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    fee_payout_bounded_by_fee_free_spec amountShares feeRate s m := by
  exact ?_

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit
```
