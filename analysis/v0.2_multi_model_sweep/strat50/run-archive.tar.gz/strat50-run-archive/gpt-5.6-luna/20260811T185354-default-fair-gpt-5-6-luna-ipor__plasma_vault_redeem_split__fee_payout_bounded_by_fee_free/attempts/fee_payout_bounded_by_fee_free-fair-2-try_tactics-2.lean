import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem fee_payout_bounded_by_fee_free_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    fee_payout_bounded_by_fee_free_spec amountShares feeRate s m := by
  intro h
    unfold fee_payout_bounded_by_fee_free_spec redeemPayout feeFreePayout convertToAssets
    have hfee : amountShares * feeRate / WAD ≤ amountShares := by
      exact Nat.div_le_of_le_mul (by omega)
    exact Nat.div_le_div_right (Nat.mul_le_mul_right (s.assets + 1) (Nat.sub_le amountShares (amountShares * feeRate / WAD)))

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

