# Verity Task Summary

- group: `forgeyields/global_solvency/handle_preserves_global_solvency`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `forgeyields/global_solvency/handle_preserves_global_solvency`

- theorem: `Benchmark.Cases.ForgeYields.GlobalSolvency.handle_preserves_global_solvency`
- target module: `Benchmark.Generated.ForgeYields.GlobalSolvency.Tasks.HandlePreservesGlobalSolvency`
- editable files: `Benchmark/Generated/ForgeYields/GlobalSolvency/Tasks/HandlePreservesGlobalSolvency.lean`
- implementation files: `cases/forgeyields/global_solvency/verity/Contract.lean, Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`
- specification files: `cases/forgeyields/global_solvency/verity/Specs.lean, Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: storage assetBalance : Uint256 := slot 0
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: storage buffer : Uint256 := slot 1
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: storage assetsLocked : Uint256 := slot 2
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: storage depreciated : Uint256 := slot 3
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function deposit (assets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function requestRedeem (assets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function claimRedeem (assets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function redeemTokenGatewayDepreciated (assets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function transferRemote (assets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function handle (assetsIn : Uint256, lockAssets : Uint256) : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Contract.lean`: Benchmark.Cases.ForgeYields.GlobalSolvency.function report () : Unit := do
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def assetBalanceOf (s : ContractState) : Uint256
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def bufferOf (s : ContractState) : Uint256
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def assetsLockedOf (s : ContractState) : Uint256
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def depreciatedOf (s : ContractState) : Uint256
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def global_solvency_spec (s : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def deposit_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def requestRedeem_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def claimRedeem_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def redeemTokenGatewayDepreciated_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def transferRemote_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def handle_preserves_global_solvency_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/ForgeYields/GlobalSolvency/Specs.lean`: def report_preserves_global_solvency_spec (s s' : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/ForgeYields/GlobalSolvency/Tasks/HandlePreservesGlobalSolvency.lean`

```lean
import Benchmark.Cases.ForgeYields.GlobalSolvency.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.ForgeYields.GlobalSolvency

open Verity
open Verity.EVM.Uint256

theorem handle_preserves_global_solvency
    (assetsIn lockAssets : Uint256) (s : ContractState)
    (hActive : s.storage 3 = 0)
    (hAssetNoOverflow : (s.storage 0).val + assetsIn.val < Verity.Core.Uint256.modulus)
    (hBufferNoOverflow : (s.storage 1).val + assetsIn.val < Verity.Core.Uint256.modulus)
    (hLockedNoOverflow : (s.storage 2).val + lockAssets.val < Verity.Core.Uint256.modulus)
    (hLockLeBufferIn : lockAssets.val <= (s.storage 1).val + assetsIn.val) :
    let s' := ((TokenGateway.handle assetsIn lockAssets).run s).snd
    handle_preserves_global_solvency_spec s s' := by
  exact ?_

end Benchmark.Cases.ForgeYields.GlobalSolvency
```
