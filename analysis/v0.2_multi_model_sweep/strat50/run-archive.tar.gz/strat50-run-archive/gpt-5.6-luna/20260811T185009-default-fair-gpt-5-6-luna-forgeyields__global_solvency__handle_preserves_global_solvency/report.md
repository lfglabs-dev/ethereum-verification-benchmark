# Run 20260811T185009-default-fair-gpt-5-6-luna-forgeyields__global_solvency__handle_preserves_global_solvency

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: forgeyields/global_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `forgeyields/global_solvency/handle_preserves_global_solvency`: lean_check_failed
