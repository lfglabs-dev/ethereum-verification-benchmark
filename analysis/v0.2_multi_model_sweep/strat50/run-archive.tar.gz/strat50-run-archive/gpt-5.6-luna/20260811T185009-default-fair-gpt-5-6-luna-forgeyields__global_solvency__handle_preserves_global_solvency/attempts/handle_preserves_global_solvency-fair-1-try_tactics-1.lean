import Benchmark.Cases.ForgeYields.GlobalSolvency.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.ForgeYields.GlobalSolvency

open Verity
open Verity.EVM.Uint256

theorem handle_preserves_global_solvency
    (assetsIn lockAssets : Uint256) (s : ContractState)
    (hActive : s.storage 3 = 0)
    (hAssetNoOverflow : (s.storage 0).val + assetsIn.val < Verity.Core.Uint256.modulus)
    (hBufferNoOverflow : (s.storage 1).val + assetsIn.val < Verity.Core.Uint256.modulus)
    (hLockedNoOverflow : (s.storage 2).val + lockAssets.val < Verity.Core.Uint256.modulus)
    (hLockLeBufferIn : lockAssets.val <= (s.storage 1).val + assetsIn.val) :
    let s' := ((TokenGateway.handle assetsIn lockAssets).run s).snd
    handle_preserves_global_solvency_spec s s' := by
  simp only [grind_norm] at *
  unfold handle_preserves_global_solvency_spec
  tsimp [grind_norm, TokenGateway.handle, TokenGateway.assetBalance, TokenGateway.buffer, TokenGateway.assetsLocked, TokenGateway.depreciated, assetBalanceOf, bufferOf, assetsLockedOf, depreciatedOf, global_solvency_spec, *]
  all_goals try (split_ifs <;> simp_all [grind_norm])
  all_goals omega

end Benchmark.Cases.ForgeYields.GlobalSolvency

