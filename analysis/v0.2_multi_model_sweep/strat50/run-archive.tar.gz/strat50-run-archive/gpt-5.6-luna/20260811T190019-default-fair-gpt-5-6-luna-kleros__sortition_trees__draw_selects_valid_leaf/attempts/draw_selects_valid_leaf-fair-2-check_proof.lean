import Benchmark.Cases.Kleros.SortitionTrees.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Kleros.SortitionTrees

open Verity
open Verity.EVM.Uint256

/--
Any successful `draw` resolves to one of the four leaf node indices.
-/
theorem draw_selects_valid_leaf
    (ticket : Uint256) (s : ContractState)
    (hRoot : s.storage 0 != 0)
    (hInRange : ticket < s.storage 0) :
    let s' := ((SortitionTrees.draw ticket).run s).snd
    draw_selects_valid_leaf_spec s' := by
  simp only [grind_norm] at *
    unfold draw_selects_valid_leaf_spec
    simp [grind_norm, SortitionTrees.draw, SortitionTrees.rootSum, SortitionTrees.leftSum, SortitionTrees.leaf0, SortitionTrees.leaf2, SortitionTrees.selectedNode, *]
    all_goals split_ifs <;> simp_all [grind_norm]
    all_goals decide

end Benchmark.Cases.Kleros.SortitionTrees

