# Verity Task Summary

- group: `kleros/sortition_trees/draw_selects_valid_leaf`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `kleros/sortition_trees/draw_selects_valid_leaf`

- theorem: `Benchmark.Cases.Kleros.SortitionTrees.draw_selects_valid_leaf`
- target module: `Benchmark.Generated.Kleros.SortitionTrees.Tasks.DrawSelectsValidLeaf`
- editable files: `Benchmark/Generated/Kleros/SortitionTrees/Tasks/DrawSelectsValidLeaf.lean`
- implementation files: `cases/kleros/sortition_trees/verity/Contract.lean, Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`
- specification files: `cases/kleros/sortition_trees/verity/Specs.lean, Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage rootSum : Uint256 := slot 0
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage leftSum : Uint256 := slot 1
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage rightSum : Uint256 := slot 2
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage leaf0 : Uint256 := slot 3
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage leaf1 : Uint256 := slot 4
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage leaf2 : Uint256 := slot 5
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage leaf3 : Uint256 := slot 6
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage nodeIndexesToIDs : Uint256 → Uint256 := slot 7
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage IDsToNodeIndexes : Uint256 → Uint256 := slot 8
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: storage selectedNode : Uint256 := slot 9
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: Benchmark.Cases.Kleros.SortitionTrees.function setLeaf (nodeIndex : Uint256, stakePathID : Uint256, weight : Uint256) : Unit := do
- `Benchmark/Cases/Kleros/SortitionTrees/Contract.lean`: Benchmark.Cases.Kleros.SortitionTrees.function draw (ticket : Uint256) : Uint256 := do
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def leaf_sum (s : ContractState) : Uint256
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def parent_equals_sum_of_children_spec (s' : ContractState) : Prop
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def root_equals_sum_of_leaves_spec (s' : ContractState) : Prop
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def draw_interval_matches_weights_spec (ticket : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def draw_selects_valid_leaf_spec (s' : ContractState) : Prop
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def node_id_bijection_spec (nodeIndex stakePathID : Uint256) (s' : ContractState) : Prop
- `Benchmark/Cases/Kleros/SortitionTrees/Specs.lean`: def root_minus_left_equals_right_subtree_spec (s' : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Kleros/SortitionTrees/Tasks/DrawSelectsValidLeaf.lean`

```lean
import Benchmark.Cases.Kleros.SortitionTrees.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Kleros.SortitionTrees

open Verity
open Verity.EVM.Uint256

/--
Any successful `draw` resolves to one of the four leaf node indices.
-/
theorem draw_selects_valid_leaf
    (ticket : Uint256) (s : ContractState)
    (hRoot : s.storage 0 != 0)
    (hInRange : ticket < s.storage 0) :
    let s' := ((SortitionTrees.draw ticket).run s).snd
    draw_selects_valid_leaf_spec s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Kleros.SortitionTrees
```
