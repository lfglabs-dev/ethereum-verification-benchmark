# Run 20260811T190019-default-fair-gpt-5-6-luna-kleros__sortition_trees__draw_selects_valid_leaf

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: kleros/sortition_trees
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `kleros/sortition_trees/draw_selects_valid_leaf`: lean_check_failed
