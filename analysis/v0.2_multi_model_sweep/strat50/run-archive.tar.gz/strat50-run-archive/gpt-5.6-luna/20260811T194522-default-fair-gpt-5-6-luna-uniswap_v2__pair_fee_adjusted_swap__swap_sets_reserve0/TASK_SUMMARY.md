# Verity Task Summary

- group: `uniswap_v2/pair_fee_adjusted_swap/swap_sets_reserve0`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `uniswap_v2/pair_fee_adjusted_swap/swap_sets_reserve0`

- theorem: `Benchmark.Cases.UniswapV2.PairFeeAdjustedSwap.applySwap_sets_reserve0`
- target module: `Benchmark.Generated.UniswapV2.PairFeeAdjustedSwap.Tasks.SwapSetsReserve0`
- editable files: `Benchmark/Generated/UniswapV2/PairFeeAdjustedSwap/Tasks/SwapSetsReserve0.lean`
- implementation files: `cases/uniswap_v2/pair_fee_adjusted_swap/verity/Contract.lean, Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Contract.lean`
- specification files: `cases/uniswap_v2/pair_fee_adjusted_swap/verity/Specs.lean, Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Contract.lean`: storage reserve0 : Uint256 := slot 0
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Contract.lean`: storage reserve1 : Uint256 := slot 1
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Contract.lean`: Benchmark.Cases.UniswapV2.PairFeeAdjustedSwap.function applySwap
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_sets_reserve0_spec
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_sets_reserve1_spec
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_sets_reserve_product_spec
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_enforces_fee_adjusted_invariant_spec
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_two_swap_k_monotone_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/UniswapV2/PairFeeAdjustedSwap/Specs.lean`: def applySwap_swap_sandwich_output_bound_spec

### Current Editable File

`Benchmark/Generated/UniswapV2/PairFeeAdjustedSwap/Tasks/SwapSetsReserve0.lean`

```lean
import Benchmark.Cases.UniswapV2.PairFeeAdjustedSwap.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.UniswapV2.PairFeeAdjustedSwap

open Verity
open Verity.EVM.Uint256

/--
Executing `applySwap` stores the observed `balance0` as `reserve0`.
-/
theorem applySwap_sets_reserve0
    (balance0 balance1 amount0In amount1In : Uint256) (s : ContractState)
    (hInput : amount0In != 0 || amount1In != 0)
    (hFee0 : mul balance0 1000 >= mul amount0In 3)
    (hFee1 : mul balance1 1000 >= mul amount1In 3)
    (hK : mul (sub (mul balance0 1000) (mul amount0In 3))
        (sub (mul balance1 1000) (mul amount1In 3))
        >= mul (mul (s.storage 0) (s.storage 1)) 1000000) :
    let s' := ((PairFeeAdjustedSwap.applySwap balance0 balance1 amount0In amount1In).run s).snd
    applySwap_sets_reserve0_spec balance0 s s' := by
  exact ?_

end Benchmark.Cases.UniswapV2.PairFeeAdjustedSwap
```
