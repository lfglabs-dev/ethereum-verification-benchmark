# Run 20260811T194522-default-fair-gpt-5-6-luna-uniswap_v2__pair_fee_adjusted_swap__swap_sets_reserve0

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: uniswap_v2/pair_fee_adjusted_swap
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `uniswap_v2/pair_fee_adjusted_swap/swap_sets_reserve0`: passed
