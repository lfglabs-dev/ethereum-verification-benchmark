# Verity Task Summary

- group: `termmax/order_v2_buy_xt_single_segment/swap_debt_token_to_xt_updates_virtual_xt_reserve`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `termmax/order_v2_buy_xt_single_segment/swap_debt_token_to_xt_updates_virtual_xt_reserve`

- theorem: `Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment.swapDebtTokenToXt_updates_virtual_xt_reserve`
- target module: `Benchmark.Generated.TermMax.OrderV2BuyXtSingleSegment.Tasks.SwapDebtTokenToXtUpdatesVirtualXtReserve`
- editable files: `Benchmark/Generated/TermMax/OrderV2BuyXtSingleSegment/Tasks/SwapDebtTokenToXtUpdatesVirtualXtReserve.lean`
- implementation files: `cases/termmax/order_v2_buy_xt_single_segment/verity/Contract.lean, Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`
- specification files: `cases/termmax/order_v2_buy_xt_single_segment/verity/Specs.lean, Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: structure as faithfully as the current `verity_contract` macro path allows.
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: def plusInt256 (a : Uint256) (b : Int256) : Uint256
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: def singleSegmentScaledLiqSquare
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: def singleSegmentBuyXtTokenAmtOut
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: storage virtualXtReserve : Uint256 := slot 0
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: storage nonReentrancyLock : Uint256 := slot 1
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment.function calcIntervalProps
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment.function cutsReverseIter
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Contract.lean`: Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment.function buyXtCurve
- `Benchmark/Cases/TermMax/OrderV2BuyXtSingleSegment/Specs.lean`: def swapDebtTokenToXt_updates_virtual_xt_reserve_spec

### Current Editable File

`Benchmark/Generated/TermMax/OrderV2BuyXtSingleSegment/Tasks/SwapDebtTokenToXtUpdatesVirtualXtReserve.lean`

```lean
import Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment

open Verity
open Verity.EVM.Uint256

/--
Executing the single-segment exact-input `debtToken -> XT` pricing path updates
`virtualXtReserve` by exactly the curve-computed XT output amount.
-/
theorem swapDebtTokenToXt_updates_virtual_xt_reserve
    (daysToMaturity debtTokenAmtIn minTokenOut : Uint256)
    (borrowTakerFeeRatio lendMakerFeeRatio : Uint256)
    (cutLiqSquare : Uint256) (cutOffset : Int256)
    (s : ContractState)
    (hNonZeroInput : debtTokenAmtIn != 0)
    (hLockOpen : s.storage 1 = 0)
    (hVXtNonZero : plusInt256 (s.storage 0) cutOffset != 0)
    (hNoCross :
      singleSegmentBuyXtTokenAmtOut
          daysToMaturity
          (s.storage 0)
          debtTokenAmtIn
          borrowTakerFeeRatio
          cutLiqSquare
          cutOffset
        <= s.storage 0)
    (hMinOut :
      add
          (singleSegmentBuyXtTokenAmtOut
            daysToMaturity
            (s.storage 0)
            debtTokenAmtIn
            borrowTakerFeeRatio
            cutLiqSquare
            cutOffset)
          debtTokenAmtIn
        >= minTokenOut) :
    let s' := ((
      TermMaxOrderV2BuyXtSingleSegment.swapDebtTokenToXtExactInSingleSegment
        debtTokenAmtIn
        minTokenOut
        daysToMaturity
        borrowTakerFeeRatio
        lendMakerFeeRatio
        cutLiqSquare
        cutOffset
      ).run s).snd
    swapDebtTokenToXt_updates_virtual_xt_reserve_spec
      daysToMaturity
      debtTokenAmtIn
      borrowTakerFeeRatio
      cutLiqSquare
      cutOffset
      s
      s' := by
  exact ?_

end Benchmark.Cases.TermMax.OrderV2BuyXtSingleSegment
```
