# Run 20260811T194400-default-fair-gpt-5-6-luna-termmax__order_v2_buy_xt_single_segment__swap_debt_token_to_xt_updates_virtual_xt_reserve

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: termmax/order_v2_buy_xt_single_segment
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `termmax/order_v2_buy_xt_single_segment/swap_debt_token_to_xt_updates_virtual_xt_reserve`: forbidden_placeholder
