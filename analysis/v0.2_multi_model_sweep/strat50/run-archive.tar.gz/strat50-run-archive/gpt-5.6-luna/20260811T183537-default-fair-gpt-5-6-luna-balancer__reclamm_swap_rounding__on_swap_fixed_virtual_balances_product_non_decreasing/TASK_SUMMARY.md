# Verity Task Summary

- group: `balancer/reclamm_swap_rounding/on_swap_fixed_virtual_balances_product_non_decreasing`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `balancer/reclamm_swap_rounding/on_swap_fixed_virtual_balances_product_non_decreasing`

- theorem: `Benchmark.Cases.Balancer.ReClammSwapRounding.onSwap_fixed_virtual_balances_product_non_decreasing`
- target module: `Benchmark.Generated.Balancer.ReClammSwapRounding.Tasks.OnSwapFixedVirtualBalancesProductNonDecreasing`
- editable files: `Benchmark/Generated/Balancer/ReClammSwapRounding/Tasks/OnSwapFixedVirtualBalancesProductNonDecreasing.lean`
- implementation files: `cases/balancer/reclamm_swap_rounding/verity/Contract.lean, Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`
- specification files: `cases/balancer/reclamm_swap_rounding/verity/Specs.lean, Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: theorem surfaces no-overflow hypotheses for the multiplication/addition
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: def a : Uint256
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: def b : Uint256
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: def mulDivUp (x y denominator : Uint256) : Uint256
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: Benchmark.Cases.Balancer.ReClammSwapRounding.function computeOutGivenIn
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: Benchmark.Cases.Balancer.ReClammSwapRounding.function computeInGivenOut
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Contract.lean`: Benchmark.Cases.Balancer.ReClammSwapRounding.function onSwap
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def balanceOf (tokenIndex balanceA balanceB : Uint256) : Uint256
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def virtualBalanceOf (tokenIndex virtualBalanceA virtualBalanceB : Uint256) : Uint256
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def totalNat (balance virtualBalance : Uint256) : Nat
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def L_before
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def postBalanceA
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def postBalanceB
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def L_after
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def onSwap_no_overflow_assumptions
- `Benchmark/Cases/Balancer/ReClammSwapRounding/Specs.lean`: def onSwap_fixed_virtual_balances_product_non_decreasing_spec

### Current Editable File

`Benchmark/Generated/Balancer/ReClammSwapRounding/Tasks/OnSwapFixedVirtualBalancesProductNonDecreasing.lean`

```lean
import Benchmark.Cases.Balancer.ReClammSwapRounding.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Balancer.ReClammSwapRounding

open Verity
open Verity.EVM.Uint256

/--
ReClamm swap rounding invariant.

For any successful exact-in or exact-out `onSwap` quote, with the current
virtual balances held fixed during the quote, applying the returned real-balance
deltas does not decrease:

  `(balanceA + virtualBalanceA) * (balanceB + virtualBalanceB)`.
-/
theorem onSwap_fixed_virtual_balances_product_non_decreasing
    (exactIn : Bool)
    (balanceA balanceB virtualBalanceA virtualBalanceB : Uint256)
    (indexIn indexOut amountGivenScaled18 amountCalculatedScaled18 : Uint256)
    (s : ContractState)
    -- Valid route condition for the two-token ReClamm pool: A -> B or B -> A.
    -- The scalar model keeps this explicit because token indexes are raw inputs.
    (hTokenPair : (indexIn = 0 ∧ indexOut = 1) ∨ (indexIn = 1 ∧ indexOut = 0))
    (hNoOverflow :
      onSwap_no_overflow_assumptions exactIn balanceA balanceB
        virtualBalanceA virtualBalanceB indexIn indexOut amountGivenScaled18)
    (hRun :
      (ReClammPool.onSwap exactIn balanceA balanceB virtualBalanceA virtualBalanceB
        indexIn indexOut amountGivenScaled18).run s =
        ContractResult.success amountCalculatedScaled18 s) :
    onSwap_fixed_virtual_balances_product_non_decreasing_spec
      exactIn balanceA balanceB virtualBalanceA virtualBalanceB
      indexIn indexOut amountGivenScaled18 amountCalculatedScaled18 := by
  exact ?_

end Benchmark.Cases.Balancer.ReClammSwapRounding
```
