# Verity Task Summary

- group: `nexus_mutual/ramm_price_band/sync_sets_sell_price`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `nexus_mutual/ramm_price_band/sync_sets_sell_price`

- theorem: `Benchmark.Cases.NexusMutual.RammPriceBand.syncPriceBand_sets_sell_price`
- target module: `Benchmark.Generated.NexusMutual.RammPriceBand.Tasks.SyncSetsSellPrice`
- editable files: `Benchmark/Generated/NexusMutual/RammPriceBand/Tasks/SyncSetsSellPrice.lean`
- implementation files: `cases/nexus_mutual/ramm_price_band/verity/Contract.lean, Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`
- specification files: `cases/nexus_mutual/ramm_price_band/verity/Specs.lean, Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: storage capital : Uint256 := slot 0
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: storage supply : Uint256 := slot 1
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: storage bookValue : Uint256 := slot 2
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: storage buySpotPrice : Uint256 := slot 3
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: storage sellSpotPrice : Uint256 := slot 4
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: Benchmark.Cases.NexusMutual.RammPriceBand.function syncPriceBand (capital_ : Uint256, supply_ : Uint256) : Unit := do
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def PRICE_BUFFER : Uint256
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def PRICE_BUFFER_DENOMINATOR : Uint256
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def RATCHET_PERIOD : Uint256
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def RATCHET_DENOMINATOR : Uint256
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def ONE_ETHER : Uint256
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def calculateBuyReserve
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def calculateSellReserve
- `Benchmark/Cases/NexusMutual/RammPriceBand/Contract.lean`: def spotPrices
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def syncPriceBand_sets_capital_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def syncPriceBand_sets_book_value_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def syncPriceBand_sets_buy_price_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def syncPriceBand_sets_sell_price_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def syncPriceBand_sell_le_buy_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def spotPrice_buy_ge_book_value_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def spotPrice_sell_le_book_value_spec
- `Benchmark/Cases/NexusMutual/RammPriceBand/Specs.lean`: def spotPrice_sell_le_buy_spec

### Current Editable File

`Benchmark/Generated/NexusMutual/RammPriceBand/Tasks/SyncSetsSellPrice.lean`

```lean
import Benchmark.Cases.NexusMutual.RammPriceBand.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.NexusMutual.RammPriceBand

open Verity
open Verity.EVM.Uint256

/--
Executing `syncPriceBand` stores the synchronized sell quote.
-/
theorem syncPriceBand_sets_sell_price
    (capital_ supply_ : Uint256) (s : ContractState)
    (hSupply : supply_ != 0) :
    let s' := ((RammPriceBand.syncPriceBand capital_ supply_).run s).snd
    syncPriceBand_sets_sell_price_spec capital_ supply_ s s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.NexusMutual.RammPriceBand
```
