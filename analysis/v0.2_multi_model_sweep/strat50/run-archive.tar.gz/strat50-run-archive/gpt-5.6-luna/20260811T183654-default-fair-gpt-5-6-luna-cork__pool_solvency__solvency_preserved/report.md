# Run 20260811T183654-default-fair-gpt-5-6-luna-cork__pool_solvency__solvency_preserved

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: cork/pool_solvency
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `cork/pool_solvency/solvency_preserved`: forbidden_placeholder
