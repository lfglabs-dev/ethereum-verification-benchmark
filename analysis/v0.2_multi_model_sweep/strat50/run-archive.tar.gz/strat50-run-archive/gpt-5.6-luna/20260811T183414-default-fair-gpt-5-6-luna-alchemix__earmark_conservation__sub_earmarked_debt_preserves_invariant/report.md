# Run 20260811T183414-default-fair-gpt-5-6-luna-alchemix__earmark_conservation__sub_earmarked_debt_preserves_invariant

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: alchemix/earmark_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `alchemix/earmark_conservation/sub_earmarked_debt_preserves_invariant`: forbidden_placeholder
