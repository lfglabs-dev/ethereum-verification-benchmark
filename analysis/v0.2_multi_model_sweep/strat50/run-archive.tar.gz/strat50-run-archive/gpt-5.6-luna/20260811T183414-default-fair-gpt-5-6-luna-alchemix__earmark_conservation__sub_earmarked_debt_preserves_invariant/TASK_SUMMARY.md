# Verity Task Summary

- group: `alchemix/earmark_conservation/sub_earmarked_debt_preserves_invariant`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `alchemix/earmark_conservation/sub_earmarked_debt_preserves_invariant`

- theorem: `Benchmark.Cases.Alchemix.EarmarkConservation._subEarmarkedDebt_preserves_invariant`
- target module: `Benchmark.Generated.Alchemix.EarmarkConservation.Tasks.SubEarmarkedDebtPreservesInvariant`
- editable files: `Benchmark/Generated/Alchemix/EarmarkConservation/Tasks/SubEarmarkedDebtPreservesInvariant.lean`
- implementation files: `cases/alchemix/earmark_conservation/verity/Contract.lean, Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`
- specification files: `cases/alchemix/earmark_conservation/verity/Specs.lean, Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: def ONE_Q128 : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: def mulQ128 (a b : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: def divQ128 (a b : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: storage cumulativeEarmarked : Uint256 := slot 0
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: storage totalDebt : Uint256 := slot 1
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: storage _earmarkWeight : Uint256 := slot 2
- `Benchmark/Cases/Alchemix/EarmarkConservation/Contract.lean`: storage _redemptionWeight : Uint256 := slot 3
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: abbrev FiniteSet
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def cumulativeEarmarked (s : ContractState) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def totalDebt (s : ContractState) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def _earmarkWeight (s : ContractState) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def _redemptionWeight (s : ContractState) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def _survivalAccumulator (s : ContractState) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def accounts_debt (s : ContractState) (id : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def accounts_earmarked (s : ContractState) (id : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def accounts_lastAccruedEarmarkWeight (s : ContractState) (id : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def accounts_lastAccruedRedemptionWeight (s : ContractState) (id : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: structure ComputeUnrealizedAccountResult where
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def _computeUnrealizedAccount (s : ContractState) (id : Uint256)
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def projectedEarmarked (s : ContractState) (id : Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def sumProjectedEarmarked (s : ContractState) (ids : FiniteSet Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def sumStoredEarmarked (s : ContractState) (ids : FiniteSet Uint256) : Uint256
- `Benchmark/Cases/Alchemix/EarmarkConservation/Specs.lean`: def earmark_conservation_spec

### Current Editable File

`Benchmark/Generated/Alchemix/EarmarkConservation/Tasks/SubEarmarkedDebtPreservesInvariant.lean`

```lean
import Benchmark.Cases.Alchemix.EarmarkConservation.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Alchemix.EarmarkConservation

open Verity
open Verity.EVM.Uint256

/--
Preservation of the lazy-projected earmark conservation invariant under
`subEarmarkedDebt(amount, accountId)`.

The operation reduces both the stored `accounts_earmarked[accountId]`
and the global `cumulativeEarmarked` by the same `earmarkToRemove =
min(min(amount, debt), earmarked)`. Under the invariant pre-state
plus the synced-at-accountId precondition, both decrements coincide
and the per-id projection at `accountId` drops by `earmarkToRemove`
(synced shortcut), while projections at all other ids are unchanged.

Hypotheses on the placeholder (all acceptable):

  * `hQ128MulOne` — Q128 idealization (see other tasks). Disclosed in
    `Contract.lean`.
  * `hSyncedAtAccountId` — pre-state weight snapshots match the
    global weights at `accountId`. Source enforces this by calling
    `_sync(id)` at every site that calls `_subEarmarkedDebt(.., id)`
    (lines 567, 590, 869, 1052).
  * `hAccountEarmarkedLeCumulative` — operational pre-condition that
    the line-1015 min-clamp does not activate. Justified by the
    invariant + accountId ∈ ids: at a synced account the projection
    equals the stored earmarked, and any single summand is ≤ the
    sum, which equals `cumulativeEarmarked` by the invariant.
-/
theorem _subEarmarkedDebt_preserves_invariant
    (s : ContractState)
    (ids : Verity.Core.FiniteSet Uint256)
    (amountInDebtTokens accountId : Uint256)
    (hQ128MulOne : ∀ x : Uint256, mulQ128 x ONE_Q128 = x)
    (hSyncedAtAccountId :
      accounts_lastAccruedEarmarkWeight s accountId = _earmarkWeight s ∧
      accounts_lastAccruedRedemptionWeight s accountId = _redemptionWeight s)
    (hAccountEarmarkedLeCumulative :
      accounts_earmarked s accountId ≤ cumulativeEarmarked s) :
    let s' := ((AlchemistV3._subEarmarkedDebt amountInDebtTokens accountId).run s).snd
    _subEarmarkedDebt_preserves_invariant_spec s s' ids accountId := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.Alchemix.EarmarkConservation
```
