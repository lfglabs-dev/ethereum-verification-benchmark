# Verity Task Summary

- group: `paladin_votes/stream_recovery_claim_usdc/both_claim_marks_both_claimed`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `paladin_votes/stream_recovery_claim_usdc/both_claim_marks_both_claimed`

- theorem: `Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.claimBoth_marks_both_claimed`
- target module: `Benchmark.Generated.PaladinVotes.StreamRecoveryClaimUsdc.Tasks.BothClaimMarksBothClaimed`
- editable files: `Benchmark/Generated/PaladinVotes/StreamRecoveryClaimUsdc/Tasks/BothClaimMarksBothClaimed.lean`
- implementation files: `cases/paladin_votes/stream_recovery_claim_usdc/verity/Contract.lean, Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`
- specification files: `cases/paladin_votes/stream_recovery_claim_usdc/verity/Specs.lean, Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage roundUsdcTotal : Uint256 := slot 0
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage roundUsdcClaimed : Uint256 := slot 1
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage totalUsdcAllocated : Uint256 := slot 2
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage roundActive : Uint256 := slot 3
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage hasSignedWaiver : Address → Uint256 := slot 4
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage hasClaimedUsdc : Address → Uint256 := slot 5
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage roundWethTotal : Uint256 := slot 6
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage roundWethClaimed : Uint256 := slot 7
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage totalWethAllocated : Uint256 := slot 8
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: storage hasClaimedWeth : Address → Uint256 := slot 9
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.function claimUsdc (shareWad : Uint256, proofAccepted : Bool) : Uint256 := do
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.function claimableUsdc (shareWad : Uint256) : Uint256 := do
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.function claimWeth (shareWad : Uint256, proofAccepted : Bool) : Uint256 := do
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Contract.lean`: Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.function claimBoth
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def computedClaimAmount (shareWad : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def computedWethClaimAmount (shareWad : Uint256) (s : ContractState) : Uint256
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_marks_claimed_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_updates_round_claimed_spec (shareWad : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_updates_total_allocated_spec (shareWad : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_claimed_plus_allocated_conserved_spec (_shareWad : Uint256) (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_preserves_round_bound_spec (s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_reverts_if_already_claimed_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_reverts_if_exceeds_total_spec (s s' : ContractState) : Prop
- `Benchmark/Cases/PaladinVotes/StreamRecoveryClaimUsdc/Specs.lean`: def claimUsdc_preserves_weth_state_spec (s s' : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/PaladinVotes/StreamRecoveryClaimUsdc/Tasks/BothClaimMarksBothClaimed.lean`

```lean
import Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc

open Verity
open Verity.EVM.Uint256

/--
Executing `claimBoth` on the successful path marks the caller as claimed for
both tokens.
-/
theorem claimBoth_marks_both_claimed
    (usdcShareWad wethShareWad : Uint256) (s : ContractState)
    (hWaiver : s.storageMap 4 s.sender != 0)
    (hActive : s.storage 3 != 0)
    (hUsdcFresh : s.storageMap 5 s.sender = 0)
    (hWethFresh : s.storageMap 9 s.sender = 0)
    (hUsdcBound : add (s.storage 1) (computedClaimAmount usdcShareWad s) <= s.storage 0)
    (hWethBound : add (s.storage 7) (computedWethClaimAmount wethShareWad s) <= s.storage 6) :
    let s' := ((StreamRecoveryClaimUsdc.claimBoth usdcShareWad true wethShareWad true).run s).snd
    claimBoth_marks_both_claimed_spec s s' := by
  -- Replace this placeholder with a complete Lean proof.
  exact ?_

end Benchmark.Cases.PaladinVotes.StreamRecoveryClaimUsdc
```
