# Verity Task Summary

- group: `starkware/starkgate_escrow/withdraw_preserves_escrow_lower_bound`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `starkware/starkgate_escrow/withdraw_preserves_escrow_lower_bound`

- theorem: `Benchmark.Cases.Starkware.StarkgateEscrow.withdraw_preserves_escrow_lower_bound`
- target module: `Benchmark.Generated.Starkware.StarkgateEscrow.Tasks.WithdrawPreservesEscrowLowerBound`
- editable files: `Benchmark/Generated/Starkware/StarkgateEscrow/Tasks/WithdrawPreservesEscrowLowerBound.lean`
- implementation files: `cases/starkware/starkgate_escrow/verity/Contract.lean, Benchmark/Cases/Starkware/StarkgateEscrow/Contract.lean`
- specification files: `cases/starkware/starkgate_escrow/verity/Specs.lean, Benchmark/Cases/Starkware/StarkgateEscrow/Specs.lean`

### Relevant Symbols

- `cases/starkware/starkgate_escrow/verity/Contract.lean`: storage assetBalance : Uint256 := slot 0
- `cases/starkware/starkgate_escrow/verity/Contract.lean`: storage cumulativeDeposits : Uint256 := slot 1
- `cases/starkware/starkgate_escrow/verity/Contract.lean`: storage cumulativeWithdrawals : Uint256 := slot 2
- `cases/starkware/starkgate_escrow/verity/Contract.lean`: Benchmark.Cases.Starkware.StarkgateEscrow.function deposit (amount : Uint256) : Unit := do
- `cases/starkware/starkgate_escrow/verity/Contract.lean`: Benchmark.Cases.Starkware.StarkgateEscrow.function withdraw (amount : Uint256) : Unit := do
- `cases/starkware/starkgate_escrow/verity/Contract.lean`: Benchmark.Cases.Starkware.StarkgateEscrow.function depositReclaim (amount : Uint256) : Unit := do
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def assetBalanceOf (s : ContractState) : Uint256
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def cumulativeDepositsOf (s : ContractState) : Uint256
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def cumulativeWithdrawalsOf (s : ContractState) : Uint256
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def escrow_lower_bound_spec (s : ContractState) : Prop
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def deposit_preserves_escrow_lower_bound_spec (s s' : ContractState) : Prop
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def withdraw_preserves_escrow_lower_bound_spec (s s' : ContractState) : Prop
- `cases/starkware/starkgate_escrow/verity/Specs.lean`: def depositReclaim_preserves_escrow_lower_bound_spec (s s' : ContractState) : Prop

### Current Editable File

`Benchmark/Generated/Starkware/StarkgateEscrow/Tasks/WithdrawPreservesEscrowLowerBound.lean`

```lean
import Benchmark.Cases.Starkware.StarkgateEscrow.Specs

namespace Benchmark.Cases.Starkware.StarkgateEscrow

theorem withdraw_preserves_escrow_lower_bound
    (amount : Verity.Core.Uint256.Uint256) (s : ContractState)
    (hPre : escrow_lower_bound_spec s)
    (hAmountLeBalance : amount.val <= (s.storage 0).val)
    (hWithdNoOverflow : (s.storage 2).val + amount.val < Verity.Core.Uint256.modulus) :
    let s' := ((StarkgateBridge.withdraw amount).run s).snd
    withdraw_preserves_escrow_lower_bound_spec s s' := by
  exact ?_

end Benchmark.Cases.Starkware.StarkgateEscrow
```
