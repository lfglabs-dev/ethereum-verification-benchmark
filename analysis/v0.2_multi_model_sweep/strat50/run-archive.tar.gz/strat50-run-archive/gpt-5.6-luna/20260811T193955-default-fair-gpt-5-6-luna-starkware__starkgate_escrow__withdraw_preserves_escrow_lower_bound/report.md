# Run 20260811T193955-default-fair-gpt-5-6-luna-starkware__starkgate_escrow__withdraw_preserves_escrow_lower_bound

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: starkware/starkgate_escrow
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `starkware/starkgate_escrow/withdraw_preserves_escrow_lower_bound`: forbidden_placeholder
