# Run 20260811T194808-default-fair-gpt-5-6-luna-wildcat__borrow_liquidity_safety__positive_borrow_preserves_required_liquidity

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: wildcat/borrow_liquidity_safety
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `wildcat/borrow_liquidity_safety/positive_borrow_preserves_required_liquidity`: passed
