# Run 20260811T195211-default-fair-gpt-5-6-luna-zodiac__roles_decoder_faithfulness__roles_decoder_bounds_safe

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: zodiac/roles_decoder_faithfulness
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `zodiac/roles_decoder_faithfulness/roles_decoder_bounds_safe`: theorem_missing
