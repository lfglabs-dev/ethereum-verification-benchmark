# Verity Task Summary

- group: `zodiac/roles_decoder_faithfulness/roles_decoder_bounds_safe`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `zodiac/roles_decoder_faithfulness/roles_decoder_bounds_safe`

- theorem: `Benchmark.Cases.Zodiac.RolesDecoderFaithfulness.roles_decoder_bounds_safe`
- target module: `Benchmark.Generated.Zodiac.RolesDecoderFaithfulness.Tasks.RolesDecoderBoundsSafe`
- editable files: `Benchmark/Generated/Zodiac/RolesDecoderFaithfulness/Tasks/RolesDecoderBoundsSafe.lean`
- implementation files: `cases/zodiac/roles_decoder_faithfulness/verity/Contract.lean, Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`
- specification files: `cases/zodiac/roles_decoder_faithfulness/verity/Specs.lean, Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: inductive AbiTy where
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: structure Calldata where
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: structure Region where
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: inductive DecodeResult where
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def wordSize : Nat
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def selectorSize : Nat
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def ceil32 (n : Nat) : Nat
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def guardedWord (data : Calldata) (pos : Nat) : Option Nat
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def inBounds (data : Calldata) (r : Region) : Bool
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def nonForwardTail (headOffset tailOffset : Nat) : Bool
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def dynamicPayloadRegion (data : Calldata) (location : Nat) : DecodeResult
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def safeTailFromHead
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def canonicalTailStart
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def sumMapTake (f : α -> Nat) : List α -> Nat -> Nat
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def childAt? (xs : List AbiTy) (i : Nat) : Option AbiTy
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Contract.lean`: def abiStatic : AbiTy -> Bool
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def metadata_bridge_spec (t : AbiTy) : Prop
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def bounds_safe_result (data : Calldata) (result : DecodeResult) : Prop
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def roles_bounds_safe_spec (data : Calldata) (t : AbiTy) (path : List Nat) :
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def roles_ref_faithful_spec (data : Calldata) (t : AbiTy) (path : List Nat) :
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def governed_field_agreement
- `Benchmark/Cases/Zodiac/RolesDecoderFaithfulness/Specs.lean`: def canonical_injectivity_spec

### Current Editable File

`Benchmark/Generated/Zodiac/RolesDecoderFaithfulness/Tasks/RolesDecoderBoundsSafe.lean`

```lean
import Benchmark.Cases.Zodiac.RolesDecoderFaithfulness.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Zodiac.RolesDecoderFaithfulness.Tasks

open Benchmark.Cases.Zodiac.RolesDecoderFaithfulness

theorem roles_decoder_bounds_safe_task
    (data : Calldata) (t : AbiTy) (path : List Nat) :
    roles_bounds_safe_spec data t path := by
  exact ?_

end Benchmark.Generated.Zodiac.RolesDecoderFaithfulness.Tasks
```
