import Benchmark.Cases.NexusMutual.RammPriceBand.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.NexusMutual.RammPriceBand

open Verity
open Verity.EVM.Uint256

/--
Executing `syncPriceBand` stores the synchronized buy quote.
-/
theorem syncPriceBand_sets_buy_price
    (capital_ supply_ : Uint256) (s : ContractState)
    (hSupply : supply_ != 0) :
    let s' := ((RammPriceBand.syncPriceBand capital_ supply_).run s).snd
    syncPriceBand_sets_buy_price_spec capital_ supply_ s s' := by
  simp [grind_norm, RammPriceBand.syncPriceBand, RammPriceBand.buySpotPrice, RammPriceBand.bookValue, syncPriceBand_sets_buy_price_spec, *]

end Benchmark.Cases.NexusMutual.RammPriceBand

