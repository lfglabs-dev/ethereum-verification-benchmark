# Run 20260811T194115-default-fair-gpt-5-6-luna-superfluid__realtime_balance_conservation__failed_nested_rolls_back_and_prevents_resume

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: superfluid/realtime_balance_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `superfluid/realtime_balance_conservation/failed_nested_rolls_back_and_prevents_resume`: forbidden_placeholder
