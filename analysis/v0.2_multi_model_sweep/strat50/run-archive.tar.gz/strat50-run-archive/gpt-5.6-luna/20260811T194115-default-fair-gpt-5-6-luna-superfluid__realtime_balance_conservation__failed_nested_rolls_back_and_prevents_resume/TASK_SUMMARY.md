# Verity Task Summary

- group: `superfluid/realtime_balance_conservation/failed_nested_rolls_back_and_prevents_resume`
- suite: `active`
- tasks: `1`
- check command: `./harness/check.sh`

## Policy

- Edit only files listed under editable files.
- Do not import hidden Proofs modules or Benchmark/GeneratedPreview.
- Do not use `sorry`, `admit`, or new `axiom` declarations.
- In fair comparisons, do not rely on benchmark-specific Grindset helpers or task-name-specific proof knowledge.

## Task 1: `superfluid/realtime_balance_conservation/failed_nested_rolls_back_and_prevents_resume`

- theorem: `Benchmark.Cases.Superfluid.RealtimeBalanceConservation.failedNested_rolls_back_and_prevents_resume`
- target module: `Benchmark.Generated.Superfluid.RealtimeBalanceConservation.Tasks.FailedNestedRollsBackAndPreventsResume`
- editable files: `Benchmark/Generated/Superfluid/RealtimeBalanceConservation/Tasks/FailedNestedRollsBackAndPreventsResume.lean`
- implementation files: `cases/superfluid/realtime_balance_conservation/verity/Contract.lean, Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`
- specification files: `cases/superfluid/realtime_balance_conservation/verity/Specs.lean, Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`

### Relevant Symbols

- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def UINT32_MAX_WORD : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def INT96_MAX_WORD : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def NEG_INT96_MIN_WORD : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def INT256_SIGN_BIT_WORD : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def DEPOSIT_LOW_MASK : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def PACKED_DEPOSIT_MAX : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def isPositiveInt96Word (value : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def isCanonicalInt96Word (value : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def isNonnegativeInt256Word (value : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def signedAddNoOverflow (left right : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def signedSubNoOverflow (left right : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def isPackedDepositWord (value : Uint256) : Bool
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def clipDepositRoundingUp (deposit : Uint256) : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def sourceDeposit
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: def sourceStoredDeposit (deposit : Uint256) : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Contract.lean`: theorem appCreditBase_differs_when_minimumBinds :
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def cfaProjectionAt (s : ContractState) (account : Address) (timestamp : Uint256) : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def pairCfaProjectionAt
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def pairNetFlowRate (s : ContractState) (sender receiver : Address) : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def modularCfaGlobalProjectionSumAt
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def CfaPairCoveredBy
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def pairAndFrameImplyModularCfaGlobalProjection
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: def storedFlowRate (s : ContractState) (sender receiver : Address) : Uint256
- `Benchmark/Cases/Superfluid/RealtimeBalanceConservation/Specs.lean`: structure PinnedSourceState where

### Current Editable File

`Benchmark/Generated/Superfluid/RealtimeBalanceConservation/Tasks/FailedNestedRollsBackAndPreventsResume.lean`

```lean
import Benchmark.Cases.Superfluid.RealtimeBalanceConservation.Contract
import Benchmark.Cases.Superfluid.RealtimeBalanceConservation.Specs

namespace Benchmark.Cases.Superfluid.RealtimeBalanceConservation

open Verity

theorem failedNested_rolls_back_and_prevents_resume {α β γ : Type}
    (outerPrefix : Contract α) (nested : α → Contract β)
    (outerResume : α → β → Contract γ) :
    failedNestedRollsBackAndPreventsResume outerPrefix nested outerResume := by
  exact ?_

end Benchmark.Cases.Superfluid.RealtimeBalanceConservation
```
