import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem redeem_preserves_pps_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    redeem_preserves_pps_spec amountShares feeRate s m := by
  intro h
    simp [redeem_preserves_pps_spec, validRedeemInput, ppsCrossNondecreasing, redeem, redeemPayout, convertToAssets] at *
    have hd := Nat.mul_div_le (amountShares - feeShares amountShares feeRate) (s.assets + 1) (s.shares + m)
    nlinarith

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

