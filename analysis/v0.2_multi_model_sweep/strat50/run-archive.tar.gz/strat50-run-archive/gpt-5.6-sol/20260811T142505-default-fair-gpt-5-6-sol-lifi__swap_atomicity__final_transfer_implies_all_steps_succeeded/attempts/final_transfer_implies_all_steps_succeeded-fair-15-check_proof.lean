import Benchmark.Cases.LiFi.SwapAtomicity.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.LiFi.SwapAtomicity

open Verity
open Verity.EVM.Uint256

/-- A committed final transfer means every modeled LI.FI route step succeeded. -/
theorem final_transfer_implies_all_steps_succeeded
    (route : RouteGuards) (steps : List SwapStep)
    (minAmount outputAmount : Nat) :
    final_transfer_implies_all_steps_succeeded_spec
      route steps minAmount outputAmount := by
  set_option maxHeartbeats 2000000 in
    simp only [final_transfer_implies_all_steps_succeeded_spec]
    intro h
    induction steps with
    | nil =>
        simp [allStepsSucceeded]
    | cons a rest ih =>
        cases a <;>
          simp_all (config := { maxSteps := 1000000 }) only [depositAndSwap,
            executeSwapsCount, finalTransferCommitted, requiredDepositCount,
            allStepsSucceeded, getStorage, setStorage, Verity.require,
            Verity.bind, Bind.bind, Verity.pure, Pure.pure, Contract.run]

end Benchmark.Cases.LiFi.SwapAtomicity

