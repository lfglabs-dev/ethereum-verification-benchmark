# Run 20260811T143602-default-fair-gpt-5-6-sol-lifi__swap_atomicity__no_final_transfer_on_failed_step

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lifi/swap_atomicity
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `lifi/swap_atomicity/no_final_transfer_on_failed_step`: forbidden_placeholder
