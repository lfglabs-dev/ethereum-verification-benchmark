# Run 20260811T140545-default-fair-gpt-5-6-sol-forgeyields__global_solvency__handle_preserves_global_solvency

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: forgeyields/global_solvency
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `forgeyields/global_solvency/handle_preserves_global_solvency`: passed
