# Run 20260811T145158-default-fair-gpt-5-6-sol-paladin_votes__stream_recovery_claim_usdc__both_claim_marks_both_claimed

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: paladin_votes/stream_recovery_claim_usdc
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `paladin_votes/stream_recovery_claim_usdc/both_claim_marks_both_claimed`: timeout
