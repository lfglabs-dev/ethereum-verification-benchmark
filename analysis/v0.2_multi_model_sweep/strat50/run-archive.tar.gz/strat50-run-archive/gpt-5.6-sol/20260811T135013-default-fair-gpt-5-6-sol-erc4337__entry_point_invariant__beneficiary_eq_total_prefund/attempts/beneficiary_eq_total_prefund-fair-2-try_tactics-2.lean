import Benchmark.Cases.ERC4337.EntryPointInvariant.Specs

namespace Benchmark.Cases.ERC4337.EntryPointInvariant

open Verity
open Verity.EVM.Uint256

/--
Beneficiary receives exactly the sum of per-op prefunds on success.
-/
theorem beneficiary_eq_total_prefund
    (ops : List FullOpInfo) (startNonce : Nat) :
    beneficiary_eq_total_prefund_spec ops startNonce := by
  unfold beneficiary_eq_total_prefund_spec beneficiaryReceives
  intro h
  split <;> simp_all

end Benchmark.Cases.ERC4337.EntryPointInvariant

