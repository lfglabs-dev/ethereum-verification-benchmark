# Run 20260811T135013-default-fair-gpt-5-6-sol-erc4337__entry_point_invariant__beneficiary_eq_total_prefund

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: erc4337/entry_point_invariant
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `erc4337/entry_point_invariant/beneficiary_eq_total_prefund`: passed
