# Run 20260811T152653-default-fair-gpt-5-6-sol-polaris__bonding_curve__floor_sell_and_burn_preserves_reserve_ratio_zero

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: polaris/bonding_curve
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `polaris/bonding_curve/floor_sell_and_burn_preserves_reserve_ratio_zero`: theorem_missing
