# Run 20260811T141823-default-fair-gpt-5-6-sol-lagoon__guardrails__exact_compliance

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lagoon/guardrails
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {}

## Targets

- `lagoon/guardrails/exact_compliance`: theorem_missing
