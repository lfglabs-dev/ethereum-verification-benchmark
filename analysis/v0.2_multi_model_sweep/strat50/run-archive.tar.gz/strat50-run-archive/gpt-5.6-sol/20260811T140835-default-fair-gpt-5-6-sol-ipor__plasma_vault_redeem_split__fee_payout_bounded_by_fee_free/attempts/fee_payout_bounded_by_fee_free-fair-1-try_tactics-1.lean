import Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

theorem fee_payout_bounded_by_fee_free_task
    (amountShares feeRate : Nat) (s : VaultState) (m : Nat := virtualShares) :
    fee_payout_bounded_by_fee_free_spec amountShares feeRate s m := by
  simp only [fee_payout_bounded_by_fee_free_spec, redeemPayout, feeFreePayout, convertToAssets]
  intro h
  exact Nat.div_le_div_right (Nat.mul_le_mul_right _ (Nat.sub_le amountShares (feeShares amountShares feeRate)))

end Benchmark.Cases.IPOR.PlasmaVaultRedeemSplit

