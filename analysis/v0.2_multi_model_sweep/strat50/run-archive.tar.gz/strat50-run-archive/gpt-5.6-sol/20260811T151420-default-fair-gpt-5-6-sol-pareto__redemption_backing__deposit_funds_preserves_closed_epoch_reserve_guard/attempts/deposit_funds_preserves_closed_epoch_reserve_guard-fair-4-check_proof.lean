import Benchmark.Cases.Pareto.RedemptionBacking.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.Pareto.RedemptionBacking

open Verity
open Verity.EVM.Uint256

theorem depositFunds_preserves_closed_epoch_reserve_guard
    (depositedScaled : Uint256) (s : ContractState)
    (hCollateralized : s.storage 5 != 0)
    (hDepositLeIdle : depositedScaled.val <= (s.storage 0).val)
    (hCurrentLeReserved : (s.storage 3).val <= (s.storage 2).val)
    (hAddNoOverflow :
      (sub (s.storage 0) depositedScaled).val + (s.storage 1).val <
        Verity.Core.Uint256.modulus)
    (hReserveGuard :
      (sub (s.storage 2) (s.storage 3)).val <=
        (add (sub (s.storage 0) depositedScaled) (s.storage 1)).val) :
    let s' := ((ParetoDollarQueue.depositFunds depositedScaled).run s).snd
    depositFunds_preserves_closed_epoch_reserve_guard_spec s s' := by
  unfold depositFunds_preserves_closed_epoch_reserve_guard_spec
      closed_epoch_reserve_guard closedClaims idleCollateralScaledOf
      totCreditVaultsRequestedScaledOf totReservedWithdrawalsOf
      currentEpochPendingOf
    unfold ParetoDollarQueue.depositFunds
    simp [ParetoDollarQueue.idleCollateralScaled,
      ParetoDollarQueue.totCreditVaultsRequestedScaled,
      ParetoDollarQueue.totReservedWithdrawals,
      ParetoDollarQueue.currentEpochPending,
      ParetoDollarQueue.previousEpochPending,
      ParetoDollarQueue.collateralizedFlag,
      getStorage, setStorage, Verity.require, Verity.bind, Bind.bind,
      Verity.pure, Pure.pure, Contract.run, ContractResult.snd,
      hCollateralized, hDepositLeIdle, hCurrentLeReserved]
    all_goals split_ifs <;> simp_all
    all_goals omega

end Benchmark.Cases.Pareto.RedemptionBacking

