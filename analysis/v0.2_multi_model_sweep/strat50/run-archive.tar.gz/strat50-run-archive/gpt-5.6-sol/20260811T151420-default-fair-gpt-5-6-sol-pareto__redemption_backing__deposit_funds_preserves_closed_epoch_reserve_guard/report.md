# Run 20260811T151420-default-fair-gpt-5-6-sol-pareto__redemption_backing__deposit_funds_preserves_closed_epoch_reserve_guard

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: pareto/redemption_backing
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `pareto/redemption_backing/deposit_funds_preserves_closed_epoch_reserve_guard`: lean_check_failed
