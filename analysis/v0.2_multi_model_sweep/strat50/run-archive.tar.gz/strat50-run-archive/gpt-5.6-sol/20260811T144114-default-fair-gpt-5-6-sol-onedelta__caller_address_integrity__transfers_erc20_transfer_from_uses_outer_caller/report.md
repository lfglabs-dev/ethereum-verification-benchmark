# Run 20260811T144114-default-fair-gpt-5-6-sol-onedelta__caller_address_integrity__transfers_erc20_transfer_from_uses_outer_caller

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: onedelta/caller_address_integrity
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `onedelta/caller_address_integrity/transfers_erc20_transfer_from_uses_outer_caller`: forbidden_placeholder
