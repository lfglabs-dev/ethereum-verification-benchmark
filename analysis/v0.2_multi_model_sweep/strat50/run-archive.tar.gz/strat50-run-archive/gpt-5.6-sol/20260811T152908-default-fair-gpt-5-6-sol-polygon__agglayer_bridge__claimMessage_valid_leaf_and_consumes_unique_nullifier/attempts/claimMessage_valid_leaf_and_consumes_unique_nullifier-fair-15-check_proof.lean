import Benchmark.Cases.Polygon.AgglayerBridge.Contract
import Benchmark.Cases.Polygon.AgglayerBridge.Specs
import Benchmark.Grindset

namespace Benchmark.Generated.Polygon.AgglayerBridge.Tasks

open Verity
open Verity.EVM.Uint256
open Benchmark.Cases.Polygon.AgglayerBridge

theorem claimMessage_valid_leaf_and_consumes_unique_nullifier
    (s : ContractState)
    (smtProofLocalExitRoot smtProofRollupExitRoot : Array Uint256)
    (globalIndex mainnetExitRoot rollupExitRoot originNetwork : Uint256)
    (originAddress : Address)
    (destinationNetwork : Uint256)
    (destinationAddress : Address)
    (amount metadataHash : Uint256) :
    match
      (AgglayerBridge.claimMessage
        smtProofLocalExitRoot smtProofRollupExitRoot globalIndex mainnetExitRoot rollupExitRoot
        originNetwork originAddress destinationNetwork destinationAddress amount metadataHash).run s
    with
    | ContractResult.success _ s' =>
        claimMessage_valid_leaf_and_consumes_unique_nullifier_spec
          s s' smtProofLocalExitRoot smtProofRollupExitRoot globalIndex mainnetExitRoot rollupExitRoot
          originNetwork originAddress destinationNetwork destinationAddress amount metadataHash
    | ContractResult.revert _ _ => True := by
  set_option maxHeartbeats 2000000 in
  set_option linter.unusedSimpArgs false in
    unfold AgglayerBridge.claimMessage
    unfold AgglayerBridge._setAndCheckClaimed
    simp [claimMessage_valid_leaf_and_consumes_unique_nullifier_spec,
      validClaimLeaf_spec, nullifierConsumed_spec,
      AgglayerBridge.claimedBitMap, getStorage, setStorage, getMapping, setMapping,
      Verity.require, Verity.bind, Bind.bind, Verity.pure, Pure.pure,
      Contract.run, ContractResult.snd]
    <;> split
    <;> (try simp_all [claimMessage_valid_leaf_and_consumes_unique_nullifier_spec,
      validClaimLeaf_spec, nullifierConsumed_spec,
      AgglayerBridge.claimedBitMap, getStorage, setStorage, getMapping, setMapping,
      Verity.require, Verity.bind, Bind.bind,
      Contract.run, ContractResult.snd])
    <;> grind

end Benchmark.Generated.Polygon.AgglayerBridge.Tasks

