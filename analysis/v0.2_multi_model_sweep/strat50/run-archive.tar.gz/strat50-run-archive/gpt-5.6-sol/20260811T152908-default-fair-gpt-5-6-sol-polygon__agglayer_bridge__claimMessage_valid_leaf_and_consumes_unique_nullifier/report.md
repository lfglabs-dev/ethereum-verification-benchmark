# Run 20260811T152908-default-fair-gpt-5-6-sol-polygon__agglayer_bridge__claimMessage_valid_leaf_and_consumes_unique_nullifier

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: polygon/agglayer_bridge
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `polygon/agglayer_bridge/claimMessage_valid_leaf_and_consumes_unique_nullifier`: lean_check_failed
