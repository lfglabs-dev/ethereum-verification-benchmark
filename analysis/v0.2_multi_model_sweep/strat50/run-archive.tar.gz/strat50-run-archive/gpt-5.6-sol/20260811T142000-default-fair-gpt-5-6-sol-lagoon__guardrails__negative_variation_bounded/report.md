# Run 20260811T142000-default-fair-gpt-5-6-sol-lagoon__guardrails__negative_variation_bounded

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: lagoon/guardrails
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {}

## Targets

- `lagoon/guardrails/negative_variation_bounded`: theorem_missing
