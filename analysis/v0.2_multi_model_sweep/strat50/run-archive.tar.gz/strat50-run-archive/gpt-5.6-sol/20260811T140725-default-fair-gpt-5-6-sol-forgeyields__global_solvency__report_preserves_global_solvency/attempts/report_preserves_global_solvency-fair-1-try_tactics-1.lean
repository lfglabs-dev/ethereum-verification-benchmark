import Benchmark.Cases.ForgeYields.GlobalSolvency.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.ForgeYields.GlobalSolvency

open Verity
open Verity.EVM.Uint256

theorem report_preserves_global_solvency
    (s : ContractState) :
    let s' := ((TokenGateway.report).run s).snd
    report_preserves_global_solvency_spec s s' := by
  simp [report_preserves_global_solvency_spec, TokenGateway.report, grind_norm]

end Benchmark.Cases.ForgeYields.GlobalSolvency

