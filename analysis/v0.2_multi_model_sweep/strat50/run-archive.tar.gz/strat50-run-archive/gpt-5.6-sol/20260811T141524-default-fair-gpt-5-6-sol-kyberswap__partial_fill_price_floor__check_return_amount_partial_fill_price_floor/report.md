# Run 20260811T141524-default-fair-gpt-5-6-sol-kyberswap__partial_fill_price_floor__check_return_amount_partial_fill_price_floor

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: kyberswap/partial_fill_price_floor
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `kyberswap/partial_fill_price_floor/check_return_amount_partial_fill_price_floor`: passed
