import Benchmark.Cases.KyberSwap.PartialFillPriceFloor.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.KyberSwap.PartialFillPriceFloor

open Verity
open Verity.EVM.Uint256

/--
KyberSwap helper-level partial-fill price-floor invariant.

For a successful modeled `_checkReturnAmount` execution in the partial-fill
branch, the checked scaled floor holds:

  `returnAmount * amount >= minReturnAmount * spentAmount`.
-/
theorem checkReturnAmount_partial_fill_price_floor
    (spentAmount returnAmount amount minReturnAmount flags : Uint256)
    (s : ContractState)
    (hPartial :
      isPartialFill
        { amount := amount, minReturnAmount := minReturnAmount, flags := flags } = true)
    (hRun :
      (MetaAggregationRouterV2._checkReturnAmount
        spentAmount returnAmount amount minReturnAmount flags).run s =
        ContractResult.success () s) :
    partial_fill_price_floor_spec spentAmount returnAmount
      { amount := amount, minReturnAmount := minReturnAmount, flags := flags } := by
  simp only [grind_norm] at *
  unfold partial_fill_price_floor_spec checkedScaledPriceFloorHolds
  unfold MetaAggregationRouterV2._checkReturnAmount at hRun
  simp only [grind_norm, isPartialFill, _flagsChecked, partialFillFlag] at hPartial
  unfold Stdlib.Math.mulPanic at hRun
  cases hLeft : Stdlib.Math.safeMul returnAmount amount with
  | none =>
      simp [hLeft] at hRun
  | some left =>
      cases hRight : Stdlib.Math.safeMul minReturnAmount spentAmount with
      | none =>
          simp [hLeft, hRight] at hRun
      | some right =>
          simp [hLeft, hRight] at hRun ⊢

end Benchmark.Cases.KyberSwap.PartialFillPriceFloor

