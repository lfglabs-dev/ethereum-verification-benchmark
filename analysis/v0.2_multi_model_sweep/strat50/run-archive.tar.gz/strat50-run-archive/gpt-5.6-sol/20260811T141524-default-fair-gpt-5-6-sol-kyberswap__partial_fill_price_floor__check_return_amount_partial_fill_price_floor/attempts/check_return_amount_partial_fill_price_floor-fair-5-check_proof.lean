import Benchmark.Cases.KyberSwap.PartialFillPriceFloor.Specs
import Benchmark.Grindset

namespace Benchmark.Cases.KyberSwap.PartialFillPriceFloor

open Verity
open Verity.EVM.Uint256

/--
KyberSwap helper-level partial-fill price-floor invariant.

For a successful modeled `_checkReturnAmount` execution in the partial-fill
branch, the checked scaled floor holds:

  `returnAmount * amount >= minReturnAmount * spentAmount`.
-/
theorem checkReturnAmount_partial_fill_price_floor
    (spentAmount returnAmount amount minReturnAmount flags : Uint256)
    (s : ContractState)
    (hPartial :
      isPartialFill
        { amount := amount, minReturnAmount := minReturnAmount, flags := flags } = true)
    (hRun :
      (MetaAggregationRouterV2._checkReturnAmount
        spentAmount returnAmount amount minReturnAmount flags).run s =
        ContractResult.success () s) :
    partial_fill_price_floor_spec spentAmount returnAmount
      { amount := amount, minReturnAmount := minReturnAmount, flags := flags } := by
  unfold partial_fill_price_floor_spec checkedScaledPriceFloorHolds
  intro _
  simp only [grind_norm, isPartialFill, _flagsChecked, partialFillFlag] at hPartial
  have hFlag : EVM.Uint256.and flags 1 ≠ 0 := by
    intro hZero
    rw [hZero] at hPartial
    simp at hPartial
  unfold MetaAggregationRouterV2._checkReturnAmount at hRun
  unfold Stdlib.Math.mulPanic at hRun
  cases hLeft : Stdlib.Math.safeMul returnAmount amount with
  | none =>
      simp [hFlag, hLeft, Stdlib.Math.requireSomeUint, Verity.require,
        Verity.bind, Bind.bind, Verity.pure, Pure.pure] at hRun
  | some left =>
      cases hRight : Stdlib.Math.safeMul minReturnAmount spentAmount with
      | none =>
          simp [hFlag, hLeft, hRight, Stdlib.Math.requireSomeUint, Verity.require,
            Verity.bind, Bind.bind, Verity.pure, Pure.pure] at hRun
      | some right =>
          by_cases hLe : right.val ≤ left.val
          · simpa [hLeft, hRight] using hLe
          · simp [hFlag, hLeft, hRight, hLe, Stdlib.Math.requireSomeUint,
              Verity.require, Verity.bind, Bind.bind, Verity.pure, Pure.pure] at hRun

end Benchmark.Cases.KyberSwap.PartialFillPriceFloor

