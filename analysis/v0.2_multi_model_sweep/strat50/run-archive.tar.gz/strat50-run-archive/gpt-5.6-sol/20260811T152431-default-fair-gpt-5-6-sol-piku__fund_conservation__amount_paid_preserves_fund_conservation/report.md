# Run 20260811T152431-default-fair-gpt-5-6-sol-piku__fund_conservation__amount_paid_preserves_fund_conservation

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: piku/fund_conservation
- score: 0 / 1 points
- targets: 0 / 1 passed
- failure taxonomy: {"repetition_loop": 1}

## Targets

- `piku/fund_conservation/amount_paid_preserves_fund_conservation`: forbidden_placeholder
