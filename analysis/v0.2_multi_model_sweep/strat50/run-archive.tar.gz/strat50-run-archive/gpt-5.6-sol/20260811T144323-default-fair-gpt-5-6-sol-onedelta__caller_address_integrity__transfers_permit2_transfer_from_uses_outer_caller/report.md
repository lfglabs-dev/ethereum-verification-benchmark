# Run 20260811T144323-default-fair-gpt-5-6-sol-onedelta__caller_address_integrity__transfers_permit2_transfer_from_uses_outer_caller

- harness: default
- track: group/lean_tools
- run mode: task
- harness mode: fair
- group: onedelta/caller_address_integrity
- score: 1 / 1 points
- targets: 1 / 1 passed
- failure taxonomy: {}

## Targets

- `onedelta/caller_address_integrity/transfers_permit2_transfer_from_uses_outer_caller`: passed
